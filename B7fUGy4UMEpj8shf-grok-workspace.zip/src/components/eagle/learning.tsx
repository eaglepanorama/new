import { Download, Map as MapIcon, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePanorama } from "@/store/panorama";

const STATUS_LABEL = {
  explored: "Explored",
  learning: "Learning",
  mastered: "Mastered (self)",
  verified: "Verified",
};

export function LearningAtlas({ onOpen }: { onOpen: (title: string) => void }) {
  const atlas = usePanorama((s) => s.atlas);
  const savedTopics = usePanorama((s) => s.savedTopics);
  const savedResources = usePanorama((s) => s.savedResources);
  const savedBooks = usePanorama((s) => s.savedBooks);
  const recentSearches = usePanorama((s) => s.recentSearches);
  const setAtlasStatus = usePanorama((s) => s.setAtlasStatus);
  const removeRecent = usePanorama((s) => s.removeRecent);
  const removeSavedTopic = usePanorama((s) => s.removeSavedTopic);
  const removeSavedResource = usePanorama((s) => s.removeSavedResource);
  const removeSavedBook = usePanorama((s) => s.removeSavedBook);
  const clearLearningData = usePanorama((s) => s.clearLearningData);
  const exportEvidence = usePanorama((s) => s.exportEvidence);
  const saveNote = usePanorama((s) => s.saveNote);

  const states = [...atlas].sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));
  const explored = states.filter((item) => item.status === "explored").length;
  const learning = states.filter((item) => item.status === "learning").length;
  const verified = states.filter((item) => item.status === "verified").length;
  const mastered = states.filter((item) => item.status === "mastered").length;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 text-fg">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-primary">Personal atlas</p>
          <h1 className="mt-2 font-display text-4xl">My Learning</h1>
          <p className="mt-2 max-w-2xl text-fg-muted">
            A local record of what you explored, marked as learning, or actually verified. Nothing here is
            uploaded. Verification is evidence of demonstrated work, not a claim of mastery.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={exportEvidence}>
            <Download className="size-4" /> Export evidence
          </Button>
          <Button
            variant="secondary"
            onClick={() => {
              if (window.confirm("Clear all saved topics, resources, books, and recent searches?")) {
                clearLearningData();
              }
            }}
          >
            <Trash2 className="size-4" /> Clear
          </Button>
        </div>
      </header>

      <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat value={states.length} label="Topics in atlas" />
        <Stat value={learning} label="Learning" />
        <Stat value={verified} label="Verified" />
        <Stat value={savedTopics.length} label="Saved" />
      </div>
      <p className="mt-2 text-xs text-fg-muted">
        Explored {explored} · self-marked mastered {mastered}. Self-mastery is not the same as verified.
      </p>

      <section className="mt-8 rounded-[22px] border border-border bg-bg-elevated p-5">
        <h2 className="font-display text-2xl">Atlas</h2>
        {states.length === 0 ? (
          <p className="mt-3 text-fg-muted">
            Your atlas is empty. Explore a topic and it will appear here automatically.
          </p>
        ) : (
          <div className="mt-4 grid gap-3">
            {states.slice(0, 12).map((item) => (
              <article
                key={`${item.language}-${item.title}`}
                className="flex flex-col gap-3 rounded-[16px] border border-border bg-bg-subtle p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <h3 className="font-semibold">{item.title}</h3>
                  <p className="text-sm text-fg-muted">
                    {item.visits} visit{item.visits === 1 ? "" : "s"} · {STATUS_LABEL[item.status]}
                  </p>
                  {item.evidence ? (
                    <p className="mt-1 text-xs text-fg-muted">
                      Check {Number(item.evidence.score || 0)}/{Number(item.evidence.total || 5)} ·{" "}
                      {item.evidence.explanationSubmitted ? "explanation submitted" : "explanation pending"} ·{" "}
                      {item.evidence.connectionCompleted ? "connection demonstrated" : "connection pending"}
                    </p>
                  ) : null}
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="secondary" onClick={() => onOpen(item.title)}>
                    Open
                  </Button>
                  {item.status !== "learning" && item.status !== "verified" ? (
                    <Button size="sm" variant="secondary" onClick={() => setAtlasStatus(item.title, "learning")}>
                      Learning
                    </Button>
                  ) : null}
                  {item.status !== "mastered" && item.status !== "verified" ? (
                    <Button size="sm" variant="secondary" onClick={() => setAtlasStatus(item.title, "mastered")}>
                      Mark mastered
                    </Button>
                  ) : null}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      <section className="mt-6 rounded-[22px] border border-border bg-bg-elevated p-5">
        <h2 className="font-display text-xl">Study note</h2>
        <StudyNote onSave={saveNote} />
      </section>

      <ListBlock
        title="Recent searches"
        empty="No recent searches yet."
        items={recentSearches.map((item) => ({
          title: item.pageTitle,
          meta: item.query,
          onOpen: () => onOpen(item.pageTitle),
          onRemove: () => removeRecent(item.query, item.language),
        }))}
      />
      <ListBlock
        title="Saved topics"
        empty="No saved topics yet."
        items={savedTopics.map((item) => ({
          title: item.title,
          meta: item.category || item.description,
          onOpen: () => onOpen(item.title),
          onRemove: () => removeSavedTopic(item.url, item.language),
        }))}
      />
      <ListBlock
        title="Saved resources"
        empty="No saved resources yet."
        items={savedResources.map((item) => ({
          title: item.name || item.title || item.url,
          meta: item.topic || item.url,
          href: item.url,
          onRemove: () => removeSavedResource(item.url),
        }))}
      />
      <ListBlock
        title="Saved books"
        empty="No saved books yet."
        items={savedBooks.map((item) => ({
          title: item.title || item.url,
          meta: item.author || "",
          href: item.url,
          onRemove: () => removeSavedBook(item.url),
        }))}
      />
    </div>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="rounded-[16px] border border-border bg-bg-elevated p-4">
      <p className="font-display text-3xl tabular-nums">{value}</p>
      <p className="mt-1 text-sm text-fg-muted">{label}</p>
    </div>
  );
}

function StudyNote({ onSave }: { onSave: (note: string) => void }) {
  return (
    <form
      className="mt-3 grid gap-2"
      onSubmit={(event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const area = form.elements.namedItem("note") as HTMLTextAreaElement;
        const value = area.value.trim();
        if (!value) return;
        onSave(value);
        area.value = "";
      }}
    >
      <textarea
        name="note"
        className="min-h-24 rounded-[12px] border border-border bg-bg-subtle p-3 text-sm text-fg outline-none focus:border-primary"
        placeholder="A private note about what you are trying to understand."
      />
      <Button type="submit" variant="secondary" className="justify-self-start">
        Save note locally
      </Button>
    </form>
  );
}

function ListBlock({
  title,
  empty,
  items,
}: {
  title: string;
  empty: string;
  items: Array<{
    title: string;
    meta: string;
    href?: string;
    onOpen?: () => void;
    onRemove: () => void;
  }>;
}) {
  return (
    <section className="mt-6 rounded-[22px] border border-border bg-bg-elevated p-5">
      <h2 className="font-display text-xl">{title}</h2>
      {items.length === 0 ? (
        <p className="mt-3 text-sm text-fg-muted">{empty}</p>
      ) : (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {items.map((item) => (
            <article key={item.title + item.meta} className="rounded-[14px] border border-border bg-bg-subtle p-4">
              <h3 className="font-semibold">{item.title}</h3>
              <p className="mt-1 text-sm text-fg-muted">{item.meta}</p>
              <div className="mt-3 flex gap-2">
                {item.onOpen ? (
                  <Button size="sm" variant="secondary" onClick={item.onOpen}>
                    Open
                  </Button>
                ) : item.href ? (
                  <Button size="sm" variant="secondary" asChild>
                    <a href={item.href} target="_blank" rel="noopener noreferrer">
                      Open
                    </a>
                  </Button>
                ) : null}
                <Button size="sm" variant="ghost" onClick={item.onRemove}>
                  Remove
                </Button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

export function LearningEmptyHint() {
  return (
    <p className="inline-flex items-center gap-2 text-sm text-fg-muted">
      <MapIcon className="size-4" /> Explore a subject, then return here to see it in your atlas.
    </p>
  );
}
