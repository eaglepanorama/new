import { Minus, Plus, RotateCcw } from "lucide-react";
import { useMemo, useState } from "react";
import { RELATION_COPY } from "@/lib/panorama/catalog";
import { buildKnowledgeGraph, wrapNodeTitle } from "@/lib/panorama/engine";
import type { MapPerspective, RelationType, TopicResult } from "@/lib/panorama/types";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const TYPE_COLOR: Record<string, { fill: string; stroke: string; edge: string }> = {
  current: { fill: "#cfe8e4", stroke: "#1f9a93", edge: "#1f9a93" },
  foundation: { fill: "#dcefe0", stroke: "#3d7a58", edge: "#3d7a58" },
  path: { fill: "#d7e6f5", stroke: "#3d6494", edge: "#3d6494" },
  connected: { fill: "#e4dced", stroke: "#6a5a86", edge: "#6a5a86" },
  broader: { fill: "#f0e2d2", stroke: "#8a6744", edge: "#8a6744" },
  causal: { fill: "#d4eceb", stroke: "#2f7c7d", edge: "#2f7c7d" },
  application: { fill: "#f3e7d2", stroke: "#8d6a3c", edge: "#8d6a3c" },
  method: { fill: "#e6dcf0", stroke: "#6d568c", edge: "#6d568c" },
  contrast: { fill: "#f1dcd9", stroke: "#8d5753", edge: "#8d5753" },
  discovery: { fill: "#e8eef2", stroke: "#5d7380", edge: "#5d7380" },
};

const PERSPECTIVE_NOTE: Record<MapPerspective, string> = {
  nearby: "Connected subjects reveal nearby areas of knowledge.",
  in: "More specific steps from this subject's learning path and foundations.",
  out: "Broader fields that place this subject in a larger landscape.",
};

export function KnowledgeMap({
  result,
  perspective,
  onPerspective,
  onOpen,
}: {
  result: TopicResult | null;
  perspective: MapPerspective;
  onPerspective: (mode: MapPerspective) => void;
  onOpen: (title: string) => void;
}) {
  const [scale, setScale] = useState(1);
  const graph = useMemo(() => {
    if (!result) return null;
    return buildKnowledgeGraph({
      localTopic: result.localTopic,
      localKey: result.localKey,
      level: result.level,
      relatedPages: result.relatedPages,
      centerTitle: result.summary.title,
      perspective,
    });
  }, [result, perspective]);

  if (!result || !graph) {
    return (
      <section className="rounded-[26px] border border-line bg-map p-6 text-ink shadow-[0_18px_44px_rgba(4,22,36,0.12)]">
        <h2 className="font-display text-2xl text-ink">Knowledge Map</h2>
        <p className="mt-2 max-w-2xl text-ink-muted">
          Search a topic first, then use this map to move through the landscape around it.
        </p>
      </section>
    );
  }

  const all = [graph.center, ...graph.nodes, ...graph.outer];

  return (
    <section className="rounded-[26px] border border-line bg-map p-4 text-ink shadow-[0_18px_44px_rgba(4,22,36,0.12)] sm:p-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h2 className="font-display text-2xl text-ink">Knowledge Map</h2>
          <p className="mt-1 max-w-2xl text-sm leading-6 text-ink-muted">
            See how <strong className="text-ink">{result.summary.title}</strong> fits into the surrounding
            landscape. Different connections mean different things.
          </p>
        </div>
        <div className="flex gap-1">
          <Button variant="paper" size="icon" aria-label="Enlarge map" onClick={() => setScale((s) => Math.min(1.8, s * 1.18))}>
            <Plus className="size-4" />
          </Button>
          <Button variant="paper" size="icon" aria-label="Shrink map" onClick={() => setScale((s) => Math.max(0.72, s * 0.85))}>
            <Minus className="size-4" />
          </Button>
          <Button variant="paper" size="icon" aria-label="Reset map size" onClick={() => setScale(1)}>
            <RotateCcw className="size-4" />
          </Button>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {(["out", "nearby", "in"] as MapPerspective[]).map((mode) => (
          <button
            key={mode}
            type="button"
            onClick={() => onPerspective(mode)}
            className={cn(
              "min-h-11 rounded-full border px-4 text-sm font-semibold",
              perspective === mode
                ? "border-primary bg-primary-soft text-primary"
                : "border-line bg-surface text-ink-muted",
            )}
          >
            {mode === "out" ? "Zoom out" : mode === "in" ? "Zoom in" : "Nearby"}
          </button>
        ))}
      </div>
      <p className="mt-2 text-sm text-ink-muted">{PERSPECTIVE_NOTE[perspective]}</p>

      <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-xs text-ink-muted">
        {(Object.keys(RELATION_COPY) as Array<RelationType | "current">)
          .filter((key) => key !== "current" && key !== "discovery")
          .map((key) => (
            <span key={key} className="inline-flex items-center gap-2">
              <i
                className="inline-block h-0.5 w-6 rounded-full"
                style={{ background: TYPE_COLOR[key]?.stroke }}
              />
              {RELATION_COPY[key].label}
            </span>
          ))}
      </div>

      <div className="mt-4 overflow-hidden rounded-[20px] border border-line bg-[#f7fbfd]">
        <svg
          viewBox="0 0 1400 780"
          className="h-[430px] w-full sm:h-[590px]"
          role="img"
          aria-label="Interactive knowledge graph"
        >
          <g transform={`translate(700 390) scale(${scale}) translate(-700 -390)`}>
            {graph.nodes.map((node) => (
              <line
                key={`e-${node.title}`}
                x1={graph.center.x}
                y1={graph.center.y}
                x2={node.x}
                y2={node.y}
                stroke={TYPE_COLOR[node.type]?.edge || "#5d7380"}
                strokeWidth={node.type === "foundation" || node.type === "path" ? 3 : 2.4}
              />
            ))}
            {graph.outer.map((node, index) => {
              const parent = graph.nodes[index % Math.max(graph.nodes.length, 1)];
              if (!parent) return null;
              return (
                <line
                  key={`o-${node.title}`}
                  x1={parent.x}
                  y1={parent.y}
                  x2={node.x}
                  y2={node.y}
                  stroke="#7f94a1"
                  strokeWidth={1.5}
                  strokeDasharray="5 5"
                />
              );
            })}
            {all.map((node) => {
              const colors = TYPE_COLOR[node.type] || TYPE_COLOR.discovery;
              const radius = node.type === "current" ? 92 : 70;
              const lines = wrapNodeTitle(node.title);
              return (
                <g
                  key={node.title}
                  tabIndex={0}
                  role="button"
                  aria-label={`Explore ${node.title}`}
                  className="cursor-pointer outline-none"
                  onClick={() => onOpen(node.title)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") {
                      event.preventDefault();
                      onOpen(node.title);
                    }
                  }}
                >
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={radius}
                    fill={colors.fill}
                    stroke={colors.stroke}
                    strokeWidth={node.type === "current" ? 3 : 2}
                  />
                  {lines.map((line, index) => (
                    <text
                      key={line + index}
                      x={node.x}
                      y={node.y + (index - (lines.length - 1) / 2) * 16}
                      textAnchor="middle"
                      fill="#142b3b"
                      fontSize={node.type === "current" ? 16 : 14}
                      fontWeight={700}
                    >
                      {line}
                    </text>
                  ))}
                  <text
                    x={node.x}
                    y={node.y + radius - 16}
                    textAnchor="middle"
                    fill="#4e6674"
                    fontSize={10}
                    fontWeight={600}
                  >
                    {RELATION_COPY[node.type]?.label || node.type}
                  </text>
                </g>
              );
            })}
          </g>
        </svg>
      </div>

      <div className="mt-4 rounded-[16px] border border-line bg-surface p-4">
        <p className="text-sm font-semibold text-ink">Explore without clicking the map</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {all
            .filter((node) => node.type !== "current")
            .map((node) => (
              <button
                key={node.title}
                type="button"
                onClick={() => onOpen(node.title)}
                className="max-w-full rounded-[12px] border border-line bg-surface-2 px-3 py-2 text-left text-sm text-ink"
              >
                <span className="font-semibold">{node.title}</span>
                <span className="mt-0.5 block text-xs text-ink-muted">
                  {RELATION_COPY[node.type]?.label}: {node.explanation}
                </span>
              </button>
            ))}
        </div>
      </div>
    </section>
  );
}
