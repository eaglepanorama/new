import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { usePanorama } from "@/store/panorama";

const SLIDES = [
  {
    kicker: "01 / 08",
    title: "Take a step back. See the bigger picture.",
    body: "Eagles Panorama is an interactive learning explorer. The point is not one article. The point is where a topic sits in a wider landscape of knowledge.",
  },
  {
    kicker: "02 / 08 · The problem",
    title: "Information is everywhere. Context is harder to find.",
    body: "Typical search hands you an isolated page. This app starts with a topic, then shows prerequisites, relationships, a path, and a way to check understanding.",
  },
  {
    kicker: "03 / 08 · The solution",
    title: "A learning journey instead of a search result.",
    body: "Search, understand, connect, test, remember. Live public sources sit next to a small authored knowledge layer so exploration can be structured without becoming rigid.",
  },
  {
    kicker: "04 / 08 · What you can do",
    title: "One system, several ways to learn.",
    cards: [
      "Learning paths with beginner, intermediate, and advanced routes",
      "A knowledge map of authored relationships",
      "A check that asks you to recall, connect, and explain",
      "Better sources: reference, learning, research, and books",
      "A personal atlas stored locally in the browser",
      "Wikipedia languages while exploring",
    ],
  },
  {
    kicker: "05 / 08 · How it works",
    title: "A data-driven web application.",
    body: "Core subjects are structured data: aliases, overviews, paths, concepts, and relationships. The interface reads that data and generates the experience. Public APIs fill in live summaries, books, and research. Local storage keeps your atlas on this device.",
  },
  {
    kicker: "06 / 08 · The technical idea",
    title: "It is not a collection of hard-coded pages.",
    body: "Adding a topic extends the app without creating a new page for every subject. Automatically generated paths are exploration aids, not formally validated curricula.",
  },
  {
    kicker: "07 / 08 · Honest limitations",
    title: "A real project should say what it cannot do.",
    cards: [
      "Personal data stays in this browser",
      "Live search depends on public APIs",
      "Generated paths are not official courses",
      "The authored knowledge base is still small",
    ],
  },
  {
    kicker: "08 / 08 · Demonstration",
    title: "Show the idea through one journey.",
    body: "Search Astronomy. Open the learning path. Explore the Knowledge Map. Take the check. Save it to the Personal Atlas. The strongest demo is one complete route, not a tour of every button.",
  },
];

export function PresentationModal() {
  const open = usePanorama((s) => s.presentationOpen);
  const setOpen = usePanorama((s) => s.setPresentationOpen);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
      if (event.key === "ArrowRight" || event.key === "ArrowDown") {
        setIndex((value) => Math.min(SLIDES.length - 1, value + 1));
      }
      if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
        setIndex((value) => Math.max(0, value - 1));
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, setOpen]);

  if (!open) return null;
  const slide = SLIDES[index]!;

  return (
    <div className="fixed inset-0 z-50 bg-bg/95 text-fg backdrop-blur-md">
      <div className="mx-auto flex h-full max-w-5xl flex-col px-5 py-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-primary">
              Project presentation
            </p>
            <p className="font-semibold">Eagles Panorama</p>
          </div>
          <Button variant="secondary" onClick={() => setOpen(false)} aria-label="Close presentation">
            Close
          </Button>
        </div>
        <div className="mt-4 h-1 overflow-hidden rounded-full bg-border">
          <div
            className="h-full bg-primary transition-[width] duration-200"
            style={{ width: `${((index + 1) / SLIDES.length) * 100}%` }}
          />
        </div>
        <div className="flex flex-1 items-center">
          <article className="w-full">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">{slide.kicker}</p>
            <h2 className="mt-4 max-w-4xl font-display text-4xl leading-tight sm:text-5xl">{slide.title}</h2>
            {slide.body ? <p className="mt-5 max-w-3xl text-lg leading-8 text-fg-muted">{slide.body}</p> : null}
            {slide.cards ? (
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {slide.cards.map((card) => (
                  <li key={card} className="rounded-[16px] border border-border bg-bg-elevated p-4 text-fg-muted">
                    {card}
                  </li>
                ))}
              </ul>
            ) : null}
          </article>
        </div>
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
          <Button variant="secondary" disabled={index === 0} onClick={() => setIndex(index - 1)}>
            Previous
          </Button>
          <div className="hidden justify-center gap-1 sm:flex">
            {SLIDES.map((_, dot) => (
              <button
                key={dot}
                type="button"
                aria-label={`Go to slide ${dot + 1}`}
                onClick={() => setIndex(dot)}
                className={dot === index ? "h-2 w-6 rounded-full bg-primary" : "size-2 rounded-full bg-border"}
              />
            ))}
          </div>
          <Button
            className="justify-self-end"
            disabled={index === SLIDES.length - 1}
            onClick={() => setIndex(index + 1)}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}
