import {
  ArrowRight,
  BookOpen,
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  GraduationCap,
} from "lucide-react";
import { useMemo, useState, type ReactNode } from "react";
import { RELATION_COPY, topics } from "@/lib/panorama/catalog";
import {
  classifySource,
  createExplorationPath,
  getDeepKnowledgeContext,
  segmentOverview,
} from "@/lib/panorama/engine";
import type { CheckQuestion } from "@/lib/panorama/engine";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { currentQuestions, isTopicSaved, nextPathStep, usePanorama } from "@/store/panorama";

export function TopicWorkspace() {
  const result = usePanorama((s) => s.result);
  const loading = usePanorama((s) => s.loading);
  const error = usePanorama((s) => s.error);
  const tab = usePanorama((s) => s.tab);
  const setTab = usePanorama((s) => s.setTab);
  const explore = usePanorama((s) => s.explore);
  const saved = usePanorama(isTopicSaved);
  const toggleSavedTopic = usePanorama((s) => s.toggleSavedTopic);
  const next = nextPathStep(result);

  if (!result && !loading) {
    if (error) {
      return (
        <div className="mx-auto mt-8 max-w-3xl rounded-[22px] border border-danger/30 bg-surface p-6 text-ink">
          <h2 className="font-display text-2xl">Could not open that subject</h2>
          <p className="mt-2 text-ink-muted">{error}</p>
        </div>
      );
    }
    return null;
  }

  return (
    <article className="mx-auto mt-8 max-w-5xl rounded-[26px] border border-line bg-surface p-4 text-ink shadow-[0_18px_44px_rgba(4,22,36,0.14)] sm:p-8">
      {loading && (
        <div className="mb-6 flex flex-col items-center gap-3 py-8" role="status" aria-live="polite">
          <div className="flex h-8 items-end gap-1.5">
            <span className="size-2.5 animate-bounce rounded-full bg-primary [animation-delay:-0.2s]" />
            <span className="size-2.5 animate-bounce rounded-full bg-primary [animation-delay:-0.1s]" />
            <span className="size-2.5 animate-bounce rounded-full bg-primary" />
          </div>
          <p className="text-sm text-ink-muted">Opening the landscape around this subject…</p>
        </div>
      )}

      {result && (
        <>
          <header className="flex flex-col gap-5 border-b border-line pb-6 sm:flex-row">
            {result.summary.image ? (
              <img
                src={result.summary.image}
                alt=""
                className="h-36 w-full rounded-[16px] object-cover sm:h-[140px] sm:w-[190px]"
              />
            ) : null}
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-3xl text-ink sm:text-4xl">{result.summary.title}</h2>
              <p className="mt-2 text-ink-muted">{result.summary.description || "Explore this subject."}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {result.localTopic ? <Badge>{result.localTopic.category}</Badge> : null}
                <Badge className="bg-surface-2 text-ink">{result.level}</Badge>
                {result.usedFallback ? (
                  <Badge className="bg-surface-2 text-ink">Curated fallback</Badge>
                ) : null}
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button variant="paper" onClick={toggleSavedTopic}>
                  {saved ? <BookmarkCheck className="size-4" /> : <Bookmark className="size-4" />}
                  {saved ? "Saved" : "Save topic"}
                </Button>
                {next ? (
                  <Button onClick={() => void explore(next)}>
                    Next: {next}
                    <ArrowRight className="size-4" />
                  </Button>
                ) : null}
              </div>
            </div>
          </header>

          {error ? <p className="mt-4 text-sm text-warn">{error}</p> : null}

          <Tabs value={tab} onValueChange={(value) => setTab(value as typeof tab)} className="mt-6">
            <TabsList>
              <TabsTrigger value="understand">Understand</TabsTrigger>
              <TabsTrigger value="connect">Connect</TabsTrigger>
              <TabsTrigger value="verify">Verify</TabsTrigger>
              <TabsTrigger value="sources">Sources</TabsTrigger>
            </TabsList>
            <TabsContent value="understand">
              <UnderstandPanel />
            </TabsContent>
            <TabsContent value="connect">
              <ConnectPanel />
            </TabsContent>
            <TabsContent value="verify">
              <VerifyPanel />
            </TabsContent>
            <TabsContent value="sources">
              <SourcesPanel />
            </TabsContent>
          </Tabs>
        </>
      )}
    </article>
  );
}

function UnderstandPanel() {
  const result = usePanorama((s) => s.result)!;
  const explore = usePanorama((s) => s.explore);
  const segments = segmentOverview(result.localTopic?.overview || result.summary.extract);
  const path =
    result.localTopic?.learningPath[result.level] ||
    result.localTopic?.learningPath.beginner ||
    createExplorationPath(result.summary.title, result.relatedPages, result.level);
  const currentIndex = Math.max(
    0,
    path.findIndex((item) => item.toLowerCase() === result.summary.title.toLowerCase()),
  );

  return (
    <div className="grid gap-5">
      {result.localTopic?.misconception ? (
        <aside className="rounded-[16px] border border-line bg-surface-2 p-4">
          <p className="text-xs font-semibold uppercase tracking-[0.12em] text-ink-muted">
            A common mix-up
          </p>
          <p className="mt-1 leading-6 text-ink">{result.localTopic.misconception}</p>
        </aside>
      ) : null}

      <div className="grid gap-3">
        {segments.map((segment) => (
          <section key={segment.label} className="rounded-[16px] border border-line bg-surface-2 p-4">
            <h3 className="text-sm font-semibold text-ink">{segment.label}</h3>
            <p className="mt-2 leading-7 text-ink-muted">{segment.text}</p>
          </section>
        ))}
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <InfoCard title="Core ideas" body={result.localTopic?.concepts.slice(0, 3).join(" · ") || result.summary.description || "Explore the connected ideas."} />
        <InfoCard title="Start with" body={result.localTopic?.prerequisites.slice(0, 2).join(" · ") || "No curated prerequisites yet."} />
        <InfoCard title="Nearby" body={result.localTopic?.related.slice(0, 3).join(" · ") || result.relatedPages.slice(0, 3).map((p) => p.title).join(" · ") || "Explore nearby ideas."} />
      </div>

      <section>
        <h3 className="font-display text-xl text-ink">Learning path</h3>
        <p className="mt-1 text-sm text-ink-muted">
          One sequence. Click a step to open it. This is a map, not a certified curriculum.
        </p>
        <ol className="mt-4 grid gap-2 sm:grid-cols-5">
          {path.slice(0, 5).map((step, index) => (
            <li key={step}>
              <button
                type="button"
                onClick={() => void explore(step)}
                className={cn(
                  "flex min-h-[86px] w-full flex-col items-start rounded-[14px] border px-3 py-3 text-left",
                  index === currentIndex
                    ? "border-primary bg-primary-soft"
                    : index < currentIndex
                      ? "border-line bg-surface-2"
                      : "border-line bg-surface",
                )}
              >
                <span className="text-xs font-semibold text-ink-muted">{index + 1}</span>
                <span className="mt-1 text-sm font-semibold text-ink">{step}</span>
              </button>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}

function InfoCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-[16px] border border-line bg-surface-2 p-4">
      <h3 className="text-sm font-semibold text-ink">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-ink-muted">{body}</p>
    </div>
  );
}

function ConnectPanel() {
  const result = usePanorama((s) => s.result)!;
  const explore = usePanorama((s) => s.explore);
  const region = getDeepKnowledgeContext(result.localKey, result.summary.title);
  const related = result.localTopic?.related?.length
    ? result.localTopic.related
    : result.relatedPages.map((page) => page.title);

  return (
    <div className="grid gap-6">
      {region ? (
        <section>
          <h3 className="font-display text-xl text-ink">Authored knowledge region</h3>
          <p className="mt-1 text-sm leading-6 text-ink-muted">{region.thesis}</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {region.nodes.map((node) => (
              <button
                key={node.title}
                type="button"
                onClick={() => void explore(node.title)}
                className={cn(
                  "rounded-[16px] border p-4 text-left",
                  node.title.toLowerCase() === result.summary.title.toLowerCase()
                    ? "border-primary bg-primary-soft"
                    : "border-line bg-surface-2",
                )}
              >
                <p className="font-semibold text-ink">{node.title}</p>
                <p className="mt-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-ink-muted">
                  {node.role}
                </p>
                <p className="mt-2 text-sm leading-6 text-ink-muted">{node.why}</p>
              </button>
            ))}
          </div>
          <ul className="mt-4 grid gap-2">
            {region.relations.slice(0, 8).map(([from, to, type, why]) => (
              <li key={`${from}-${to}`} className="rounded-[12px] border-l-2 border-primary bg-surface-2 px-4 py-3">
                <p className="text-sm font-semibold text-ink">
                  {from} → {to}
                  <span className="ml-2 text-xs font-medium uppercase tracking-[0.08em] text-ink-muted">
                    {RELATION_COPY[type]?.label || type}
                  </span>
                </p>
                <p className="mt-1 text-sm text-ink-muted">{why}</p>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-ink-muted">
            These relationships are authored for this prototype. They are deeper than generic related-topic
            links, but they are not a complete map of the field.
          </p>
        </section>
      ) : (
        <p className="text-ink-muted">
          This subject is not in the authored knowledge regions yet. Use the related results as an exploration
          aid, not as a validated curriculum.
        </p>
      )}

      <section>
        <h3 className="font-display text-xl text-ink">Related subjects</h3>
        <div className="mt-3 grid gap-2">
          {related.slice(0, 8).map((title) => (
            <button
              key={title}
              type="button"
              onClick={() => void explore(title)}
              className="flex min-h-12 items-center justify-between rounded-[14px] border border-line bg-surface-2 px-4 text-left font-semibold text-ink"
            >
              {title}
              <ArrowRight className="size-4 text-ink-muted" />
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function VerifyPanel() {
  const result = usePanorama((s) => s.result)!;
  const questions = useMemo(() => currentQuestions(result), [result]);
  const recordEvidence = usePanorama((s) => s.recordEvidence);
  const saveExplanation = usePanorama((s) => s.saveExplanation);
  const saveFeedback = usePanorama((s) => s.saveFeedback);
  const atlas = usePanorama((s) => s.atlas);
  const explore = usePanorama((s) => s.explore);
  const evidence = atlas.find(
    (item) => item.title === result.summary.title && item.language === result.language,
  )?.evidence;
  const [answers, setAnswers] = useState<Record<number, "correct" | "wrong">>({});
  const [explanation, setExplanation] = useState("");
  const [explainResult, setExplainResult] = useState<ReturnType<typeof saveExplanation> | null>(null);
  const [feedback, setFeedback] = useState("");
  const [feedbackNote, setFeedbackNote] = useState("");
  const [feedbackSaved, setFeedbackSaved] = useState(false);
  const score = Object.values(answers).filter((value) => value === "correct").length;
  const answered = Object.keys(answers).length;
  const next = nextPathStep(result);

  if (!questions) {
    return (
      <p className="text-ink-muted">
        This topic does not yet have enough curated data for a full check. Read the overview, then try
        explaining it in your own words after exploring a related subject.
      </p>
    );
  }

  return (
    <div className="grid gap-6">
      <section>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h3 className="font-display text-xl text-ink">Knowledge check</h3>
            <p className="mt-1 text-sm text-ink-muted">
              Reading is not the same as understanding. This is a recall check, not a certificate.
            </p>
          </div>
          <Badge>
            Score {score} / {questions.length}
          </Badge>
        </div>
        <div className="mt-4 grid gap-4">
          {questions.map((question, index) => (
            <QuestionCard
              key={question.prompt}
              index={index}
              question={question}
              state={answers[index]}
              onAnswer={(correct) => {
                if (answers[index]) return;
                const nextAnswers = { ...answers, [index]: correct ? "correct" as const : "wrong" as const };
                setAnswers(nextAnswers);
                const nextScore = Object.values(nextAnswers).filter((value) => value === "correct").length;
                if (Object.keys(nextAnswers).length === questions.length) {
                  recordEvidence(result.summary.title, {
                    score: nextScore,
                    total: questions.length,
                    connectionCompleted: nextAnswers[4] === "correct",
                  });
                }
              }}
            />
          ))}
        </div>
      </section>

      {answered === questions.length ? (
        <section className="rounded-[16px] border border-line bg-surface-2 p-4">
          <h3 className="font-semibold text-ink">Evidence of understanding</h3>
          <p className="mt-1 text-sm text-ink-muted">
            Verified means 4/5 or better, a demonstrated connection, and an explanation that hits at least two
            authored concepts. That is evidence of work, not mastery.
          </p>
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            <InfoCard title="Knowledge check" body={`${score} / ${questions.length}`} />
            <InfoCard title="Connection question" body={answers[4] === "correct" ? "Demonstrated" : "Not yet"} />
            <InfoCard title="Own explanation" body={evidence?.explanationSubmitted ? "Submitted" : "Pending"} />
          </div>
          <label className="mt-4 block text-sm font-semibold text-ink">
            Explain it in your own words
            <textarea
              value={explanation}
              onChange={(event) => setExplanation(event.target.value)}
              className="mt-2 min-h-28 w-full rounded-[12px] border border-line bg-surface p-3 text-sm text-ink outline-none focus:border-primary"
              placeholder="What is the main idea? How does it work, and what does it connect to?"
            />
          </label>
          <Button
            className="mt-3"
            disabled={!explanation.trim()}
            onClick={() => setExplainResult(saveExplanation(result.summary.title, explanation.trim()))}
          >
            Save explanation
          </Button>
          {explainResult ? (
            <p className="mt-3 text-sm text-ink-muted">
              {explainResult.coverage >= 2
                ? "Your explanation included multiple authored concepts. That is useful evidence."
                : "Recorded, but it did not yet contain enough key concepts for verification."}
            </p>
          ) : null}

          <div className="mt-5">
            <p className="text-sm font-semibold text-ink">Did this help you understand the topic?</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {["helpful", "mixed", "not-helpful"].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setFeedback(value)}
                  className={cn(
                    "min-h-10 rounded-full border px-3 text-sm font-semibold",
                    feedback === value
                      ? "border-primary bg-primary-soft text-primary"
                      : "border-line bg-surface text-ink",
                  )}
                >
                  {value === "helpful" ? "Helpful" : value === "mixed" ? "Somewhat" : "Not yet"}
                </button>
              ))}
            </div>
            <textarea
              value={feedbackNote}
              onChange={(event) => setFeedbackNote(event.target.value)}
              className="mt-3 min-h-20 w-full rounded-[12px] border border-line bg-surface p-3 text-sm"
              placeholder="Optional: what confused you, or what helped most?"
            />
            <Button
              className="mt-3"
              variant="paper"
              disabled={!feedback}
              onClick={() => {
                saveFeedback(result.summary.title, feedback, feedbackNote);
                setFeedbackSaved(true);
              }}
            >
              {feedbackSaved ? "Feedback saved locally" : "Save feedback"}
            </Button>
          </div>

          {next ? (
            <Button className="mt-4" onClick={() => void explore(next)}>
              Continue to {next}
            </Button>
          ) : null}
        </section>
      ) : null}
    </div>
  );
}

function QuestionCard({
  index,
  question,
  state,
  onAnswer,
}: {
  index: number;
  question: CheckQuestion;
  state?: "correct" | "wrong";
  onAnswer: (correct: boolean) => void;
}) {
  return (
    <div className="rounded-[16px] border border-line bg-surface p-4">
      <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-primary">
        Question {index + 1}
      </p>
      <h4 className="mt-1 font-semibold text-ink">{question.prompt}</h4>
      <div className="mt-3 grid gap-2">
        {question.options.map((option, optionIndex) => {
          const isCorrect = option === question.correct;
          const chosen = Boolean(state);
          return (
            <button
              key={option}
              type="button"
              disabled={chosen}
              onClick={() => onAnswer(isCorrect)}
              className={cn(
                "flex min-h-12 items-center gap-3 rounded-[12px] border px-3 text-left text-sm",
                chosen && isCorrect
                  ? "border-primary bg-primary-soft text-ink"
                  : chosen && !isCorrect && state === "wrong"
                    ? "border-line bg-surface-2 text-ink"
                    : "border-line bg-surface text-ink",
              )}
            >
              <span className="grid size-7 place-items-center rounded-[8px] border border-line text-xs font-bold">
                {String.fromCharCode(65 + optionIndex)}
              </span>
              {option}
            </button>
          );
        })}
      </div>
      {state ? (
        <p className="mt-3 text-sm text-ink-muted">
          {state === "correct" ? "Correct — keep going." : "Not quite — use the explanation as a clue."}{" "}
          {question.explanation}
        </p>
      ) : null}
    </div>
  );
}

function SourcesPanel() {
  const result = usePanorama((s) => s.result)!;
  const research = usePanorama((s) => s.research);
  const researchLoading = usePanorama((s) => s.researchLoading);
  const toggleSavedBook = usePanorama((s) => s.toggleSavedBook);
  const toggleSavedResource = usePanorama((s) => s.toggleSavedResource);
  const savedBooks = usePanorama((s) => s.savedBooks);
  const savedResources = usePanorama((s) => s.savedResources);
  const curated = result.localKey ? topics[result.localKey]?.resources || [] : [];

  const wikiURL = result.summary.url;
  const bookURL = `https://openlibrary.org/search?q=${encodeURIComponent(result.summary.title)}`;
  const researchURL = `https://openalex.org/works?search=${encodeURIComponent(result.summary.title)}`;
  const scholarURL = `https://www.semanticscholar.org/search?q=${encodeURIComponent(result.summary.title)}`;
  const learnURL = `https://www.khanacademy.org/search?page_search_query=${encodeURIComponent(result.summary.title)}`;

  return (
    <div className="grid gap-6">
      <div className="grid gap-3 sm:grid-cols-2">
        <Lane title="Research" body="Find academic work related to this topic.">
          <a href={researchURL} target="_blank" rel="noopener noreferrer">OpenAlex</a>
          <a href={scholarURL} target="_blank" rel="noopener noreferrer">Semantic Scholar</a>
        </Lane>
        <Lane title="Learn" body="Use structured material when you want to actually study.">
          <a href={learnURL} target="_blank" rel="noopener noreferrer">Khan Academy</a>
          <a href={bookURL} target="_blank" rel="noopener noreferrer">Open Library</a>
        </Lane>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <article className="rounded-[16px] border border-line bg-surface-2 p-4">
          <p className="text-xs font-semibold uppercase tracking-[0.08em] text-ink-muted">Reference</p>
          <h4 className="mt-2 font-semibold">Wikipedia — {result.summary.title}</h4>
          <p className="mt-1 text-sm text-ink-muted">Definitions, context, citations, and linked concepts.</p>
          <a
            className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary"
            href={wikiURL}
            target="_blank"
            rel="noopener noreferrer"
          >
            Open reference <ExternalLink className="size-3.5" />
          </a>
        </article>
        {curated.map((resource) => {
          const type = classifySource(resource.url, resource.name);
          const saved = savedResources.some((item) => item.url === resource.url);
          return (
            <article key={resource.url} className="rounded-[16px] border border-line bg-surface-2 p-4">
              <p className="text-xs font-semibold uppercase tracking-[0.08em] text-ink-muted">{type.label}</p>
              <h4 className="mt-2 font-semibold">{resource.name}</h4>
              <p className="mt-1 text-sm text-ink-muted">{type.why}</p>
              <div className="mt-3 flex items-center justify-between gap-2">
                <a
                  className="inline-flex items-center gap-1 text-sm font-semibold text-primary"
                  href={resource.url}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Open source <ExternalLink className="size-3.5" />
                </a>
                <Button
                  size="sm"
                  variant="paper"
                  onClick={() =>
                    toggleSavedResource({
                      name: resource.name,
                      url: resource.url,
                      topic: result.summary.title,
                    })
                  }
                >
                  {saved ? "Saved" : "Save"}
                </Button>
              </div>
            </article>
          );
        })}
      </div>

      <section>
        <h3 className="inline-flex items-center gap-2 font-display text-xl text-ink">
          <BookOpen className="size-5" /> Public learning library
        </h3>
        {result.books.length === 0 ? (
          <p className="mt-2 text-sm text-ink-muted">No publicly readable books were found for this search.</p>
        ) : (
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {result.books.map((book) => {
              const saved = savedBooks.some((item) => item.url === book.url);
              return (
                <article key={book.url} className="flex gap-3 rounded-[16px] border border-line bg-surface-2 p-3">
                  {book.cover ? (
                    <img src={book.cover} alt="" className="h-[110px] w-[76px] rounded-[8px] object-cover" />
                  ) : (
                    <div className="h-[110px] w-[76px] rounded-[8px] bg-line" />
                  )}
                  <div className="min-w-0">
                    <h4 className="font-semibold">{book.title}</h4>
                    <p className="text-sm text-ink-muted">{book.author}</p>
                    <p className="text-xs text-ink-muted">First published: {book.year}</p>
                    <a className="mt-2 inline-block text-sm font-semibold text-primary" href={book.url} target="_blank" rel="noopener noreferrer">
                      Explore book
                    </a>
                    <Button
                      size="sm"
                      variant="paper"
                      className="ml-2"
                      onClick={() => toggleSavedBook({ ...book, topic: result.summary.title })}
                    >
                      {saved ? "Saved" : "Save"}
                    </Button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      <section>
        <h3 className="inline-flex items-center gap-2 font-display text-xl text-ink">
          <GraduationCap className="size-5" /> Live research
        </h3>
        {researchLoading ? (
          <p className="mt-2 text-sm text-ink-muted">Searching recent research sources…</p>
        ) : research.length === 0 ? (
          <p className="mt-2 text-sm text-ink-muted">
            No live research results were found. The source links above are still available.
          </p>
        ) : (
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {research.map((work) => (
              <article key={work.url} className="rounded-[16px] border border-line bg-surface-2 p-4">
                <p className="text-xs font-semibold text-primary">
                  {work.year} · {work.venue}
                </p>
                <h4 className="mt-1 font-semibold">{work.title}</h4>
                <a className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-primary" href={work.url} target="_blank" rel="noopener noreferrer">
                  Read research <ExternalLink className="size-3.5" />
                </a>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function Lane({
  title,
  body,
  children,
}: {
  title: string;
  body: string;
  children: ReactNode;
}) {
  return (
    <div className="rounded-[16px] border border-line bg-surface-2 p-4">
      <h4 className="font-semibold text-ink">{title}</h4>
      <p className="mt-1 text-sm text-ink-muted">{body}</p>
      <div className="mt-3 flex flex-wrap gap-2 [&_a]:rounded-[10px] [&_a]:border [&_a]:border-line [&_a]:bg-surface [&_a]:px-3 [&_a]:py-2 [&_a]:text-sm [&_a]:font-semibold [&_a]:text-ink">
        {children}
      </div>
    </div>
  );
}


