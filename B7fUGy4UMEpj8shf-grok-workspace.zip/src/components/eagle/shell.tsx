import { Compass, Map, UserRound } from "lucide-react";
import { useEffect, useRef, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { SUPPORTED_LANGUAGES } from "@/lib/panorama/catalog";
import { topicCategories } from "@/lib/panorama/engine";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { usePanorama } from "@/store/panorama";
import { KnowledgeMap } from "./knowledge-map";
import { LearningAtlas } from "./learning";
import { PresentationModal } from "./presentation";
import { TopicWorkspace } from "./workspace";

export function AppChrome({ children }: { children: ReactNode }) {
  const hydrate = usePanorama((s) => s.hydrate);
  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <div className="min-h-screen bg-bg text-fg">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_15%_10%,rgba(31,154,147,0.16),transparent_28%),radial-gradient(circle_at_88%_0%,rgba(180,210,220,0.08),transparent_24%)]" />
      <TopBar />
      <div className="relative z-10">{children}</div>
      <PresentationModal />
    </div>
  );
}

function TopBar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const language = usePanorama((s) => s.language);
  const setLanguage = usePanorama((s) => s.setLanguage);
  const setPresentationOpen = usePanorama((s) => s.setPresentationOpen);
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-30 border-b border-border/80 bg-bg/85 px-3 py-3 backdrop-blur-md sm:px-6">
      <div className="mx-auto flex max-w-6xl min-w-0 flex-wrap items-center gap-2">
        <Link to="/" className="mr-auto flex min-h-11 items-center gap-2">
          <span className="grid size-8 place-items-center rounded-[10px] bg-primary text-xs font-bold text-primary-fg">
            EP
          </span>
          <span className="hidden font-display text-lg sm:block">Eagles Panorama</span>
        </Link>
        <NavLink to="/" active={pathname === "/"}>
          <Compass className="size-4" />
          <span className="hidden sm:inline">Explore</span>
        </NavLink>
        <NavLink to="/map" active={pathname === "/map"}>
          <Map className="size-4" />
          <span className="hidden sm:inline">Map</span>
        </NavLink>
        <NavLink to="/learning" active={pathname === "/learning"}>
          <UserRound className="size-4" />
          <span className="hidden sm:inline">Learning</span>
        </NavLink>
        <Button variant="secondary" size="sm" className="hidden min-[420px]:inline-flex" onClick={() => setPresentationOpen(true)}>
          Project
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="sm:hidden"
          onClick={() => setPresentationOpen(true)}
        >
          Project
        </Button>
        <label className="sr-only" htmlFor="languageSelect">
          Language
        </label>
        <select
          id="languageSelect"
          value={language}
          onChange={(event) => setLanguage(event.target.value)}
          className="h-11 w-[4.8rem] min-w-0 max-w-[4.8rem] shrink-0 rounded-[12px] border border-border bg-bg-elevated px-1 text-xs text-fg sm:w-auto sm:max-w-none sm:px-2 sm:text-sm"
        >
          {SUPPORTED_LANGUAGES.map((item) => (
            <option key={item.code} value={item.code}>
              {item.label}
            </option>
          ))}
        </select>
      </div>
    </header>
  );
}

function NavLink({
  to,
  active,
  children,
}: {
  to: "/" | "/map" | "/learning";
  active: boolean;
  children: ReactNode;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "inline-flex min-h-11 items-center gap-2 rounded-[12px] px-3 text-sm font-semibold",
        active ? "bg-bg-subtle text-fg" : "text-fg-muted hover:bg-bg-subtle hover:text-fg",
      )}
    >
      {children}
    </Link>
  );
}

export function ExploreHome() {
  const query = usePanorama((s) => s.query);
  const setQuery = usePanorama((s) => s.setQuery);
  const loadSuggestions = usePanorama((s) => s.loadSuggestions);
  const suggestions = usePanorama((s) => s.suggestions);
  const clearSuggestions = usePanorama((s) => s.clearSuggestions);
  const explore = usePanorama((s) => s.explore);
  const loading = usePanorama((s) => s.loading);
  const level = usePanorama((s) => s.level);
  const setLevel = usePanorama((s) => s.setLevel);
  const language = usePanorama((s) => s.language);
  const atlas = usePanorama((s) => s.atlas);
  const inputRef = useRef<HTMLInputElement>(null);
  const categories = topicCategories(language);
  const continueTitle = atlas[0]?.title;

  return (
    <main>
      <section className="px-4 pb-8 pt-14 text-center sm:pt-20">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">
          Welcome to the knowledge landscape
        </p>
        <h1 className="mx-auto mt-5 max-w-4xl font-display text-4xl leading-tight sm:text-6xl">
          Take a step back.
          <span className="block text-primary">See the bigger picture.</span>
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-base leading-7 text-fg-muted sm:text-lg">
          Search a subject, see what it depends on, follow a path, and check whether you actually understood it.
        </p>

        <form
          className="relative mx-auto mt-8 w-full max-w-3xl"
          onSubmit={(event) => {
            event.preventDefault();
            clearSuggestions();
            void explore(query);
          }}
        >
          <div className="flex flex-col gap-2 rounded-[20px] border border-border bg-bg-elevated p-2 sm:flex-row">
            <Input
              ref={inputRef}
              id="searchInput"
              value={query}
              onChange={(event) => loadSuggestions(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  clearSuggestions();
                  void explore(query);
                }
              }}
              placeholder="What do you want to learn?"
              autoComplete="off"
              className="h-12 flex-1"
            />
            <select
              value={level}
              onChange={(event) => setLevel(event.target.value as typeof level)}
              className="h-12 rounded-[12px] border border-line bg-surface px-3 text-ink"
              aria-label="Learning level"
            >
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
            <Button type="submit" disabled={loading} className="h-12 min-w-28">
              {loading ? "Exploring" : "Explore"}
            </Button>
          </div>
          {suggestions.length > 0 ? (
            <div
              id="suggestions"
              className="absolute left-0 right-0 top-[calc(100%+8px)] z-20 max-h-[min(360px,55vh)] overflow-y-auto rounded-[12px] border border-line bg-surface text-left shadow-lg"
            >
              {suggestions.map((title) => (
                <button
                  key={title}
                  type="button"
                  className="block w-full px-4 py-3 text-left text-ink hover:bg-surface-2"
                  onClick={() => {
                    setQuery(title);
                    clearSuggestions();
                    void explore(title);
                  }}
                >
                  {title}
                </button>
              ))}
            </div>
          ) : null}
        </form>

        <div className="mt-4 flex flex-wrap justify-center gap-2">
          {["Astronomy", "Physics", "History", "Philosophy", "Mathematics"].map((title) => (
            <button
              key={title}
              type="button"
              onClick={() => {
                setQuery(title);
                void explore(title);
              }}
              className="min-h-10 rounded-full border border-border bg-bg-elevated px-3 text-sm text-fg-muted hover:text-fg"
            >
              Try {title}
            </button>
          ))}
          {continueTitle ? (
            <button
              type="button"
              onClick={() => {
                setQuery(continueTitle);
                void explore(continueTitle);
              }}
              className="min-h-10 rounded-full border border-primary/40 bg-primary/10 px-3 text-sm text-primary"
            >
              Continue {continueTitle}
            </button>
          ) : null}
        </div>
      </section>

      <TopicWorkspace />

      <section id="about" className="mx-auto mt-16 max-w-5xl px-4">
        <div className="rounded-[24px] border border-border bg-bg-elevated p-6 sm:p-8">
          <h2 className="font-display text-3xl">About Eagles Panorama</h2>
          <p className="mt-3 max-w-3xl leading-7 text-fg-muted">
            A learning explorer for seeing the landscape around a subject — not just a page of facts. Curated
            paths and authored relationships sit beside live public sources. Personal progress stays in this
            browser.
          </p>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <AboutCard
              title="Curated knowledge"
              body="Core subjects include levels, concepts, prerequisites, related subjects, and an authored relationship model."
            />
            <AboutCard
              title="Live sources"
              body="Wikipedia, Open Library, and OpenAlex extend the built-in catalog. If live search fails, curated topics still open."
            />
            <AboutCard
              title="Evidence, not theater"
              body="A quiz score is only one signal. Verification also needs a connection and an explanation in your own words."
            />
          </div>
        </div>
      </section>

      <section className="mx-auto mt-14 max-w-5xl px-4 pb-24">
        <h2 className="font-display text-3xl">Explore a world of knowledge</h2>
        <p className="mt-2 text-fg-muted">Start from a field, then keep moving through connected ideas.</p>
        <div className="mt-6 grid gap-4">
          {categories.map((group) => (
            <div key={group.category} className="rounded-[20px] border border-border bg-bg-elevated p-5">
              <h3 className="text-lg font-semibold">{group.category}</h3>
              <div className="mt-3 flex flex-wrap gap-2">
                {group.items.map((item) => (
                  <button
                    key={item.key}
                    type="button"
                    className="min-h-11 rounded-[12px] border border-border bg-bg-subtle px-4 text-sm font-semibold text-fg"
                    onClick={() => {
                      setQuery(item.title);
                      void explore(item.title);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                  >
                    {item.title}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}

function AboutCard({ title, body }: { title: string; body: string }) {
  return (
    <article className="rounded-[16px] border border-border bg-bg-subtle p-4">
      <h3 className="font-semibold">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-fg-muted">{body}</p>
    </article>
  );
}

export function MapPage() {
  const result = usePanorama((s) => s.result);
  const perspective = usePanorama((s) => s.mapPerspective);
  const setMapPerspective = usePanorama((s) => s.setMapPerspective);
  const explore = usePanorama((s) => s.explore);
  const navigate = useNavigate();

  return (
    <main className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-4xl">Knowledge Map</h1>
          <p className="mt-2 max-w-2xl text-fg-muted">
            A brighter map board, not a star chart. Click a node to open that subject in the learning space.
          </p>
        </div>
        <Button variant="secondary" onClick={() => void navigate({ to: "/" })}>
          Back to learning
        </Button>
      </div>
      <KnowledgeMap
        result={result}
        perspective={perspective}
        onPerspective={setMapPerspective}
        onOpen={(title) => {
          void explore(title);
          void navigate({ to: "/" });
        }}
      />
    </main>
  );
}

export function LearningPage() {
  const explore = usePanorama((s) => s.explore);
  const setQuery = usePanorama((s) => s.setQuery);
  const navigate = useNavigate();
  return (
    <LearningAtlas
      onOpen={(title) => {
        setQuery(title);
        void explore(title);
        void navigate({ to: "/" });
      }}
    />
  );
}


