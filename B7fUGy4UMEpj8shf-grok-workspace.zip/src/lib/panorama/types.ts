export type LearningLevel = "beginner" | "intermediate" | "advanced";

export type AtlasStatus = "explored" | "learning" | "mastered" | "verified";

export type RelationType =
  | "foundation"
  | "path"
  | "connected"
  | "broader"
  | "causal"
  | "application"
  | "method"
  | "contrast"
  | "discovery";

export type WorkspaceTab = "understand" | "connect" | "verify" | "sources";

export type MapPerspective = "out" | "nearby" | "in";

export interface LocalizedTopic {
  title: string;
  category: string;
  overview: string;
  misconception: string;
  prerequisites: string[];
  learningPath: Record<LearningLevel, string[]>;
  concepts: string[];
  related: string[];
}

export interface TopicResource {
  name: string;
  url: string;
}

export interface TopicRecord {
  aliases: Record<string, string[]>;
  translations: Record<string, LocalizedTopic>;
  resources: TopicResource[];
}

export interface DeepNode {
  title: string;
  role: string;
  why: string;
  keywords: string[];
}

export type DeepRelation = [string, string, RelationType, string];

export interface DeepRegion {
  title: string;
  thesis: string;
  nodes: DeepNode[];
  relations: DeepRelation[];
}

export interface WikiSummary {
  title: string;
  description: string;
  extract: string;
  url: string;
  image?: string;
}

export interface WikiPage {
  title: string;
  description?: string;
  excerpt?: string;
}

export interface BookResult {
  title: string;
  author: string;
  year: string;
  url: string;
  cover: string;
}

export interface ResearchWork {
  title: string;
  year: string;
  venue: string;
  url: string;
}

export interface AtlasEvidence {
  score?: number;
  total?: number;
  explanationSubmitted?: boolean;
  connectionCompleted?: boolean;
  explanationText?: string;
  explanationCoverage?: number;
  matchedConcepts?: string[];
  lastChecked?: number;
}

export interface AtlasItem {
  title: string;
  language: string;
  status: AtlasStatus;
  firstSeen: number;
  lastSeen: number;
  visits: number;
  evidence?: AtlasEvidence;
}

export interface SavedTopic {
  title: string;
  description: string;
  url: string;
  image: string;
  category: string;
  language: string;
  level: LearningLevel;
  query: string;
}

export interface SavedLink {
  name?: string;
  title?: string;
  author?: string;
  year?: string;
  url: string;
  cover?: string;
  topic?: string;
  language?: string;
}

export interface RecentSearch {
  query: string;
  pageTitle: string;
  level: LearningLevel;
  language: string;
  timestamp: number;
}

export interface MapNode {
  title: string;
  type: RelationType | "current";
  key?: string | null;
  x: number;
  y: number;
  explanation: string;
}

export interface TopicResult {
  query: string;
  level: LearningLevel;
  language: string;
  summary: WikiSummary;
  relatedPages: WikiPage[];
  localKey: string | null;
  localTopic: LocalizedTopic | null;
  books: BookResult[];
  fetchedAt: number;
  usedFallback: boolean;
}
