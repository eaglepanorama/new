import {
  deepKnowledgeRegions,
  knowledgeMapParents,
  relationshipExplanation,
  topics,
} from "./catalog";
import type {
  BookResult,
  DeepRegion,
  LearningLevel,
  LocalizedTopic,
  MapNode,
  MapPerspective,
  RelationType,
  ResearchWork,
  WikiPage,
  WikiSummary,
} from "./types";

const STOP = new Set([
  "a", "an", "the", "what", "is", "are", "of", "about", "tell", "me", "learn",
  "to", "introduction", "intro", "basics", "basic", "que", "es", "son", "del",
  "de", "la", "el", "los", "las", "una", "un", "sobre", "para", "ce", "l",
  "les", "des", "et", "ou",
]);

const wikiCache = new Map<string, { at: number; value: unknown }>();
const CACHE_MS = 12 * 60 * 1000;

function cacheGet<T>(key: string): T | null {
  const hit = wikiCache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > CACHE_MS) {
    wikiCache.delete(key);
    return null;
  }
  return hit.value as T;
}

function cacheSet(key: string, value: unknown) {
  wikiCache.set(key, { at: Date.now(), value });
}

export function normalizeText(value: string): string {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function searchTokens(text: string): string[] {
  return normalizeText(text)
    .split(" ")
    .filter(Boolean)
    .map((token) => (token.length > 4 && token.endsWith("s") ? token.slice(0, -1) : token))
    .filter((token) => !STOP.has(token));
}

export function getLocalizedTopic(topicKey: string, language: string): LocalizedTopic | null {
  const topic = topics[topicKey];
  if (!topic) return null;
  return topic.translations[language] || topic.translations.en || null;
}

export function findTopicKey(query: string): string | null {
  const normalizedQuery = normalizeText(query);
  const simplifiedQuery = searchTokens(query).join(" ");
  const queryTokens = searchTokens(query);
  let bestMatch: string | null = null;
  let bestScore = 0;

  for (const topicKey of Object.keys(topics)) {
    const topic = topics[topicKey];
    const candidates: string[] = [];
    Object.values(topic.aliases).forEach((list) => candidates.push(...list));
    Object.values(topic.translations).forEach((translation) => {
      if (translation?.title) candidates.push(translation.title);
    });

    for (const candidate of candidates) {
      const normalizedCandidate = normalizeText(candidate);
      const candidateTokens = searchTokens(candidate);
      const candidateSimplified = candidateTokens.join(" ");
      if (!normalizedCandidate) continue;
      if (normalizedCandidate === normalizedQuery) return topicKey;
      if (candidateSimplified && candidateSimplified === simplifiedQuery) return topicKey;
      if (
        simplifiedQuery &&
        (candidateSimplified.includes(simplifiedQuery) || simplifiedQuery.includes(candidateSimplified))
      ) {
        const substringScore = Math.min(
          1,
          simplifiedQuery.length / Math.max(candidateSimplified.length, 1),
        );
        if (substringScore > bestScore) {
          bestScore = substringScore;
          bestMatch = topicKey;
        }
      }
      if (queryTokens.length === 1 && candidateTokens.includes(queryTokens[0]!)) {
        return topicKey;
      }
    }
  }
  return bestScore >= 0.72 ? bestMatch : null;
}

export function getDeepKnowledgeContext(localKey: string | null, centerTitle: string): DeepRegion | null {
  if (localKey && deepKnowledgeRegions[localKey]) return deepKnowledgeRegions[localKey];
  const wanted = normalizeText(centerTitle);
  for (const candidate of Object.values(deepKnowledgeRegions)) {
    if (candidate.nodes.some((node) => normalizeText(node.title) === wanted)) return candidate;
  }
  return null;
}

function wikiBase(language: string) {
  const lang = language || "en";
  return `https://${lang}.wikipedia.org`;
}

async function fetchJson<T>(url: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(url, {
    signal,
    headers: { Accept: "application/json" },
  });
  if (!response.ok) {
    throw new Error(`Source request failed (${response.status})`);
  }
  return response.json() as Promise<T>;
}

export async function searchWikipedia(
  query: string,
  language: string,
  signal?: AbortSignal,
): Promise<WikiPage[]> {
  const key = `search:${language}:${normalizeText(query)}`;
  const cached = cacheGet<WikiPage[]>(key);
  if (cached) return cached;

  const restUrl = `${wikiBase(language)}/w/rest.php/v1/search/page?q=${encodeURIComponent(query)}&limit=8`;
  try {
    const data = await fetchJson<{ pages?: Array<{ title: string; description?: string; excerpt?: string }> }>(
      restUrl,
      signal,
    );
    const pages = (data.pages || [])
      .filter((page) => page.title)
      .map((page) => ({
        title: page.title,
        description: page.description,
        excerpt: page.excerpt?.replace(/<[^>]+>/g, ""),
      }));
    cacheSet(key, pages);
    return pages;
  } catch (error) {
    if (signal?.aborted) throw error;
    const fallbackUrl =
      `${wikiBase(language)}/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}` +
      `&srlimit=8&format=json&origin=*`;
    const data = await fetchJson<{ query?: { search?: Array<{ title: string; snippet?: string }> } }>(
      fallbackUrl,
      signal,
    );
    const pages = (data.query?.search || []).map((item) => ({
      title: item.title,
      excerpt: item.snippet?.replace(/<[^>]+>/g, ""),
    }));
    cacheSet(key, pages);
    return pages;
  }
}

export async function getWikipediaSummary(
  title: string,
  language: string,
  signal?: AbortSignal,
): Promise<WikiSummary> {
  const key = `sum:${language}:${normalizeText(title)}`;
  const cached = cacheGet<WikiSummary>(key);
  if (cached) return cached;

  const url = `${wikiBase(language)}/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
  try {
    const data = await fetchJson<{
      title: string;
      description?: string;
      extract?: string;
      content_urls?: { desktop?: { page?: string } };
      thumbnail?: { source?: string };
    }>(url, signal);
    const summary: WikiSummary = {
      title: data.title,
      description: data.description || "",
      extract: data.extract || "",
      url: data.content_urls?.desktop?.page || `${wikiBase(language)}/wiki/${encodeURIComponent(data.title)}`,
      image: data.thumbnail?.source,
    };
    cacheSet(key, summary);
    return summary;
  } catch (error) {
    if (signal?.aborted) throw error;
    const api =
      `${wikiBase(language)}/w/api.php?action=query&prop=extracts|info&exintro=1&explaintext=1` +
      `&inprop=url&format=json&origin=*&titles=${encodeURIComponent(title)}`;
    const data = await fetchJson<{
      query?: { pages?: Record<string, { title?: string; extract?: string; fullurl?: string }> };
    }>(api, signal);
    const page = Object.values(data.query?.pages || {})[0];
    if (!page?.title) throw error;
    const summary: WikiSummary = {
      title: page.title,
      description: "",
      extract: page.extract || "",
      url: page.fullurl || `${wikiBase(language)}/wiki/${encodeURIComponent(page.title)}`,
    };
    cacheSet(key, summary);
    return summary;
  }
}

export async function getExpandedIntro(
  title: string,
  language: string,
  signal?: AbortSignal,
): Promise<string> {
  const key = `intro:${language}:${normalizeText(title)}`;
  const cached = cacheGet<string>(key);
  if (cached) return cached;
  try {
    const url =
      `${wikiBase(language)}/w/api.php?action=query&prop=extracts&explaintext=1&exintro=1&format=json&origin=*` +
      `&titles=${encodeURIComponent(title)}`;
    const data = await fetchJson<{
      query?: { pages?: Record<string, { extract?: string }> };
    }>(url, signal);
    const extract = Object.values(data.query?.pages || {})[0]?.extract?.trim() || "";
    cacheSet(key, extract);
    return extract;
  } catch {
    return "";
  }
}

export async function getBooks(topic: string, signal?: AbortSignal): Promise<BookResult[]> {
  const key = `books:${normalizeText(topic)}`;
  const cached = cacheGet<BookResult[]>(key);
  if (cached) return cached;
  try {
    const url =
      "https://openlibrary.org/search.json?q=" +
      encodeURIComponent(`${topic} ebook_access:public`) +
      "&fields=title,author_name,first_publish_year,key,cover_i&limit=4";
    const data = await fetchJson<{
      docs?: Array<{
        title?: string;
        author_name?: string[];
        first_publish_year?: number;
        key?: string;
        cover_i?: number;
      }>;
    }>(url, signal);
    const books = (data.docs || []).map((book) => {
      const workKey = book.key ? book.key.replace("/works/", "") : "";
      return {
        title: book.title || "Untitled book",
        author: book.author_name?.[0] || "Unknown author",
        year: book.first_publish_year ? String(book.first_publish_year) : "Unknown year",
        url: workKey ? `https://openlibrary.org/works/${workKey}` : "https://openlibrary.org/",
        cover: book.cover_i ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` : "",
      };
    });
    cacheSet(key, books);
    return books;
  } catch {
    return [];
  }
}

export async function getResearch(topic: string, signal?: AbortSignal): Promise<ResearchWork[]> {
  const key = `research:${normalizeText(topic)}`;
  const cached = cacheGet<ResearchWork[]>(key);
  if (cached) return cached;
  try {
    const url = `https://api.openalex.org/works?search=${encodeURIComponent(topic)}&per-page=4&sort=relevance_score:desc`;
    const data = await fetchJson<{
      results?: Array<{
        title?: string;
        doi?: string;
        publication_year?: number;
        primary_location?: { landing_page_url?: string; source?: { display_name?: string } };
      }>;
    }>(url, signal);
    const works = (data.results || [])
      .filter((work) => work.title)
      .map((work) => ({
        title: work.title || "",
        year: work.publication_year ? String(work.publication_year) : "Year unknown",
        venue: work.primary_location?.source?.display_name || "Research work",
        url:
          work.doi ||
          work.primary_location?.landing_page_url ||
          `https://openalex.org/works?search=${encodeURIComponent(topic)}`,
      }));
    cacheSet(key, works);
    return works;
  } catch {
    return [];
  }
}

export function segmentOverview(overview: string): { label: string; text: string }[] {
  const clean = String(overview || "").replace(/\s+/g, " ").trim();
  if (!clean) return [];
  const sentences = clean.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [clean];
  const groups: string[] = [];
  let current = "";
  for (const sentence of sentences) {
    const part = sentence.trim();
    if (!part) continue;
    if (current && current.length + part.length + 1 > 230) {
      groups.push(current);
      current = part;
    } else {
      current = current ? `${current} ${part}` : part;
    }
  }
  if (current) groups.push(current);
  const labels = ["The big picture", "What it studies", "Why it matters", "In context"];
  return groups.slice(0, 4).map((text, index) => ({
    label: labels[index] || "More",
    text,
  }));
}

export function createExplorationPath(
  mainTitle: string,
  relatedPages: WikiPage[],
  level: LearningLevel,
): string[] {
  const path = [mainTitle, ...relatedPages.slice(0, 4).map((page) => page.title)];
  const count = level === "advanced" ? 5 : level === "intermediate" ? 4 : 3;
  return path.slice(0, count);
}

function addUnique(
  groups: Record<string, Array<{ title: string; type: RelationType; key: string | null }>>,
  title: string,
  type: RelationType,
  centerNorm: string,
) {
  const clean = String(title || "").trim();
  const norm = normalizeText(clean);
  if (!norm || norm === centerNorm) return;
  const existing = Object.values(groups).flat();
  if (existing.some((item) => normalizeText(item.title) === norm)) return;
  groups[type].push({ title: clean, type, key: findTopicKey(clean) });
}

export function buildKnowledgeGraph(options: {
  localTopic: LocalizedTopic | null;
  localKey: string | null;
  level: LearningLevel;
  relatedPages: WikiPage[];
  centerTitle: string;
  perspective: MapPerspective;
}): { center: MapNode; nodes: MapNode[]; outer: MapNode[] } {
  const { localTopic, localKey, level, relatedPages, centerTitle, perspective } = options;
  const centerNorm = normalizeText(centerTitle);
  const groups: Record<string, Array<{ title: string; type: RelationType; key: string | null }>> = {
    foundation: [],
    path: [],
    connected: [],
    broader: [],
    causal: [],
    application: [],
    method: [],
    contrast: [],
  };

  if (localTopic) {
    (localTopic.prerequisites || []).slice(0, 5).forEach((item) => addUnique(groups, item, "foundation", centerNorm));
    const learningPath = localTopic.learningPath?.[level] || localTopic.learningPath?.beginner || [];
    learningPath.slice(0, 6).forEach((item) => addUnique(groups, item, "path", centerNorm));
    (localTopic.related || []).slice(0, 7).forEach((item) => addUnique(groups, item, "connected", centerNorm));
    if (localTopic.category) addUnique(groups, localTopic.category, "broader", centerNorm);
    const deep = getDeepKnowledgeContext(localKey, centerTitle);
    if (deep) {
      deep.relations
        .filter(
          ([from, to]) => normalizeText(from) === centerNorm || normalizeText(to) === centerNorm,
        )
        .forEach(([from, to, type]) => {
          const target = normalizeText(from) === centerNorm ? to : from;
          const mapped: RelationType = ["causal", "application", "method", "contrast"].includes(type)
            ? type
            : "connected";
          addUnique(groups, target, mapped, centerNorm);
        });
    }
  } else {
    relatedPages.slice(0, 10).forEach((page) => addUnique(groups, page.title, "connected", centerNorm));
  }

  if (perspective === "out") {
    const parents = (localKey && knowledgeMapParents[localKey]) || [];
    parents.forEach((item) => addUnique(groups, item, "broader", centerNorm));
  }

  let selected =
    perspective === "in"
      ? [...groups.foundation, ...groups.path, ...groups.causal, ...groups.application, ...groups.method]
      : perspective === "out"
        ? [...groups.broader, ...groups.connected, ...groups.application, ...groups.causal]
        : [...groups.foundation, ...groups.path, ...groups.connected, ...groups.broader];

  if (perspective === "nearby" && selected.length < 5) {
    const fallback = [
      ...groups.connected,
      ...groups.path,
      ...groups.foundation,
      ...groups.causal,
      ...groups.application,
      ...groups.method,
      ...groups.broader,
    ];
    fallback.forEach((item) => {
      if (selected.length >= 10) return;
      if (!selected.some((existing) => normalizeText(existing.title) === normalizeText(item.title))) {
        selected.push(item);
      }
    });
  }

  const seen = new Set([centerNorm]);
  const unique = selected.filter((item) => {
    const norm = normalizeText(item.title);
    if (!norm || seen.has(norm)) return false;
    seen.add(norm);
    return true;
  }).slice(0, 12);

  const center = { x: 700, y: 390 };
  const radius = unique.length <= 6 ? 230 : 280;
  const nodes: MapNode[] = unique.map((relation, index) => {
    const angle = -Math.PI / 2 + (index * Math.PI * 2) / Math.max(unique.length, 1);
    return {
      title: relation.title,
      type: relation.type,
      key: relation.key,
      x: center.x + Math.cos(angle) * radius,
      y: center.y + Math.sin(angle) * radius,
      explanation: relationshipExplanation(relation.type, centerTitle, relation.title),
    };
  });

  const outer: MapNode[] = [];
  if (perspective === "nearby" && localTopic) {
    const outerSeen = new Set([centerNorm, ...nodes.map((node) => normalizeText(node.title))]);
    nodes.forEach((parent, index) => {
      if (!parent.key || outer.length >= 8) return;
      const child = getLocalizedTopic(parent.key, "en");
      (child?.related || []).slice(0, 2).forEach((title) => {
        const norm = normalizeText(title);
        if (!norm || outerSeen.has(norm) || outer.length >= 8) return;
        outerSeen.add(norm);
        const angle = -Math.PI / 2 + (index * Math.PI * 2) / Math.max(nodes.length, 1) + 0.25;
        outer.push({
          title,
          type: "discovery",
          key: findTopicKey(title),
          x: center.x + Math.cos(angle) * 420,
          y: center.y + Math.sin(angle) * 420,
          explanation: relationshipExplanation("discovery", centerTitle, title),
        });
      });
    });
  }

  return {
    center: {
      title: centerTitle,
      type: "current",
      x: center.x,
      y: center.y,
      explanation: `${centerTitle} is the current subject.`,
    },
    nodes,
    outer,
  };
}

export function wrapNodeTitle(title: string, maxLength = 16): string[] {
  const words = String(title || "").split(/\s+/);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    if (!current) {
      current = word;
    } else if ((current + " " + word).length <= maxLength) {
      current += ` ${word}`;
    } else {
      lines.push(current);
      current = word;
    }
  }
  if (current) lines.push(current);
  return lines.slice(0, 3);
}

function shuffle<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j]!, copy[i]!];
  }
  return copy;
}

export interface CheckQuestion {
  prompt: string;
  options: string[];
  correct: string;
  explanation: string;
}

export function buildKnowledgeCheck(
  localTopic: LocalizedTopic,
  level: LearningLevel,
  relatedPages: WikiPage[],
  currentTitle: string,
): CheckQuestion[] | null {
  const path = localTopic.learningPath[level] || localTopic.learningPath.beginner || [];
  const concepts = (localTopic.concepts || []).filter(Boolean);
  const prerequisites = (localTopic.prerequisites || []).filter(Boolean);
  if (!concepts.length || !prerequisites.length || path.length < 2) return null;

  const otherConcepts: string[] = [];
  Object.keys(topics).forEach((key) => {
    const candidate = getLocalizedTopic(key, "en");
    if (!candidate || candidate.title === localTopic.title) return;
    (candidate.concepts || []).forEach((item) => {
      if (item && !otherConcepts.includes(item)) otherConcepts.push(item);
    });
  });
  const related = relatedPages.map((item) => item.title).filter(Boolean);
  const nextIndex = Math.max(
    1,
    path.findIndex((item) => normalizeText(item) === normalizeText(currentTitle)) + 1,
  );
  const nextStep = path[nextIndex] || path[1]!;
  const conceptOptions = shuffle(
    [concepts[0]!, ...otherConcepts.filter((item) => !concepts.includes(item)).slice(0, 2)],
  ).slice(0, 3);
  const nextOptions = shuffle(
    [nextStep, ...path.filter((item) => item !== nextStep && item !== currentTitle).slice(0, 2)],
  ).slice(0, 3);
  const prereqOptions = shuffle(
    [
      prerequisites[0]!,
      ...[...related, ...path.slice(2)].filter((item) => item && !prerequisites.includes(item)).slice(0, 2),
    ],
  ).slice(0, 3);
  const applicationAnswer = concepts[1] || concepts[0]!;
  const applicationOptions = shuffle(
    [applicationAnswer, concepts[0]!, prerequisites[0]!].filter(
      (value, index, array) => value && array.indexOf(value) === index,
    ),
  ).slice(0, 3);
  const connectionAnswer =
    related.find((item) => normalizeText(item) !== normalizeText(currentTitle)) ||
    localTopic.related[0] ||
    nextStep;
  const connectionOptions = shuffle(
    [connectionAnswer, ...related, ...path].filter(
      (value, index, array) => value && array.indexOf(value) === index,
    ),
  ).slice(0, 3);

  return [
    {
      prompt: `Which is one of the core ideas of ${currentTitle}?`,
      options: conceptOptions,
      correct: concepts[0]!,
      explanation: `${concepts[0]} is one of the core ideas currently defined for ${currentTitle}.`,
    },
    {
      prompt: "What comes next in the selected learning path?",
      options: nextOptions,
      correct: nextStep,
      explanation: `${nextStep} is the next step in the ${level} path for ${localTopic.title}.`,
    },
    {
      prompt: `Which is a prerequisite for ${currentTitle}?`,
      options: prereqOptions,
      correct: prerequisites[0]!,
      explanation: `${prerequisites[0]} is listed as background knowledge that makes this topic easier.`,
    },
    {
      prompt: `Which idea would you use when applying what you learned about ${currentTitle}?`,
      options: applicationOptions,
      correct: applicationAnswer,
      explanation: `${applicationAnswer} is a concept you would actually use, not only recognize.`,
    },
    {
      prompt: `Which subject is meaningfully connected to ${currentTitle}?`,
      options: connectionOptions,
      correct: connectionAnswer,
      explanation: `${connectionAnswer} is connected to ${currentTitle} in the authored landscape.`,
    },
  ];
}

export function classifySource(url: string, name = "") {
  const value = `${url} ${name}`.toLowerCase();
  if (/(nasa\.gov|esa\.int|noaa\.gov|nih\.gov|cern\.ch)/.test(value)) {
    return { label: "Institutional", why: "Produced by a scientific or public institution." };
  }
  if (value.includes("khanacademy.org")) {
    return { label: "Guided learning", why: "Designed for explanations and practice, not just reference." };
  }
  if (value.includes("openstax.org")) {
    return { label: "Open textbook", why: "Free structured textbook material for deeper study." };
  }
  if (value.includes("wikipedia.org")) {
    return { label: "Reference", why: "A broad starting point with definitions, context, and linked concepts." };
  }
  if (value.includes("openlibrary.org")) {
    return { label: "Books", why: "A catalog for discovering books and editions related to the topic." };
  }
  if (value.includes("plato.stanford.edu") || value.includes("iep.utm.edu")) {
    return { label: "Reference encyclopedia", why: "Specialist reference writing with citations and debates." };
  }
  return { label: "Further exploration", why: "An additional resource selected for exploring the subject." };
}

export function scoreExplanation(title: string, localKey: string | null, text: string) {
  const region = getDeepKnowledgeContext(localKey, title);
  const node = region?.nodes.find((item) => normalizeText(item.title) === normalizeText(title));
  const keywords = node?.keywords || [];
  const lower = text.toLowerCase();
  const matched = keywords.filter((keyword) => lower.includes(keyword.toLowerCase()));
  return {
    keywords,
    matched,
    coverage: new Set(matched.map((item) => item.toLowerCase())).size,
  };
}

export function topicCategories(language: string): Array<{ category: string; items: Array<{ key: string; title: string }> }> {
  const groups = new Map<string, Array<{ key: string; title: string }>>();
  Object.keys(topics).forEach((key) => {
    const data = getLocalizedTopic(key, language);
    if (!data) return;
    const list = groups.get(data.category) || [];
    list.push({ key, title: data.title });
    groups.set(data.category, list);
  });
  return [...groups.entries()].map(([category, items]) => ({ category, items }));
}
