import { create } from "zustand";
import { topics } from "@/lib/panorama/catalog";
import {
  buildKnowledgeCheck,
  findTopicKey,
  getBooks,
  getExpandedIntro,
  getLocalizedTopic,
  getResearch,
  getWikipediaSummary,
  scoreExplanation,
  searchWikipedia,
  type CheckQuestion,
} from "@/lib/panorama/engine";
import type {
  AtlasItem,
  AtlasStatus,
  LearningLevel,
  MapPerspective,
  RecentSearch,
  ResearchWork,
  SavedLink,
  SavedTopic,
  TopicResult,
  WorkspaceTab,
} from "@/lib/panorama/types";

const KEYS = {
  language: "eaglesLanguage",
  level: "eaglesLearningLevel",
  recent: "eaglesRecentSearches",
  topics: "eaglesSavedTopics",
  resources: "eaglesSavedResources",
  books: "eaglesSavedBooks",
  atlas: "eaglesKnowledgeAtlas",
  feedback: "eaglesStudyFeedback",
  notes: "eaglesStudyNotes",
};

function readJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJSON(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore quota */
  }
}

function atlasKey(title: string, language: string) {
  return `${language}::${title.toLowerCase().trim()}`;
}

export interface PanoramaState {
  hydrated: boolean;
  language: string;
  level: LearningLevel;
  query: string;
  suggestions: string[];
  loading: boolean;
  suggesting: boolean;
  error: string | null;
  result: TopicResult | null;
  research: ResearchWork[];
  researchLoading: boolean;
  tab: WorkspaceTab;
  mapPerspective: MapPerspective;
  presentationOpen: boolean;
  recentSearches: RecentSearch[];
  savedTopics: SavedTopic[];
  savedResources: SavedLink[];
  savedBooks: SavedLink[];
  atlas: AtlasItem[];
  hydrate: () => void;
  setLanguage: (language: string) => void;
  setLevel: (level: LearningLevel) => void;
  setQuery: (query: string) => void;
  setTab: (tab: WorkspaceTab) => void;
  setMapPerspective: (perspective: MapPerspective) => void;
  setPresentationOpen: (open: boolean) => void;
  loadSuggestions: (query: string) => void;
  clearSuggestions: () => void;
  explore: (query: string) => Promise<void>;
  toggleSavedTopic: () => void;
  toggleSavedResource: (resource: SavedLink) => void;
  toggleSavedBook: (book: SavedLink) => void;
  removeRecent: (query: string, language: string) => void;
  removeSavedTopic: (url: string, language: string) => void;
  removeSavedResource: (url: string) => void;
  removeSavedBook: (url: string) => void;
  clearLearningData: () => void;
  setAtlasStatus: (title: string, status: AtlasStatus) => void;
  recordEvidence: (title: string, evidence: AtlasItem["evidence"]) => void;
  saveExplanation: (title: string, text: string) => { coverage: number; matched: string[]; keywords: string[] };
  saveFeedback: (topic: string, usefulness: string, note: string) => void;
  saveNote: (note: string) => void;
  exportEvidence: () => void;
}

let suggestionTimer: ReturnType<typeof setTimeout> | null = null;
let suggestionRequest = 0;
let exploreRequest = 0;
let exploreAbort: AbortController | null = null;

function curatedFallback(query: string, language: string, level: LearningLevel): TopicResult | null {
  const key = findTopicKey(query);
  if (!key) return null;
  const local = getLocalizedTopic(key, language);
  if (!local) return null;
  return {
    query,
    level,
    language,
    summary: {
      title: local.title,
      description: local.category,
      extract: local.overview,
      url: `https://${language}.wikipedia.org/wiki/${encodeURIComponent(local.title)}`,
    },
    relatedPages: (local.related || []).map((title) => ({ title })),
    localKey: key,
    localTopic: local,
    books: [],
    fetchedAt: Date.now(),
    usedFallback: true,
  };
}

export const usePanorama = create<PanoramaState>((set, get) => ({
  hydrated: false,
  language: "en",
  level: "beginner",
  query: "",
  suggestions: [],
  loading: false,
  suggesting: false,
  error: null,
  result: null,
  research: [],
  researchLoading: false,
  tab: "understand",
  mapPerspective: "nearby",
  presentationOpen: false,
  recentSearches: [],
  savedTopics: [],
  savedResources: [],
  savedBooks: [],
  atlas: [],

  hydrate: () => {
    if (get().hydrated) return;
    const language = readJSON(KEYS.language, "en");
    const level = readJSON<LearningLevel>(KEYS.level, "beginner");
    set({
      hydrated: true,
      language: typeof language === "string" ? language : "en",
      level: ["beginner", "intermediate", "advanced"].includes(level) ? level : "beginner",
      recentSearches: readJSON(KEYS.recent, []),
      savedTopics: readJSON(KEYS.topics, []),
      savedResources: readJSON(KEYS.resources, []),
      savedBooks: readJSON(KEYS.books, []),
      atlas: readJSON(KEYS.atlas, []),
    });
  },

  setLanguage: (language) => {
    set({ language });
    writeJSON(KEYS.language, language);
    const { query, result } = get();
    if (query || result) void get().explore(query || result?.summary.title || "");
  },

  setLevel: (level) => {
    set({ level });
    writeJSON(KEYS.level, level);
    const { result } = get();
    if (result) void get().explore(result.query || result.summary.title);
  },

  setQuery: (query) => set({ query }),
  setTab: (tab) => set({ tab }),
  setMapPerspective: (mapPerspective) => set({ mapPerspective }),
  setPresentationOpen: (presentationOpen) => set({ presentationOpen }),
  clearSuggestions: () => set({ suggestions: [] }),

  loadSuggestions: (query) => {
    set({ query });
    if (suggestionTimer) clearTimeout(suggestionTimer);
    if (query.trim().length < 2) {
      set({ suggestions: [], suggesting: false });
      return;
    }
    set({ suggesting: true });
    const requestId = ++suggestionRequest;
    const language = get().language;
    suggestionTimer = setTimeout(() => {
      void (async () => {
        try {
          const pages = await searchWikipedia(query.trim(), language);
          if (requestId !== suggestionRequest) return;
          set({
            suggestions: pages.map((page) => page.title).slice(0, 7),
            suggesting: false,
          });
        } catch {
          if (requestId !== suggestionRequest) return;
          set({ suggesting: false });
        }
      })();
    }, 180);
  },

  explore: async (rawQuery) => {
    const query = rawQuery.trim();
    if (suggestionTimer) clearTimeout(suggestionTimer);
    suggestionRequest += 1;
    set({ query, suggestions: [], suggesting: false, error: null, tab: "understand", mapPerspective: "nearby" });
    if (!query) {
      set({ error: "Enter a subject to explore.", loading: false });
      return;
    }

    if (exploreAbort) exploreAbort.abort();
    const abort = new AbortController();
    exploreAbort = abort;
    const requestId = ++exploreRequest;
    const { language, level } = get();
    const immediate = curatedFallback(query, language, level);
    set({
      loading: true,
      error: null,
      result: immediate
        ? { ...immediate, books: get().result?.query === query ? get().result?.books || [] : [] }
        : get().result,
    });

    try {
      const pages = await searchWikipedia(query, language, abort.signal);
      if (requestId !== exploreRequest) return;

      let summaryTitle = pages[0]?.title;
      if (!summaryTitle && immediate) summaryTitle = immediate.summary.title;
      if (!summaryTitle) {
        set({
          loading: false,
          error: "No results found. Try a broader subject name.",
        });
        return;
      }

      const [summary, expanded, books] = await Promise.all([
        getWikipediaSummary(summaryTitle, language, abort.signal),
        getExpandedIntro(summaryTitle, language, abort.signal),
        getBooks(query, abort.signal),
      ]);
      if (requestId !== exploreRequest) return;

      const localKey = findTopicKey(query) || findTopicKey(summary.title);
      const localTopic = localKey ? getLocalizedTopic(localKey, language) : null;
      const extract = localTopic?.overview || expanded || summary.extract;
      const result: TopicResult = {
        query,
        level,
        language,
        summary: { ...summary, extract, description: summary.description || localTopic?.category || "" },
        relatedPages: pages.slice(1),
        localKey,
        localTopic,
        books,
        fetchedAt: Date.now(),
        usedFallback: false,
      };

      const recent: RecentSearch = {
        query,
        pageTitle: summary.title,
        level,
        language,
        timestamp: Date.now(),
      };
      const recentSearches = [
        recent,
        ...get().recentSearches.filter((item) => !(item.query === query && item.language === language)),
      ].slice(0, 10);

      const atlas = upsertAtlas(get().atlas, summary.title, language);
      writeJSON(KEYS.recent, recentSearches);
      writeJSON(KEYS.atlas, atlas);

      set({
        result,
        recentSearches,
        atlas,
        loading: false,
        error: null,
        research: [],
        researchLoading: true,
      });

      void getResearch(query, abort.signal).then((research) => {
        if (requestId !== exploreRequest) return;
        set({ research, researchLoading: false });
      });
    } catch (error) {
      if (abort.signal.aborted || requestId !== exploreRequest) return;
      const fallback = curatedFallback(query, language, level);
      if (fallback) {
        const atlas = upsertAtlas(get().atlas, fallback.summary.title, language);
        writeJSON(KEYS.atlas, atlas);
        set({
          result: fallback,
          atlas,
          loading: false,
          error: "Live sources were unavailable, so the curated topic is shown instead.",
          researchLoading: false,
        });
        return;
      }
      set({
        loading: false,
        error:
          error instanceof Error
            ? "The live source could not be reached. Check the name and try again."
            : "Something went wrong while exploring this subject.",
      });
    }
  },

  toggleSavedTopic: () => {
    const { result, language, level, savedTopics } = get();
    if (!result) return;
    const topic: SavedTopic = {
      title: result.summary.title,
      description: result.summary.description,
      url: result.summary.url,
      image: result.summary.image || "",
      category: result.localTopic?.category || "",
      language,
      level,
      query: result.query,
    };
    const exists = savedTopics.some((item) => item.url === topic.url && item.language === language);
    const next = exists
      ? savedTopics.filter((item) => !(item.url === topic.url && item.language === language))
      : [topic, ...savedTopics].slice(0, 50);
    writeJSON(KEYS.topics, next);
    set({ savedTopics: next });
  },

  toggleSavedResource: (resource) => {
    const exists = get().savedResources.some((item) => item.url === resource.url);
    const next = exists
      ? get().savedResources.filter((item) => item.url !== resource.url)
      : [resource, ...get().savedResources].slice(0, 50);
    writeJSON(KEYS.resources, next);
    set({ savedResources: next });
  },

  toggleSavedBook: (book) => {
    const exists = get().savedBooks.some((item) => item.url === book.url);
    const next = exists
      ? get().savedBooks.filter((item) => item.url !== book.url)
      : [book, ...get().savedBooks].slice(0, 50);
    writeJSON(KEYS.books, next);
    set({ savedBooks: next });
  },

  removeRecent: (query, language) => {
    const next = get().recentSearches.filter((item) => !(item.query === query && item.language === language));
    writeJSON(KEYS.recent, next);
    set({ recentSearches: next });
  },
  removeSavedTopic: (url, language) => {
    const next = get().savedTopics.filter((item) => !(item.url === url && item.language === language));
    writeJSON(KEYS.topics, next);
    set({ savedTopics: next });
  },
  removeSavedResource: (url) => {
    const next = get().savedResources.filter((item) => item.url !== url);
    writeJSON(KEYS.resources, next);
    set({ savedResources: next });
  },
  removeSavedBook: (url) => {
    const next = get().savedBooks.filter((item) => item.url !== url);
    writeJSON(KEYS.books, next);
    set({ savedBooks: next });
  },
  clearLearningData: () => {
    writeJSON(KEYS.recent, []);
    writeJSON(KEYS.topics, []);
    writeJSON(KEYS.resources, []);
    writeJSON(KEYS.books, []);
    writeJSON(KEYS.atlas, []);
    writeJSON(KEYS.feedback, []);
    writeJSON(KEYS.notes, []);
    set({
      recentSearches: [],
      savedTopics: [],
      savedResources: [],
      savedBooks: [],
      atlas: [],
    });
  },
  setAtlasStatus: (title, status) => {
    const atlas = upsertAtlas(get().atlas, title, get().language, { status, force: true, countVisit: false });
    writeJSON(KEYS.atlas, atlas);
    set({ atlas });
  },
  recordEvidence: (title, evidence) => {
    const language = get().language;
    let atlas = upsertAtlas(get().atlas, title, language, { countVisit: false });
    atlas = atlas.map((item) => {
      if (atlasKey(item.title, item.language) !== atlasKey(title, language)) return item;
      const nextEvidence = { ...item.evidence, ...evidence, lastChecked: Date.now() };
      const score = Number(nextEvidence.score || 0);
      const total = Number(nextEvidence.total || 0);
      const verified =
        total >= 5 &&
        score >= 4 &&
        nextEvidence.explanationSubmitted &&
        nextEvidence.connectionCompleted &&
        Number(nextEvidence.explanationCoverage || 0) >= 2;
      return {
        ...item,
        evidence: nextEvidence,
        status: verified ? "verified" : item.status,
      };
    });
    writeJSON(KEYS.atlas, atlas);
    set({ atlas });
  },
  saveExplanation: (title, text) => {
    const { result } = get();
    const scored = scoreExplanation(title, result?.localKey || findTopicKey(title), text);
    get().recordEvidence(title, {
      explanationSubmitted: true,
      explanationText: text,
      explanationCoverage: scored.coverage,
      matchedConcepts: scored.matched,
    });
    return scored;
  },
  saveFeedback: (topic, usefulness, note) => {
    const feedback = readJSON<Array<Record<string, string>>>(KEYS.feedback, []);
    feedback.push({
      id: String(Date.now()),
      topic,
      usefulness,
      note,
      timestamp: new Date().toISOString(),
    });
    writeJSON(KEYS.feedback, feedback.slice(-100));
  },
  saveNote: (note) => {
    const notes = readJSON<Array<Record<string, string>>>(KEYS.notes, []);
    notes.push({ note, timestamp: new Date().toISOString() });
    writeJSON(KEYS.notes, notes.slice(-50));
  },
  exportEvidence: () => {
    const payload = {
      atlas: get().atlas,
      feedback: readJSON(KEYS.feedback, []),
      studyNotes: readJSON(KEYS.notes, []),
      exportedAt: new Date().toISOString(),
      methodology:
        "Local prototype evidence. Verification uses quiz performance, a connection question, an explanation, and transparent keyword coverage against authored concepts. It is evidence of demonstrated work, not a claim of mastery.",
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "eagles-panorama-study-evidence.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },
}));

function upsertAtlas(
  atlas: AtlasItem[],
  title: string,
  language: string,
  options: { status?: AtlasStatus; force?: boolean; countVisit?: boolean } = {},
): AtlasItem[] {
  if (!title) return atlas;
  const key = atlasKey(title, language);
  const next = [...atlas];
  const index = next.findIndex((item) => atlasKey(item.title, item.language) === key);
  if (index < 0) {
    next.push({
      title,
      language,
      status: options.status || "explored",
      firstSeen: Date.now(),
      lastSeen: Date.now(),
      visits: options.countVisit === false ? 0 : 1,
    });
  } else {
    const current = next[index]!;
    next[index] = {
      ...current,
      title,
      lastSeen: Date.now(),
      visits: current.visits + (options.countVisit === false ? 0 : 1),
      status:
        options.status && (options.force || current.status === "explored")
          ? options.status
          : current.status,
    };
  }
  return next.slice(-100);
}

export function isTopicSaved(state: PanoramaState) {
  const result = state.result;
  if (!result) return false;
  return state.savedTopics.some(
    (item) => item.url === result.summary.url && item.language === state.language,
  );
}

export function currentQuestions(result: TopicResult | null): CheckQuestion[] | null {
  if (!result?.localTopic) return null;
  return buildKnowledgeCheck(result.localTopic, result.level, result.relatedPages, result.summary.title);
}

export function nextPathStep(result: TopicResult | null): string | null {
  if (!result) return null;
  const path = result.localTopic?.learningPath[result.level] || result.localTopic?.learningPath.beginner;
  if (path && path.length) {
    const index = path.findIndex(
      (item) => item.toLowerCase() === result.summary.title.toLowerCase(),
    );
    return path[Math.max(0, index) + 1] || path[1] || null;
  }
  return result.relatedPages[0]?.title || null;
}

export { topics };
