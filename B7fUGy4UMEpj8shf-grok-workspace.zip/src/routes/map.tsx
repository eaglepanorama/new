import { createFileRoute } from "@tanstack/react-router";
import { AppChrome, MapPage } from "@/components/eagle/shell";

export const Route = createFileRoute("/map")({ component: MapRoute });

function MapRoute() {
  return (
    <AppChrome>
      <MapPage />
    </AppChrome>
  );
}
