import { createFileRoute } from "@tanstack/react-router";
import { AppChrome, LearningPage } from "@/components/eagle/shell";

export const Route = createFileRoute("/learning")({ component: LearningRoute });

function LearningRoute() {
  return (
    <AppChrome>
      <LearningPage />
    </AppChrome>
  );
}
