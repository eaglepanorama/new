import { createFileRoute } from "@tanstack/react-router";
import { AppChrome, ExploreHome } from "@/components/eagle/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <AppChrome>
      <ExploreHome />
    </AppChrome>
  );
}
