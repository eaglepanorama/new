import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as Link, p as useRouterState, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as GraduationCap, d as Compass, f as Bookmark, h as ArrowRight, i as RotateCcw, l as ExternalLink, m as BookOpen, o as Minus, p as BookmarkCheck, r as Trash2, s as Map$1, t as UserRound, u as Download } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-BzHUoGFR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SUPPORTED_LANGUAGES = [
	{
		code: "en",
		label: "English"
	},
	{
		code: "fr",
		label: "Français"
	},
	{
		code: "es",
		label: "Español"
	},
	{
		code: "ar",
		label: "العربية"
	},
	{
		code: "de",
		label: "Deutsch"
	},
	{
		code: "pt",
		label: "Português"
	},
	{
		code: "ru",
		label: "Русский"
	},
	{
		code: "zh",
		label: "中文"
	},
	{
		code: "ja",
		label: "日本語"
	},
	{
		code: "hi",
		label: "हिन्दी"
	},
	{
		code: "it",
		label: "Italiano"
	},
	{
		code: "nl",
		label: "Nederlands"
	},
	{
		code: "pl",
		label: "Polski"
	},
	{
		code: "tr",
		label: "Türkçe"
	},
	{
		code: "ko",
		label: "한국어"
	},
	{
		code: "fa",
		label: "فارسی"
	},
	{
		code: "id",
		label: "Bahasa Indonesia"
	}
];
var path = (beginner, intermediate, advanced) => ({
	beginner,
	intermediate,
	advanced
});
function loc(title, category, overview, misconception, prerequisites, learningPath, concepts, related) {
	return {
		title,
		category,
		overview,
		misconception,
		prerequisites,
		learningPath,
		concepts,
		related
	};
}
var topics = {
	astronomy: {
		aliases: {
			en: ["astronomy"],
			fr: ["astronomie"],
			es: ["astronomía", "astronomia"],
			ar: ["علم الفلك"]
		},
		translations: {
			en: loc("Astronomy", "Science", "Astronomy is the scientific study of objects and phenomena beyond Earth: planets, stars, galaxies, black holes, and the large-scale structure and history of the universe.", "Astronomy is not astrology. It uses measurement, physics, and models — not personality forecasts.", [
				"Basic mathematics",
				"Basic physics",
				"Curiosity about space"
			], path([
				"What is Astronomy?",
				"The Solar System",
				"Stars",
				"Galaxies",
				"The Universe"
			], [
				"Classical Physics",
				"Stellar Structure",
				"Galactic Astronomy",
				"Black Holes",
				"Cosmology"
			], [
				"Astrophysics",
				"General Relativity",
				"High-Energy Astrophysics",
				"Cosmology",
				"Quantum Gravity"
			]), [
				"Planets and planetary systems",
				"Stars and stellar evolution",
				"Galaxies",
				"Black holes",
				"Cosmology"
			], [
				"Physics",
				"Cosmology",
				"Astrophysics",
				"Planetary Science"
			]),
			fr: loc("Astronomie", "Sciences", "L'astronomie est l'étude scientifique des objets et phénomènes situés au-delà de la Terre.", "L'astronomie n'est pas l'astrologie.", [
				"Mathématiques de base",
				"Physique de base",
				"Curiosité pour l'espace"
			], path([
				"Qu'est-ce que l'astronomie ?",
				"Le Système solaire",
				"Les étoiles",
				"Les galaxies",
				"L'Univers"
			], [
				"Physique classique",
				"Structure des étoiles",
				"Astronomie galactique",
				"Trous noirs",
				"Cosmologie"
			], [
				"Astrophysique",
				"Relativité générale",
				"Astrophysique des hautes énergies",
				"Cosmologie",
				"Gravitation quantique"
			]), [
				"Planètes",
				"Étoiles",
				"Galaxies",
				"Trous noirs",
				"Cosmologie"
			], [
				"Physique",
				"Cosmologie",
				"Astrophysique",
				"Science planétaire"
			]),
			es: loc("Astronomía", "Ciencia", "La astronomía es el estudio científico de los objetos y fenómenos más allá de la Tierra.", "La astronomía no es astrología.", [
				"Matemáticas básicas",
				"Física básica",
				"Curiosidad por el espacio"
			], path([
				"¿Qué es la astronomía?",
				"El Sistema Solar",
				"Las estrellas",
				"Las galaxias",
				"El Universo"
			], [
				"Física clásica",
				"Estructura estelar",
				"Astronomía galáctica",
				"Agujeros negros",
				"Cosmología"
			], [
				"Astrofísica",
				"Relatividad general",
				"Astrofísica de altas energías",
				"Cosmología",
				"Gravedad cuántica"
			]), [
				"Planetas",
				"Estrellas",
				"Galaxias",
				"Agujeros negros",
				"Cosmología"
			], [
				"Física",
				"Cosmología",
				"Astrofísica",
				"Ciencia planetaria"
			]),
			ar: loc("علم الفلك", "العلوم", "علم الفلك هو الدراسة العلمية للأجرام والظواهر الموجودة خارج الأرض.", "علم الفلك ليس علم التنجيم.", [
				"أساسيات الرياضيات",
				"أساسيات الفيزياء",
				"الفضول حول الفضاء"
			], path([
				"ما هو علم الفلك؟",
				"النظام الشمسي",
				"النجوم",
				"المجرات",
				"الكون"
			], [
				"الفيزياء الكلاسيكية",
				"بنية النجوم",
				"علم الفلك المجري",
				"الثقوب السوداء",
				"علم الكونيات"
			], [
				"الفيزياء الفلكية",
				"النسبية العامة",
				"فيزياء الفلك عالية الطاقة",
				"علم الكونيات",
				"الجاذبية الكمومية"
			]), [
				"الكواكب",
				"النجوم",
				"المجرات",
				"الثقوب السوداء",
				"علم الكونيات"
			], [
				"الفيزياء",
				"علم الكونيات",
				"الفيزياء الفلكية",
				"علم الكواكب"
			])
		},
		resources: [
			{
				name: "NASA Astronomy",
				url: "https://science.nasa.gov/astronomy/"
			},
			{
				name: "Khan Academy — Cosmology and Astronomy",
				url: "https://www.khanacademy.org/science/cosmology-and-astronomy"
			},
			{
				name: "OpenStax — Astronomy 2e",
				url: "https://openstax.org/books/astronomy-2e/"
			}
		]
	},
	physics: {
		aliases: {
			en: ["physics"],
			fr: ["physique"],
			es: ["física", "fisica"],
			ar: ["الفيزياء"]
		},
		translations: {
			en: loc("Physics", "Science", "Physics studies matter, energy, motion, forces, space, and time, and the rules that describe how nature behaves.", "Physics is not a pile of formulas. Formulas are compressed models of relationships that have to be measured and tested.", ["Basic mathematics", "Algebra"], path([
				"Basic Mathematics",
				"Motion",
				"Forces",
				"Energy",
				"Waves"
			], [
				"Classical Mechanics",
				"Electricity",
				"Magnetism",
				"Thermodynamics",
				"Waves"
			], [
				"Quantum Mechanics",
				"Relativity",
				"Particle Physics",
				"Statistical Mechanics",
				"Field Theory"
			]), [
				"Motion",
				"Forces",
				"Energy",
				"Waves",
				"Modern physics"
			], [
				"Mathematics",
				"Astronomy",
				"Engineering",
				"Chemistry"
			]),
			fr: loc("Physique", "Sciences", "La physique étudie la matière, l'énergie, le mouvement, les forces, l'espace et le temps.", "La physique n'est pas une collection de formules isolées.", ["Mathématiques de base", "Algèbre"], path([
				"Mathématiques de base",
				"Mouvement",
				"Forces",
				"Énergie",
				"Ondes"
			], [
				"Mécanique classique",
				"Électricité",
				"Magnétisme",
				"Thermodynamique",
				"Ondes"
			], [
				"Mécanique quantique",
				"Relativité",
				"Physique des particules",
				"Mécanique statistique",
				"Théorie des champs"
			]), [
				"Mouvement",
				"Forces",
				"Énergie",
				"Ondes",
				"Physique moderne"
			], [
				"Mathématiques",
				"Astronomie",
				"Ingénierie",
				"Chimie"
			]),
			es: loc("Física", "Ciencia", "La física estudia la materia, la energía, el movimiento, las fuerzas, el espacio y el tiempo.", "La física no es una lista de fórmulas.", ["Matemáticas básicas", "Álgebra"], path([
				"Matemáticas básicas",
				"Movimiento",
				"Fuerzas",
				"Energía",
				"Ondas"
			], [
				"Mecánica clásica",
				"Electricidad",
				"Magnetismo",
				"Termodinámica",
				"Ondas"
			], [
				"Mecánica cuántica",
				"Relatividad",
				"Física de partículas",
				"Mecánica estadística",
				"Teoría de campos"
			]), [
				"Movimiento",
				"Fuerzas",
				"Energía",
				"Ondas",
				"Física moderna"
			], [
				"Matemáticas",
				"Astronomía",
				"Ingeniería",
				"Química"
			])
		},
		resources: [{
			name: "Khan Academy — Physics",
			url: "https://www.khanacademy.org/science/physics"
		}, {
			name: "OpenStax — College Physics",
			url: "https://openstax.org/details/books/college-physics-2e"
		}]
	},
	history: {
		aliases: {
			en: ["history"],
			fr: ["histoire"],
			es: ["historia"],
			ar: ["التاريخ"]
		},
		translations: { en: loc("History", "Humanities", "History is the study of the human past through events, societies, cultures, institutions, and the evidence people have left behind.", "History is not a timeline of dates. Chronology is a tool; the work is evidence, argument, and uncertainty.", ["Ability to compare sources", "Interest in human societies"], path([
			"Understanding Historical Time",
			"Ancient Civilizations",
			"Medieval History",
			"Early Modern History",
			"Modern History"
		], [
			"Historical Sources",
			"Ancient Civilizations",
			"Medieval Societies",
			"Early Modern States",
			"Modern World History"
		], [
			"Historiography",
			"Primary Source Analysis",
			"Comparative History",
			"Historical Method",
			"Specialized Research"
		]), [
			"Ancient civilizations",
			"Medieval societies",
			"Early modern history",
			"Modern history",
			"Historical evidence"
		], [
			"Archaeology",
			"Geography",
			"Politics",
			"Anthropology",
			"Philosophy"
		]) },
		resources: [{
			name: "Khan Academy — World History",
			url: "https://www.khanacademy.org/humanities/world-history"
		}, {
			name: "OpenStax — World History",
			url: "https://openstax.org/subjects/humanities"
		}]
	},
	philosophy: {
		aliases: {
			en: ["philosophy"],
			fr: ["philosophie"],
			es: ["filosofía", "filosofia"],
			ar: ["الفلسفة"]
		},
		translations: { en: loc("Philosophy", "Humanities", "Philosophy investigates fundamental questions about reality, knowledge, morality, reasoning, existence, and how we should live.", "Philosophy is not a collection of opinions. The work is making assumptions explicit and testing whether conclusions follow.", ["Willingness to question assumptions", "Basic reasoning skills"], path([
			"What is Philosophy?",
			"Logic",
			"Ethics",
			"Knowledge",
			"Existence"
		], [
			"Logic",
			"Epistemology",
			"Ethics",
			"Metaphysics",
			"Philosophy of Mind"
		], [
			"Formal Logic",
			"Advanced Epistemology",
			"Metaethics",
			"Analytic Metaphysics",
			"Philosophy of Mind"
		]), [
			"Logic",
			"Epistemology",
			"Ethics",
			"Metaphysics",
			"Philosophy of mind"
		], [
			"Psychology",
			"Logic",
			"History",
			"Political Philosophy"
		]) },
		resources: [{
			name: "Stanford Encyclopedia of Philosophy",
			url: "https://plato.stanford.edu/"
		}, {
			name: "Internet Encyclopedia of Philosophy",
			url: "https://iep.utm.edu/"
		}]
	},
	technology: {
		aliases: {
			en: ["technology", "computer science"],
			fr: ["technologie"],
			es: ["tecnología", "tecnologia"],
			ar: ["التكنولوجيا"]
		},
		translations: { en: loc("Technology", "Technology", "Technology turns knowledge into designed systems, tools, and processes that operate under constraints.", "Technology is not the same as gadgets. The deeper subject is how designed systems store, transform, and communicate information.", ["Basic computer skills", "Curiosity about how systems work"], path([
			"Computer Basics",
			"How the Web Works",
			"Programming Basics",
			"Data Basics",
			"Digital Systems"
		], [
			"Programming",
			"Data Structures",
			"Databases",
			"Computer Networks",
			"Cybersecurity"
		], [
			"Algorithms",
			"Distributed Systems",
			"Artificial Intelligence",
			"Computer Architecture",
			"Advanced Computing"
		]), [
			"Computer science",
			"Programming",
			"Artificial intelligence",
			"Networks",
			"Cybersecurity"
		], [
			"Programming",
			"Engineering",
			"Artificial Intelligence",
			"Mathematics"
		]) },
		resources: [{
			name: "freeCodeCamp",
			url: "https://www.freecodecamp.org/"
		}, {
			name: "MDN Web Docs",
			url: "https://developer.mozilla.org/"
		}]
	},
	mathematics: {
		aliases: {
			en: [
				"mathematics",
				"maths",
				"math"
			],
			fr: ["mathématiques", "mathematiques"],
			es: ["matemáticas", "matematicas"]
		},
		translations: { en: loc("Mathematics", "Science", "Mathematics studies quantity, structure, space, and change using precise definitions, proofs, and models.", "Mathematics is not a race to compute answers. The core skill is seeing the structure that makes a calculation valid.", ["Arithmetic fluency", "Willingness to work slowly and precisely"], path([
			"Numbers and operations",
			"Algebra",
			"Geometry",
			"Functions",
			"Probability"
		], [
			"Linear algebra",
			"Calculus",
			"Discrete mathematics",
			"Statistics",
			"Proof"
		], [
			"Real analysis",
			"Abstract algebra",
			"Differential equations",
			"Topology",
			"Mathematical logic"
		]), [
			"Proof",
			"Functions",
			"Structures",
			"Change",
			"Uncertainty"
		], [
			"Physics",
			"Computer Science",
			"Statistics",
			"Philosophy"
		]) },
		resources: [{
			name: "Khan Academy — Math",
			url: "https://www.khanacademy.org/math"
		}, {
			name: "OpenStax — Mathematics",
			url: "https://openstax.org/subjects/math"
		}]
	},
	biology: {
		aliases: {
			en: ["biology"],
			fr: ["biologie"],
			es: ["biología", "biologia"]
		},
		translations: { en: loc("Biology", "Science", "Biology studies living systems: cells, organisms, evolution, ecology, and the chemical processes that keep life going.", "Biology is not a list of facts to memorize. The organizing ideas are evolution, information, energy, and systems.", ["Basic chemistry", "Curiosity about living systems"], path([
			"What is life?",
			"Cells",
			"Genetics",
			"Evolution",
			"Ecology"
		], [
			"Molecular biology",
			"Physiology",
			"Evolutionary biology",
			"Microbiology",
			"Ecology"
		], [
			"Systems biology",
			"Developmental biology",
			"Population genetics",
			"Neuroscience",
			"Bioinformatics"
		]), [
			"Cells",
			"Genes",
			"Evolution",
			"Energy",
			"Ecosystems"
		], [
			"Chemistry",
			"Medicine",
			"Ecology",
			"Philosophy of Science"
		]) },
		resources: [{
			name: "Khan Academy — Biology",
			url: "https://www.khanacademy.org/science/biology"
		}, {
			name: "OpenStax — Biology",
			url: "https://openstax.org/details/books/biology-2e"
		}]
	},
	chemistry: {
		aliases: {
			en: ["chemistry"],
			fr: ["chimie"],
			es: ["química", "quimica"]
		},
		translations: { en: loc("Chemistry", "Science", "Chemistry studies matter by looking at atoms, bonds, reactions, energy, and how substances change into other substances.", "Chemistry is not magic transformations. Reactions are rearrangements of atoms under energy and environmental constraints.", ["Basic mathematics", "Atomic structure"], path([
			"Atoms and the periodic table",
			"Chemical bonds",
			"Reactions",
			"Stoichiometry",
			"Acids and bases"
		], [
			"Thermochemistry",
			"Equilibrium",
			"Kinetics",
			"Organic chemistry",
			"Electrochemistry"
		], [
			"Quantum chemistry",
			"Physical chemistry",
			"Spectroscopy",
			"Materials chemistry",
			"Biochemistry"
		]), [
			"Atoms",
			"Bonds",
			"Reactions",
			"Energy",
			"Molecules"
		], [
			"Physics",
			"Biology",
			"Materials Science",
			"Astronomy"
		]) },
		resources: [{
			name: "Khan Academy — Chemistry",
			url: "https://www.khanacademy.org/science/chemistry"
		}, {
			name: "OpenStax — Chemistry",
			url: "https://openstax.org/details/books/chemistry-2e"
		}]
	}
};
var knowledgeMapParents = {
	astronomy: [
		"Physics",
		"Natural Sciences",
		"Human Knowledge"
	],
	physics: ["Natural Sciences", "Human Knowledge"],
	mathematics: ["Formal Sciences", "Human Knowledge"],
	biology: ["Natural Sciences", "Human Knowledge"],
	chemistry: ["Natural Sciences", "Human Knowledge"],
	history: ["Humanities", "Human Knowledge"],
	philosophy: ["Humanities", "Human Knowledge"],
	technology: [
		"Computer Science",
		"Technology",
		"Human Knowledge"
	]
};
var deepKnowledgeRegions = {
	astronomy: {
		title: "Astronomy",
		thesis: "Astronomy connects physical laws to the objects, history, and structure of the universe.",
		nodes: [
			{
				title: "Mathematics",
				role: "Foundation",
				why: "Provides the language for measuring motion, scale, probability, and change.",
				keywords: [
					"math",
					"mathematics",
					"equation",
					"measurement"
				]
			},
			{
				title: "Physics",
				role: "Foundation",
				why: "Supplies the physical laws used to model gravity, light, matter, and energy.",
				keywords: [
					"physics",
					"laws",
					"gravity",
					"energy",
					"matter"
				]
			},
			{
				title: "Stars",
				role: "Core region",
				why: "Stars are laboratories where gravity, plasma, radiation, and nuclear fusion interact.",
				keywords: [
					"stars",
					"fusion",
					"nuclear",
					"hydrogen",
					"helium"
				]
			},
			{
				title: "Stellar Evolution",
				role: "Process",
				why: "Explains how stars change over time as their fuel and internal structure change.",
				keywords: [
					"stellar evolution",
					"fuel",
					"star",
					"core"
				]
			},
			{
				title: "Nucleosynthesis",
				role: "Bridge",
				why: "Connects stellar physics to the formation of many chemical elements.",
				keywords: [
					"nucleosynthesis",
					"elements",
					"heavy elements",
					"fusion"
				]
			},
			{
				title: "Galaxies",
				role: "Structure",
				why: "Shows how stars, gas, dark matter, and gravity organize matter on larger scales.",
				keywords: [
					"galaxies",
					"stars",
					"dark matter",
					"gravity"
				]
			},
			{
				title: "Cosmology",
				role: "Large scale",
				why: "Studies the origin, evolution, and large-scale structure of the universe.",
				keywords: [
					"cosmology",
					"universe",
					"expansion",
					"big bang"
				]
			},
			{
				title: "Planetary Science",
				role: "Application",
				why: "Connects astronomy to the formation, composition, and evolution of planetary systems.",
				keywords: [
					"planets",
					"planetary",
					"formation",
					"systems"
				]
			}
		],
		relations: [
			[
				"Mathematics",
				"Physics",
				"method",
				"Mathematics provides quantitative tools for physical models."
			],
			[
				"Physics",
				"Stars",
				"causal",
				"Physical laws explain stellar structure and behavior."
			],
			[
				"Stars",
				"Stellar Evolution",
				"causal",
				"A star's internal processes change as its fuel and structure evolve."
			],
			[
				"Stellar Evolution",
				"Nucleosynthesis",
				"causal",
				"Different stages of stellar evolution enable different element-forming processes."
			],
			[
				"Nucleosynthesis",
				"Chemistry",
				"application",
				"Elements produced in cosmic processes become the ingredients of chemical matter."
			],
			[
				"Stars",
				"Galaxies",
				"connected",
				"Stars are major visible components of galaxies and trace their structure."
			],
			[
				"Galaxies",
				"Cosmology",
				"connected",
				"Galaxy populations provide evidence about large-scale cosmic history."
			],
			[
				"Physics",
				"Cosmology",
				"foundation",
				"Cosmological models rely on physical laws and measurements."
			]
		]
	},
	physics: {
		title: "Physics",
		thesis: "Physics builds models that connect measurable phenomena through laws, mathematics, and experiments.",
		nodes: [
			{
				title: "Mathematics",
				role: "Foundation",
				why: "Formalizes physical relationships and lets models make quantitative predictions.",
				keywords: [
					"mathematics",
					"equations",
					"calculus",
					"probability"
				]
			},
			{
				title: "Mechanics",
				role: "Classical core",
				why: "Describes motion, forces, momentum, and energy at everyday scales.",
				keywords: [
					"mechanics",
					"motion",
					"force",
					"momentum",
					"energy"
				]
			},
			{
				title: "Electromagnetism",
				role: "Classical field",
				why: "Explains electric and magnetic phenomena and electromagnetic radiation.",
				keywords: [
					"electromagnetism",
					"electric",
					"magnetic",
					"fields",
					"light"
				]
			},
			{
				title: "Thermodynamics",
				role: "Macroscopic",
				why: "Connects energy, heat, work, and the direction of physical processes.",
				keywords: [
					"thermodynamics",
					"heat",
					"energy",
					"entropy",
					"work"
				]
			},
			{
				title: "Quantum Mechanics",
				role: "Modern foundation",
				why: "Describes physical systems where classical models cease to be sufficient.",
				keywords: [
					"quantum",
					"probability",
					"wave",
					"particle"
				]
			},
			{
				title: "Relativity",
				role: "Spacetime",
				why: "Reframes space, time, motion, and gravity at high speeds and strong fields.",
				keywords: [
					"relativity",
					"spacetime",
					"gravity",
					"speed"
				]
			},
			{
				title: "Particle Physics",
				role: "Fundamental",
				why: "Investigates matter and interactions at the smallest accessible scales.",
				keywords: [
					"particles",
					"standard model",
					"matter",
					"interaction"
				]
			},
			{
				title: "Statistical Physics",
				role: "Bridge",
				why: "Connects microscopic behavior to macroscopic properties.",
				keywords: [
					"statistical",
					"probability",
					"microstate",
					"macroscopic"
				]
			}
		],
		relations: [
			[
				"Mathematics",
				"Mechanics",
				"method",
				"Mechanics expresses motion and forces through mathematical models."
			],
			[
				"Mechanics",
				"Relativity",
				"contrast",
				"Classical mechanics becomes an approximation when relativistic effects matter."
			],
			[
				"Electromagnetism",
				"Quantum Mechanics",
				"foundation",
				"Quantum theory is needed for a deeper description of electromagnetic interactions."
			],
			[
				"Thermodynamics",
				"Statistical Physics",
				"causal",
				"Statistical physics explains macroscopic thermodynamic behavior from microscopic states."
			],
			[
				"Quantum Mechanics",
				"Particle Physics",
				"foundation",
				"Particle physics uses quantum principles to describe fundamental interactions."
			],
			[
				"Relativity",
				"Cosmology",
				"application",
				"Relativistic gravity is central to modern models of cosmic evolution."
			],
			[
				"Mathematics",
				"Quantum Mechanics",
				"method",
				"Quantum states and predictions require mathematical structures and probability."
			],
			[
				"Mechanics",
				"Thermodynamics",
				"connected",
				"Both describe physical systems but focus on different kinds of variables and scales."
			]
		]
	},
	history: {
		title: "History",
		thesis: "History is not simply a timeline: it is an evidence-based reconstruction of past human change.",
		nodes: [
			{
				title: "Chronology",
				role: "Foundation",
				why: "Provides temporal order without by itself explaining causes or significance.",
				keywords: [
					"chronology",
					"time",
					"dates",
					"period"
				]
			},
			{
				title: "Primary Sources",
				role: "Evidence",
				why: "Provide direct traces from the period being studied, with context and limitations.",
				keywords: [
					"primary source",
					"source",
					"document",
					"evidence"
				]
			},
			{
				title: "Source Criticism",
				role: "Method",
				why: "Tests provenance, context, perspective, reliability, and what a source can actually support.",
				keywords: [
					"source criticism",
					"bias",
					"context",
					"provenance",
					"reliability"
				]
			},
			{
				title: "Historiography",
				role: "Interpretation",
				why: "Studies how historians construct, debate, and revise interpretations of the past.",
				keywords: [
					"historiography",
					"interpretation",
					"historians",
					"debate"
				]
			},
			{
				title: "Causation",
				role: "Reasoning",
				why: "Separates sequences of events from defensible explanations of why change occurred.",
				keywords: [
					"causation",
					"cause",
					"effect",
					"explanation"
				]
			},
			{
				title: "Comparative History",
				role: "Connection",
				why: "Compares societies or periods to reveal patterns without assuming they are identical.",
				keywords: [
					"comparative",
					"comparison",
					"societies",
					"differences"
				]
			},
			{
				title: "Social History",
				role: "Perspective",
				why: "Examines lived experience, institutions, work, family, class, and everyday life.",
				keywords: [
					"social history",
					"society",
					"class",
					"everyday"
				]
			},
			{
				title: "Historical Method",
				role: "Synthesis",
				why: "Combines source analysis, chronology, comparison, argument, and uncertainty.",
				keywords: [
					"historical method",
					"research",
					"argument",
					"evidence"
				]
			}
		],
		relations: [
			[
				"Chronology",
				"Causation",
				"method",
				"Knowing what happened first does not by itself establish why it happened."
			],
			[
				"Primary Sources",
				"Source Criticism",
				"foundation",
				"Sources must be evaluated before their claims are used as evidence."
			],
			[
				"Source Criticism",
				"Historical Method",
				"method",
				"Critical source evaluation is part of defensible historical research."
			],
			[
				"Historiography",
				"Historical Method",
				"method",
				"Historiography exposes competing interpretations and the assumptions behind them."
			],
			[
				"Causation",
				"Comparative History",
				"method",
				"Comparison can test whether a proposed cause appears across different contexts."
			],
			[
				"Social History",
				"Comparative History",
				"connected",
				"Comparing everyday life can reveal both recurring structures and local differences."
			],
			[
				"Primary Sources",
				"Social History",
				"application",
				"Diaries, records, and objects can illuminate lived experience."
			],
			[
				"Historiography",
				"Causation",
				"contrast",
				"Different interpretations can disagree about which causes deserve emphasis."
			]
		]
	},
	philosophy: {
		title: "Philosophy",
		thesis: "Philosophy examines concepts and arguments by making assumptions explicit and testing whether conclusions follow.",
		nodes: [
			{
				title: "Logic",
				role: "Foundation",
				why: "Provides tools for identifying valid forms of reasoning and hidden assumptions.",
				keywords: [
					"logic",
					"argument",
					"valid",
					"premise",
					"conclusion"
				]
			},
			{
				title: "Epistemology",
				role: "Knowledge",
				why: "Asks what knowledge is, what justifies belief, and how certainty can be assessed.",
				keywords: [
					"epistemology",
					"knowledge",
					"belief",
					"justification",
					"certainty"
				]
			},
			{
				title: "Metaphysics",
				role: "Reality",
				why: "Investigates what exists and what kinds of things reality fundamentally contains.",
				keywords: [
					"metaphysics",
					"reality",
					"existence",
					"being"
				]
			},
			{
				title: "Ethics",
				role: "Value",
				why: "Examines what makes actions, character, or outcomes morally significant.",
				keywords: [
					"ethics",
					"moral",
					"action",
					"value",
					"good"
				]
			},
			{
				title: "Philosophy of Mind",
				role: "Mind",
				why: "Investigates consciousness, mental states, identity, and their relation to the physical world.",
				keywords: [
					"mind",
					"consciousness",
					"mental",
					"identity"
				]
			},
			{
				title: "Philosophy of Science",
				role: "Method",
				why: "Examines explanation, evidence, models, theory choice, and the limits of scientific knowledge.",
				keywords: [
					"science",
					"evidence",
					"theory",
					"explanation",
					"method"
				]
			},
			{
				title: "Political Philosophy",
				role: "Society",
				why: "Analyzes justice, authority, freedom, rights, and collective life.",
				keywords: [
					"political",
					"justice",
					"authority",
					"freedom",
					"rights"
				]
			},
			{
				title: "Philosophy of Language",
				role: "Meaning",
				why: "Studies meaning, reference, interpretation, and how language relates to thought.",
				keywords: [
					"language",
					"meaning",
					"reference",
					"interpretation"
				]
			}
		],
		relations: [
			[
				"Logic",
				"Epistemology",
				"foundation",
				"Arguments about knowledge depend on reasoning from premises to conclusions."
			],
			[
				"Epistemology",
				"Philosophy of Science",
				"application",
				"Questions about evidence and justification shape how scientific claims are evaluated."
			],
			[
				"Metaphysics",
				"Philosophy of Mind",
				"connected",
				"Questions about what exists intersect with questions about minds and consciousness."
			],
			[
				"Ethics",
				"Political Philosophy",
				"connected",
				"Individual moral reasoning intersects with questions about justice and institutions."
			],
			[
				"Philosophy of Language",
				"Epistemology",
				"method",
				"What a claim means affects what evidence could support or challenge it."
			],
			[
				"Logic",
				"Philosophy of Science",
				"method",
				"Scientific arguments require careful reasoning about models, evidence, and inference."
			],
			[
				"Philosophy of Mind",
				"Metaphysics",
				"foundation",
				"Accounts of consciousness often depend on assumptions about what kinds of things minds are."
			],
			[
				"Ethics",
				"Epistemology",
				"connected",
				"Moral reasoning raises questions about whether and how moral beliefs can be justified."
			]
		]
	},
	technology: {
		title: "Technology",
		thesis: "Technology turns knowledge into designed systems, tools, and processes that operate under constraints.",
		nodes: [
			{
				title: "Algorithms",
				role: "Foundation",
				why: "Provide step-by-step procedures for transforming inputs into useful outputs.",
				keywords: [
					"algorithm",
					"procedure",
					"input",
					"output",
					"complexity"
				]
			},
			{
				title: "Data Structures",
				role: "Foundation",
				why: "Organize information so software can store, access, and transform it efficiently.",
				keywords: [
					"data structures",
					"arrays",
					"trees",
					"graphs",
					"data"
				]
			},
			{
				title: "Computer Architecture",
				role: "Hardware",
				why: "Connects software abstractions to processors, memory, storage, and physical computation.",
				keywords: [
					"architecture",
					"processor",
					"memory",
					"hardware",
					"cpu"
				]
			},
			{
				title: "Operating Systems",
				role: "Systems",
				why: "Manage hardware resources and provide abstractions that applications rely on.",
				keywords: [
					"operating system",
					"process",
					"memory",
					"filesystem",
					"kernel"
				]
			},
			{
				title: "Networks",
				role: "Systems",
				why: "Allow independent computers and services to communicate and exchange information.",
				keywords: [
					"network",
					"protocol",
					"internet",
					"communication"
				]
			},
			{
				title: "Distributed Systems",
				role: "Scale",
				why: "Coordinate computation and data across machines where failures and latency matter.",
				keywords: [
					"distributed",
					"servers",
					"latency",
					"failure",
					"consensus"
				]
			},
			{
				title: "Artificial Intelligence",
				role: "Application",
				why: "Uses computational methods for prediction, generation, or decision-making.",
				keywords: [
					"artificial intelligence",
					"machine learning",
					"model",
					"prediction"
				]
			},
			{
				title: "Human-Computer Interaction",
				role: "Human layer",
				why: "Studies how people interact with technology and how interfaces shape use.",
				keywords: [
					"interaction",
					"interface",
					"user",
					"usability"
				]
			}
		],
		relations: [
			[
				"Algorithms",
				"Data Structures",
				"foundation",
				"Algorithms often depend on how information is represented and accessed."
			],
			[
				"Data Structures",
				"Algorithms",
				"method",
				"The chosen representation affects what operations are efficient."
			],
			[
				"Computer Architecture",
				"Operating Systems",
				"foundation",
				"Operating systems manage resources exposed by hardware."
			],
			[
				"Operating Systems",
				"Networks",
				"connected",
				"Networked applications rely on operating-system facilities and abstractions."
			],
			[
				"Networks",
				"Distributed Systems",
				"foundation",
				"Distributed systems operate across communicating machines."
			],
			[
				"Algorithms",
				"Artificial Intelligence",
				"application",
				"Many AI systems are built from algorithms operating on data and models."
			],
			[
				"Human-Computer Interaction",
				"Artificial Intelligence",
				"application",
				"AI systems still depend on interfaces through which people interpret them."
			],
			[
				"Mathematics",
				"Algorithms",
				"foundation",
				"Algorithm analysis uses mathematical ideas of structure, proof, and complexity."
			]
		]
	},
	mathematics: {
		title: "Mathematics",
		thesis: "Mathematics makes structure explicit so arguments can be checked and models can be reused.",
		nodes: [
			{
				title: "Arithmetic",
				role: "Foundation",
				why: "Gives the first precise operations on quantity.",
				keywords: [
					"arithmetic",
					"number",
					"operation"
				]
			},
			{
				title: "Algebra",
				role: "Language",
				why: "Lets unknown quantities and relationships be written and transformed.",
				keywords: [
					"algebra",
					"equation",
					"variable"
				]
			},
			{
				title: "Proof",
				role: "Method",
				why: "Turns a claim into something that can be verified from agreed rules.",
				keywords: [
					"proof",
					"theorem",
					"axiom",
					"logic"
				]
			},
			{
				title: "Calculus",
				role: "Change",
				why: "Describes rates of change and accumulation.",
				keywords: [
					"calculus",
					"derivative",
					"integral",
					"change"
				]
			},
			{
				title: "Probability",
				role: "Uncertainty",
				why: "Gives a language for reasoning under incomplete information.",
				keywords: [
					"probability",
					"chance",
					"random",
					"uncertainty"
				]
			},
			{
				title: "Linear Algebra",
				role: "Structure",
				why: "Describes spaces, transformations, and systems of relationships.",
				keywords: [
					"linear",
					"vector",
					"matrix",
					"space"
				]
			},
			{
				title: "Statistics",
				role: "Application",
				why: "Connects data to models, uncertainty, and inference.",
				keywords: [
					"statistics",
					"data",
					"inference",
					"sample"
				]
			},
			{
				title: "Logic",
				role: "Foundation",
				why: "Makes valid inference explicit.",
				keywords: [
					"logic",
					"valid",
					"premise",
					"conclusion"
				]
			}
		],
		relations: [
			[
				"Arithmetic",
				"Algebra",
				"foundation",
				"Algebra generalizes arithmetic operations into symbolic relationships."
			],
			[
				"Algebra",
				"Calculus",
				"foundation",
				"Calculus needs a language of functions and algebraic manipulation."
			],
			[
				"Proof",
				"Logic",
				"method",
				"Proof is the practical use of logical inference in mathematics."
			],
			[
				"Linear Algebra",
				"Physics",
				"application",
				"Physical models often live in vector spaces and linear transformations."
			],
			[
				"Probability",
				"Statistics",
				"foundation",
				"Statistical inference uses probability as its formal language."
			],
			[
				"Calculus",
				"Physics",
				"application",
				"Rates of change are the backbone of classical physical models."
			],
			[
				"Logic",
				"Philosophy",
				"connected",
				"Questions about valid argument sit in both mathematics and philosophy."
			],
			[
				"Linear Algebra",
				"Algorithms",
				"application",
				"Many computational methods rest on linear-algebraic structure."
			]
		]
	},
	biology: {
		title: "Biology",
		thesis: "Living systems are organized by information, energy flow, and evolutionary history.",
		nodes: [
			{
				title: "Cells",
				role: "Unit",
				why: "The basic organizational unit of known life.",
				keywords: [
					"cell",
					"membrane",
					"organelle"
				]
			},
			{
				title: "Genetics",
				role: "Information",
				why: "Describes how biological information is stored, copied, and used.",
				keywords: [
					"gene",
					"dna",
					"inheritance",
					"information"
				]
			},
			{
				title: "Evolution",
				role: "History",
				why: "Explains the diversity of life through descent with modification.",
				keywords: [
					"evolution",
					"selection",
					"variation",
					"ancestry"
				]
			},
			{
				title: "Ecology",
				role: "Systems",
				why: "Studies organisms in relation to each other and their environments.",
				keywords: [
					"ecology",
					"ecosystem",
					"population",
					"environment"
				]
			},
			{
				title: "Chemistry",
				role: "Foundation",
				why: "Life is a set of constrained chemical processes.",
				keywords: [
					"chemistry",
					"molecule",
					"reaction",
					"energy"
				]
			},
			{
				title: "Physiology",
				role: "Function",
				why: "Asks how organisms maintain and coordinate internal processes.",
				keywords: [
					"physiology",
					"function",
					"homeostasis",
					"organ"
				]
			},
			{
				title: "Energy",
				role: "Constraint",
				why: "Living systems persist only by capturing and transforming energy.",
				keywords: [
					"energy",
					"metabolism",
					"atp",
					"photosynthesis"
				]
			},
			{
				title: "Medicine",
				role: "Application",
				why: "Applies biological understanding to health and disease.",
				keywords: [
					"medicine",
					"disease",
					"health",
					"treatment"
				]
			}
		],
		relations: [
			[
				"Chemistry",
				"Cells",
				"foundation",
				"Cellular processes are chemical processes under biological constraints."
			],
			[
				"Cells",
				"Genetics",
				"connected",
				"Genes are used, copied, and expressed inside cells."
			],
			[
				"Genetics",
				"Evolution",
				"causal",
				"Heritable variation is the raw material of evolutionary change."
			],
			[
				"Evolution",
				"Ecology",
				"connected",
				"Populations evolve in ecological contexts."
			],
			[
				"Energy",
				"Physiology",
				"causal",
				"Organismal function depends on capturing and allocating energy."
			],
			[
				"Physiology",
				"Medicine",
				"application",
				"Medical reasoning uses physiological models of function and failure."
			],
			[
				"Chemistry",
				"Energy",
				"method",
				"Metabolic energy is understood through chemical reactions."
			],
			[
				"Evolution",
				"Philosophy of Science",
				"connected",
				"Evolution is a major case of historical scientific explanation."
			]
		]
	},
	chemistry: {
		title: "Chemistry",
		thesis: "Chemistry explains how atoms rearrange, why energy matters, and how new substances form.",
		nodes: [
			{
				title: "Atoms",
				role: "Foundation",
				why: "The periodic table organizes the building blocks of chemical matter.",
				keywords: [
					"atom",
					"element",
					"periodic",
					"electron"
				]
			},
			{
				title: "Bonds",
				role: "Structure",
				why: "Chemical bonds are the relationships that hold molecules together.",
				keywords: [
					"bond",
					"covalent",
					"ionic",
					"molecule"
				]
			},
			{
				title: "Reactions",
				role: "Process",
				why: "A reaction is a rearrangement of atoms, not the disappearance of matter.",
				keywords: [
					"reaction",
					"reactant",
					"product",
					"stoichiometry"
				]
			},
			{
				title: "Energy",
				role: "Constraint",
				why: "Whether a reaction happens, and how fast, depends on energy landscapes.",
				keywords: [
					"energy",
					"enthalpy",
					"activation",
					"thermodynamics"
				]
			},
			{
				title: "Equilibrium",
				role: "Balance",
				why: "Many processes settle into a balance of forward and reverse change.",
				keywords: [
					"equilibrium",
					"reversible",
					"balance"
				]
			},
			{
				title: "Organic Chemistry",
				role: "Carbon world",
				why: "Carbon frameworks are the backbone of most biological molecules.",
				keywords: [
					"organic",
					"carbon",
					"functional group"
				]
			},
			{
				title: "Materials",
				role: "Application",
				why: "Designed substances depend on chemical structure and processing.",
				keywords: [
					"materials",
					"polymer",
					"crystal",
					"solid"
				]
			},
			{
				title: "Nucleosynthesis",
				role: "Origin",
				why: "The elements themselves have an astronomical history.",
				keywords: [
					"nucleosynthesis",
					"elements",
					"stars",
					"origin"
				]
			}
		],
		relations: [
			[
				"Atoms",
				"Bonds",
				"foundation",
				"Bonding is the interaction of atomic structure."
			],
			[
				"Bonds",
				"Reactions",
				"causal",
				"Reactions change bonding arrangements."
			],
			[
				"Energy",
				"Reactions",
				"method",
				"Energy analysis tells you what is possible and what is likely."
			],
			[
				"Reactions",
				"Equilibrium",
				"connected",
				"Equilibrium describes the balance of opposing reactions."
			],
			[
				"Organic Chemistry",
				"Biology",
				"application",
				"Biological molecules are carbon-based chemical structures."
			],
			[
				"Nucleosynthesis",
				"Atoms",
				"causal",
				"Stellar processes produce many of the elements chemistry studies."
			],
			[
				"Atoms",
				"Physics",
				"foundation",
				"Atomic structure is a physical description used by chemistry."
			],
			[
				"Materials",
				"Technology",
				"application",
				"Designed materials sit between chemistry and engineering."
			]
		]
	}
};
var RELATION_COPY = {
	current: {
		label: "Current",
		meaning: "The subject you are standing on."
	},
	foundation: {
		label: "Foundation",
		meaning: "Background knowledge that makes this subject easier to understand."
	},
	path: {
		label: "Learning path",
		meaning: "A step that builds understanding in sequence."
	},
	connected: {
		label: "Connected",
		meaning: "A nearby subject whose ideas interact with this one."
	},
	broader: {
		label: "Broader",
		meaning: "A larger field that this subject belongs to."
	},
	causal: {
		label: "Cause / process",
		meaning: "One idea changes, produces, or constrains another."
	},
	application: {
		label: "Application",
		meaning: "Where this knowledge is used or has consequences."
	},
	method: {
		label: "Method",
		meaning: "A tool for describing, testing, or reasoning about the subject."
	},
	contrast: {
		label: "Contrast",
		meaning: "A comparison that shows where a model applies and where it does not."
	},
	discovery: {
		label: "Discovery",
		meaning: "A live exploration result. Investigate the relationship rather than assume it."
	}
};
function relationshipExplanation(type, centerTitle, targetTitle) {
	const templates = {
		foundation: `${targetTitle} is a foundation for ${centerTitle}: background knowledge that makes the current subject easier to understand.`,
		path: `${targetTitle} belongs to the learning path around ${centerTitle}: a step that helps build understanding progressively.`,
		connected: `${targetTitle} is connected to ${centerTitle}: exploring the relationship can show how ideas from the two areas interact.`,
		broader: `${targetTitle} is a broader field around ${centerTitle}: it places the current subject inside a larger area of knowledge.`,
		causal: `${targetTitle} has a process or causal relationship with ${centerTitle}: the connection explains how one idea changes, produces, or constrains another.`,
		application: `${targetTitle} is an application or consequence of ${centerTitle}: knowledge here is used to explain or build something there.`,
		method: `${targetTitle} is a method or formal tool connected to ${centerTitle}: it helps describe, test, or reason about the subject.`,
		contrast: `${targetTitle} provides a contrast with ${centerTitle}: comparing them clarifies where a model applies and where it does not.`,
		discovery: `${targetTitle} came from surrounding exploration results for ${centerTitle}. Its exact relationship should be investigated rather than assumed.`,
		current: `${centerTitle} is the current subject.`
	};
	return templates[type] || templates.discovery;
}
var STOP = /* @__PURE__ */ new Set([
	"a",
	"an",
	"the",
	"what",
	"is",
	"are",
	"of",
	"about",
	"tell",
	"me",
	"learn",
	"to",
	"introduction",
	"intro",
	"basics",
	"basic",
	"que",
	"es",
	"son",
	"del",
	"de",
	"la",
	"el",
	"los",
	"las",
	"una",
	"un",
	"sobre",
	"para",
	"ce",
	"l",
	"les",
	"des",
	"et",
	"ou"
]);
var wikiCache = /* @__PURE__ */ new Map();
var CACHE_MS = 72e4;
function cacheGet(key) {
	const hit = wikiCache.get(key);
	if (!hit) return null;
	if (Date.now() - hit.at > CACHE_MS) {
		wikiCache.delete(key);
		return null;
	}
	return hit.value;
}
function cacheSet(key, value) {
	wikiCache.set(key, {
		at: Date.now(),
		value
	});
}
function normalizeText(value) {
	return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
}
function searchTokens(text) {
	return normalizeText(text).split(" ").filter(Boolean).map((token) => token.length > 4 && token.endsWith("s") ? token.slice(0, -1) : token).filter((token) => !STOP.has(token));
}
function getLocalizedTopic(topicKey, language) {
	const topic = topics[topicKey];
	if (!topic) return null;
	return topic.translations[language] || topic.translations.en || null;
}
function findTopicKey(query) {
	const normalizedQuery = normalizeText(query);
	const simplifiedQuery = searchTokens(query).join(" ");
	const queryTokens = searchTokens(query);
	let bestMatch = null;
	let bestScore = 0;
	for (const topicKey of Object.keys(topics)) {
		const topic = topics[topicKey];
		const candidates = [];
		Object.values(topic.aliases).forEach((list) => candidates.push(...list));
		Object.values(topic.translations).forEach((translation) => {
			if (translation?.title) candidates.push(translation.title);
		});
		for (const candidate of candidates) {
			const normalizedCandidate = normalizeText(candidate);
			const candidateTokens = searchTokens(candidate);
			const candidateSimplified = candidateTokens.join(" ");
			if (!normalizedCandidate) continue;
			if (normalizedCandidate === normalizedQuery) return topicKey;
			if (candidateSimplified && candidateSimplified === simplifiedQuery) return topicKey;
			if (simplifiedQuery && (candidateSimplified.includes(simplifiedQuery) || simplifiedQuery.includes(candidateSimplified))) {
				const substringScore = Math.min(1, simplifiedQuery.length / Math.max(candidateSimplified.length, 1));
				if (substringScore > bestScore) {
					bestScore = substringScore;
					bestMatch = topicKey;
				}
			}
			if (queryTokens.length === 1 && candidateTokens.includes(queryTokens[0])) return topicKey;
		}
	}
	return bestScore >= .72 ? bestMatch : null;
}
function getDeepKnowledgeContext(localKey, centerTitle) {
	if (localKey && deepKnowledgeRegions[localKey]) return deepKnowledgeRegions[localKey];
	const wanted = normalizeText(centerTitle);
	for (const candidate of Object.values(deepKnowledgeRegions)) if (candidate.nodes.some((node) => normalizeText(node.title) === wanted)) return candidate;
	return null;
}
function wikiBase(language) {
	return `https://${language || "en"}.wikipedia.org`;
}
async function fetchJson(url, signal) {
	const response = await fetch(url, {
		signal,
		headers: { Accept: "application/json" }
	});
	if (!response.ok) throw new Error(`Source request failed (${response.status})`);
	return response.json();
}
async function searchWikipedia(query, language, signal) {
	const key = `search:${language}:${normalizeText(query)}`;
	const cached = cacheGet(key);
	if (cached) return cached;
	const restUrl = `${wikiBase(language)}/w/rest.php/v1/search/page?q=${encodeURIComponent(query)}&limit=8`;
	try {
		const pages = ((await fetchJson(restUrl, signal)).pages || []).filter((page) => page.title).map((page) => ({
			title: page.title,
			description: page.description,
			excerpt: page.excerpt?.replace(/<[^>]+>/g, "")
		}));
		cacheSet(key, pages);
		return pages;
	} catch (error) {
		if (signal?.aborted) throw error;
		const pages = ((await fetchJson(`${wikiBase(language)}/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=8&format=json&origin=*`, signal)).query?.search || []).map((item) => ({
			title: item.title,
			excerpt: item.snippet?.replace(/<[^>]+>/g, "")
		}));
		cacheSet(key, pages);
		return pages;
	}
}
async function getWikipediaSummary(title, language, signal) {
	const key = `sum:${language}:${normalizeText(title)}`;
	const cached = cacheGet(key);
	if (cached) return cached;
	const url = `${wikiBase(language)}/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
	try {
		const data = await fetchJson(url, signal);
		const summary = {
			title: data.title,
			description: data.description || "",
			extract: data.extract || "",
			url: data.content_urls?.desktop?.page || `${wikiBase(language)}/wiki/${encodeURIComponent(data.title)}`,
			image: data.thumbnail?.source
		};
		cacheSet(key, summary);
		return summary;
	} catch (error) {
		if (signal?.aborted) throw error;
		const data = await fetchJson(`${wikiBase(language)}/w/api.php?action=query&prop=extracts|info&exintro=1&explaintext=1&inprop=url&format=json&origin=*&titles=${encodeURIComponent(title)}`, signal);
		const page = Object.values(data.query?.pages || {})[0];
		if (!page?.title) throw error;
		const summary = {
			title: page.title,
			description: "",
			extract: page.extract || "",
			url: page.fullurl || `${wikiBase(language)}/wiki/${encodeURIComponent(page.title)}`
		};
		cacheSet(key, summary);
		return summary;
	}
}
async function getExpandedIntro(title, language, signal) {
	const key = `intro:${language}:${normalizeText(title)}`;
	const cached = cacheGet(key);
	if (cached) return cached;
	try {
		const data = await fetchJson(`${wikiBase(language)}/w/api.php?action=query&prop=extracts&explaintext=1&exintro=1&format=json&origin=*&titles=${encodeURIComponent(title)}`, signal);
		const extract = Object.values(data.query?.pages || {})[0]?.extract?.trim() || "";
		cacheSet(key, extract);
		return extract;
	} catch {
		return "";
	}
}
async function getBooks(topic, signal) {
	const key = `books:${normalizeText(topic)}`;
	const cached = cacheGet(key);
	if (cached) return cached;
	try {
		const books = ((await fetchJson("https://openlibrary.org/search.json?q=" + encodeURIComponent(`${topic} ebook_access:public`) + "&fields=title,author_name,first_publish_year,key,cover_i&limit=4", signal)).docs || []).map((book) => {
			const workKey = book.key ? book.key.replace("/works/", "") : "";
			return {
				title: book.title || "Untitled book",
				author: book.author_name?.[0] || "Unknown author",
				year: book.first_publish_year ? String(book.first_publish_year) : "Unknown year",
				url: workKey ? `https://openlibrary.org/works/${workKey}` : "https://openlibrary.org/",
				cover: book.cover_i ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` : ""
			};
		});
		cacheSet(key, books);
		return books;
	} catch {
		return [];
	}
}
async function getResearch(topic, signal) {
	const key = `research:${normalizeText(topic)}`;
	const cached = cacheGet(key);
	if (cached) return cached;
	try {
		const works = ((await fetchJson(`https://api.openalex.org/works?search=${encodeURIComponent(topic)}&per-page=4&sort=relevance_score:desc`, signal)).results || []).filter((work) => work.title).map((work) => ({
			title: work.title || "",
			year: work.publication_year ? String(work.publication_year) : "Year unknown",
			venue: work.primary_location?.source?.display_name || "Research work",
			url: work.doi || work.primary_location?.landing_page_url || `https://openalex.org/works?search=${encodeURIComponent(topic)}`
		}));
		cacheSet(key, works);
		return works;
	} catch {
		return [];
	}
}
function segmentOverview(overview) {
	const clean = String(overview || "").replace(/\s+/g, " ").trim();
	if (!clean) return [];
	const sentences = clean.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [clean];
	const groups = [];
	let current = "";
	for (const sentence of sentences) {
		const part = sentence.trim();
		if (!part) continue;
		if (current && current.length + part.length + 1 > 230) {
			groups.push(current);
			current = part;
		} else current = current ? `${current} ${part}` : part;
	}
	if (current) groups.push(current);
	const labels = [
		"The big picture",
		"What it studies",
		"Why it matters",
		"In context"
	];
	return groups.slice(0, 4).map((text, index) => ({
		label: labels[index] || "More",
		text
	}));
}
function createExplorationPath(mainTitle, relatedPages, level) {
	const path = [mainTitle, ...relatedPages.slice(0, 4).map((page) => page.title)];
	const count = level === "advanced" ? 5 : level === "intermediate" ? 4 : 3;
	return path.slice(0, count);
}
function addUnique(groups, title, type, centerNorm) {
	const clean = String(title || "").trim();
	const norm = normalizeText(clean);
	if (!norm || norm === centerNorm) return;
	if (Object.values(groups).flat().some((item) => normalizeText(item.title) === norm)) return;
	groups[type].push({
		title: clean,
		type,
		key: findTopicKey(clean)
	});
}
function buildKnowledgeGraph(options) {
	const { localTopic, localKey, level, relatedPages, centerTitle, perspective } = options;
	const centerNorm = normalizeText(centerTitle);
	const groups = {
		foundation: [],
		path: [],
		connected: [],
		broader: [],
		causal: [],
		application: [],
		method: [],
		contrast: []
	};
	if (localTopic) {
		(localTopic.prerequisites || []).slice(0, 5).forEach((item) => addUnique(groups, item, "foundation", centerNorm));
		(localTopic.learningPath?.[level] || localTopic.learningPath?.beginner || []).slice(0, 6).forEach((item) => addUnique(groups, item, "path", centerNorm));
		(localTopic.related || []).slice(0, 7).forEach((item) => addUnique(groups, item, "connected", centerNorm));
		if (localTopic.category) addUnique(groups, localTopic.category, "broader", centerNorm);
		const deep = getDeepKnowledgeContext(localKey, centerTitle);
		if (deep) deep.relations.filter(([from, to]) => normalizeText(from) === centerNorm || normalizeText(to) === centerNorm).forEach(([from, to, type]) => {
			const target = normalizeText(from) === centerNorm ? to : from;
			const mapped = [
				"causal",
				"application",
				"method",
				"contrast"
			].includes(type) ? type : "connected";
			addUnique(groups, target, mapped, centerNorm);
		});
	} else relatedPages.slice(0, 10).forEach((page) => addUnique(groups, page.title, "connected", centerNorm));
	if (perspective === "out") (localKey && knowledgeMapParents[localKey] || []).forEach((item) => addUnique(groups, item, "broader", centerNorm));
	let selected = perspective === "in" ? [
		...groups.foundation,
		...groups.path,
		...groups.causal,
		...groups.application,
		...groups.method
	] : perspective === "out" ? [
		...groups.broader,
		...groups.connected,
		...groups.application,
		...groups.causal
	] : [
		...groups.foundation,
		...groups.path,
		...groups.connected,
		...groups.broader
	];
	if (perspective === "nearby" && selected.length < 5) [
		...groups.connected,
		...groups.path,
		...groups.foundation,
		...groups.causal,
		...groups.application,
		...groups.method,
		...groups.broader
	].forEach((item) => {
		if (selected.length >= 10) return;
		if (!selected.some((existing) => normalizeText(existing.title) === normalizeText(item.title))) selected.push(item);
	});
	const seen = /* @__PURE__ */ new Set([centerNorm]);
	const unique = selected.filter((item) => {
		const norm = normalizeText(item.title);
		if (!norm || seen.has(norm)) return false;
		seen.add(norm);
		return true;
	}).slice(0, 12);
	const center = {
		x: 700,
		y: 390
	};
	const radius = unique.length <= 6 ? 230 : 280;
	const nodes = unique.map((relation, index) => {
		const angle = -Math.PI / 2 + index * Math.PI * 2 / Math.max(unique.length, 1);
		return {
			title: relation.title,
			type: relation.type,
			key: relation.key,
			x: center.x + Math.cos(angle) * radius,
			y: center.y + Math.sin(angle) * radius,
			explanation: relationshipExplanation(relation.type, centerTitle, relation.title)
		};
	});
	const outer = [];
	if (perspective === "nearby" && localTopic) {
		const outerSeen = /* @__PURE__ */ new Set([centerNorm, ...nodes.map((node) => normalizeText(node.title))]);
		nodes.forEach((parent, index) => {
			if (!parent.key || outer.length >= 8) return;
			(getLocalizedTopic(parent.key, "en")?.related || []).slice(0, 2).forEach((title) => {
				const norm = normalizeText(title);
				if (!norm || outerSeen.has(norm) || outer.length >= 8) return;
				outerSeen.add(norm);
				const angle = -Math.PI / 2 + index * Math.PI * 2 / Math.max(nodes.length, 1) + .25;
				outer.push({
					title,
					type: "discovery",
					key: findTopicKey(title),
					x: center.x + Math.cos(angle) * 420,
					y: center.y + Math.sin(angle) * 420,
					explanation: relationshipExplanation("discovery", centerTitle, title)
				});
			});
		});
	}
	return {
		center: {
			title: centerTitle,
			type: "current",
			x: center.x,
			y: center.y,
			explanation: `${centerTitle} is the current subject.`
		},
		nodes,
		outer
	};
}
function wrapNodeTitle(title, maxLength = 16) {
	const words = String(title || "").split(/\s+/);
	const lines = [];
	let current = "";
	for (const word of words) if (!current) current = word;
	else if ((current + " " + word).length <= maxLength) current += ` ${word}`;
	else {
		lines.push(current);
		current = word;
	}
	if (current) lines.push(current);
	return lines.slice(0, 3);
}
function shuffle(items) {
	const copy = [...items];
	for (let i = copy.length - 1; i > 0; i -= 1) {
		const j = Math.floor(Math.random() * (i + 1));
		[copy[i], copy[j]] = [copy[j], copy[i]];
	}
	return copy;
}
function buildKnowledgeCheck(localTopic, level, relatedPages, currentTitle) {
	const path = localTopic.learningPath[level] || localTopic.learningPath.beginner || [];
	const concepts = (localTopic.concepts || []).filter(Boolean);
	const prerequisites = (localTopic.prerequisites || []).filter(Boolean);
	if (!concepts.length || !prerequisites.length || path.length < 2) return null;
	const otherConcepts = [];
	Object.keys(topics).forEach((key) => {
		const candidate = getLocalizedTopic(key, "en");
		if (!candidate || candidate.title === localTopic.title) return;
		(candidate.concepts || []).forEach((item) => {
			if (item && !otherConcepts.includes(item)) otherConcepts.push(item);
		});
	});
	const related = relatedPages.map((item) => item.title).filter(Boolean);
	const nextStep = path[Math.max(1, path.findIndex((item) => normalizeText(item) === normalizeText(currentTitle)) + 1)] || path[1];
	const conceptOptions = shuffle([concepts[0], ...otherConcepts.filter((item) => !concepts.includes(item)).slice(0, 2)]).slice(0, 3);
	const nextOptions = shuffle([nextStep, ...path.filter((item) => item !== nextStep && item !== currentTitle).slice(0, 2)]).slice(0, 3);
	const prereqOptions = shuffle([prerequisites[0], ...[...related, ...path.slice(2)].filter((item) => item && !prerequisites.includes(item)).slice(0, 2)]).slice(0, 3);
	const applicationAnswer = concepts[1] || concepts[0];
	const applicationOptions = shuffle([
		applicationAnswer,
		concepts[0],
		prerequisites[0]
	].filter((value, index, array) => value && array.indexOf(value) === index)).slice(0, 3);
	const connectionAnswer = related.find((item) => normalizeText(item) !== normalizeText(currentTitle)) || localTopic.related[0] || nextStep;
	const connectionOptions = shuffle([
		connectionAnswer,
		...related,
		...path
	].filter((value, index, array) => value && array.indexOf(value) === index)).slice(0, 3);
	return [
		{
			prompt: `Which is one of the core ideas of ${currentTitle}?`,
			options: conceptOptions,
			correct: concepts[0],
			explanation: `${concepts[0]} is one of the core ideas currently defined for ${currentTitle}.`
		},
		{
			prompt: "What comes next in the selected learning path?",
			options: nextOptions,
			correct: nextStep,
			explanation: `${nextStep} is the next step in the ${level} path for ${localTopic.title}.`
		},
		{
			prompt: `Which is a prerequisite for ${currentTitle}?`,
			options: prereqOptions,
			correct: prerequisites[0],
			explanation: `${prerequisites[0]} is listed as background knowledge that makes this topic easier.`
		},
		{
			prompt: `Which idea would you use when applying what you learned about ${currentTitle}?`,
			options: applicationOptions,
			correct: applicationAnswer,
			explanation: `${applicationAnswer} is a concept you would actually use, not only recognize.`
		},
		{
			prompt: `Which subject is meaningfully connected to ${currentTitle}?`,
			options: connectionOptions,
			correct: connectionAnswer,
			explanation: `${connectionAnswer} is connected to ${currentTitle} in the authored landscape.`
		}
	];
}
function classifySource(url, name = "") {
	const value = `${url} ${name}`.toLowerCase();
	if (/(nasa\.gov|esa\.int|noaa\.gov|nih\.gov|cern\.ch)/.test(value)) return {
		label: "Institutional",
		why: "Produced by a scientific or public institution."
	};
	if (value.includes("khanacademy.org")) return {
		label: "Guided learning",
		why: "Designed for explanations and practice, not just reference."
	};
	if (value.includes("openstax.org")) return {
		label: "Open textbook",
		why: "Free structured textbook material for deeper study."
	};
	if (value.includes("wikipedia.org")) return {
		label: "Reference",
		why: "A broad starting point with definitions, context, and linked concepts."
	};
	if (value.includes("openlibrary.org")) return {
		label: "Books",
		why: "A catalog for discovering books and editions related to the topic."
	};
	if (value.includes("plato.stanford.edu") || value.includes("iep.utm.edu")) return {
		label: "Reference encyclopedia",
		why: "Specialist reference writing with citations and debates."
	};
	return {
		label: "Further exploration",
		why: "An additional resource selected for exploring the subject."
	};
}
function scoreExplanation(title, localKey, text) {
	const keywords = (getDeepKnowledgeContext(localKey, title)?.nodes.find((item) => normalizeText(item.title) === normalizeText(title)))?.keywords || [];
	const lower = text.toLowerCase();
	const matched = keywords.filter((keyword) => lower.includes(keyword.toLowerCase()));
	return {
		keywords,
		matched,
		coverage: new Set(matched.map((item) => item.toLowerCase())).size
	};
}
function topicCategories(language) {
	const groups = /* @__PURE__ */ new Map();
	Object.keys(topics).forEach((key) => {
		const data = getLocalizedTopic(key, language);
		if (!data) return;
		const list = groups.get(data.category) || [];
		list.push({
			key,
			title: data.title
		});
		groups.set(data.category, list);
	});
	return [...groups.entries()].map(([category, items]) => ({
		category,
		items
	}));
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[12px] text-sm font-semibold transition-colors duration-150 disabled:pointer-events-none disabled:opacity-45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:brightness-110",
			secondary: "bg-bg-subtle text-fg hover:bg-bg-elevated border border-border",
			ghost: "bg-transparent text-fg hover:bg-bg-subtle",
			outline: "border border-border bg-transparent text-fg hover:bg-bg-subtle",
			paper: "bg-surface text-ink hover:bg-surface-2 border border-line",
			inverse: "bg-fg text-bg hover:bg-primary-soft"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	ref,
	className: cn("flex h-12 w-full rounded-[12px] border border-line bg-surface px-4 text-base text-ink outline-none placeholder:text-ink-muted focus:border-primary focus:ring-2 focus:ring-primary/20", className),
	...props
}));
Input.displayName = "Input";
var KEYS = {
	language: "eaglesLanguage",
	level: "eaglesLearningLevel",
	recent: "eaglesRecentSearches",
	topics: "eaglesSavedTopics",
	resources: "eaglesSavedResources",
	books: "eaglesSavedBooks",
	atlas: "eaglesKnowledgeAtlas",
	feedback: "eaglesStudyFeedback",
	notes: "eaglesStudyNotes"
};
function readJSON(key, fallback) {
	if (typeof window === "undefined") return fallback;
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return fallback;
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
}
function writeJSON(key, value) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(key, JSON.stringify(value));
	} catch {}
}
function atlasKey(title, language) {
	return `${language}::${title.toLowerCase().trim()}`;
}
var suggestionTimer = null;
var suggestionRequest = 0;
var exploreRequest = 0;
var exploreAbort = null;
function curatedFallback(query, language, level) {
	const key = findTopicKey(query);
	if (!key) return null;
	const local = getLocalizedTopic(key, language);
	if (!local) return null;
	return {
		query,
		level,
		language,
		summary: {
			title: local.title,
			description: local.category,
			extract: local.overview,
			url: `https://${language}.wikipedia.org/wiki/${encodeURIComponent(local.title)}`
		},
		relatedPages: (local.related || []).map((title) => ({ title })),
		localKey: key,
		localTopic: local,
		books: [],
		fetchedAt: Date.now(),
		usedFallback: true
	};
}
var usePanorama = create((set, get) => ({
	hydrated: false,
	language: "en",
	level: "beginner",
	query: "",
	suggestions: [],
	loading: false,
	suggesting: false,
	error: null,
	result: null,
	research: [],
	researchLoading: false,
	tab: "understand",
	mapPerspective: "nearby",
	presentationOpen: false,
	recentSearches: [],
	savedTopics: [],
	savedResources: [],
	savedBooks: [],
	atlas: [],
	hydrate: () => {
		if (get().hydrated) return;
		const language = readJSON(KEYS.language, "en");
		const level = readJSON(KEYS.level, "beginner");
		set({
			hydrated: true,
			language: typeof language === "string" ? language : "en",
			level: [
				"beginner",
				"intermediate",
				"advanced"
			].includes(level) ? level : "beginner",
			recentSearches: readJSON(KEYS.recent, []),
			savedTopics: readJSON(KEYS.topics, []),
			savedResources: readJSON(KEYS.resources, []),
			savedBooks: readJSON(KEYS.books, []),
			atlas: readJSON(KEYS.atlas, [])
		});
	},
	setLanguage: (language) => {
		set({ language });
		writeJSON(KEYS.language, language);
		const { query, result } = get();
		if (query || result) get().explore(query || result?.summary.title || "");
	},
	setLevel: (level) => {
		set({ level });
		writeJSON(KEYS.level, level);
		const { result } = get();
		if (result) get().explore(result.query || result.summary.title);
	},
	setQuery: (query) => set({ query }),
	setTab: (tab) => set({ tab }),
	setMapPerspective: (mapPerspective) => set({ mapPerspective }),
	setPresentationOpen: (presentationOpen) => set({ presentationOpen }),
	clearSuggestions: () => set({ suggestions: [] }),
	loadSuggestions: (query) => {
		set({ query });
		if (suggestionTimer) clearTimeout(suggestionTimer);
		if (query.trim().length < 2) {
			set({
				suggestions: [],
				suggesting: false
			});
			return;
		}
		set({ suggesting: true });
		const requestId = ++suggestionRequest;
		const language = get().language;
		suggestionTimer = setTimeout(() => {
			(async () => {
				try {
					const pages = await searchWikipedia(query.trim(), language);
					if (requestId !== suggestionRequest) return;
					set({
						suggestions: pages.map((page) => page.title).slice(0, 7),
						suggesting: false
					});
				} catch {
					if (requestId !== suggestionRequest) return;
					set({ suggesting: false });
				}
			})();
		}, 180);
	},
	explore: async (rawQuery) => {
		const query = rawQuery.trim();
		if (suggestionTimer) clearTimeout(suggestionTimer);
		suggestionRequest += 1;
		set({
			query,
			suggestions: [],
			suggesting: false,
			error: null,
			tab: "understand",
			mapPerspective: "nearby"
		});
		if (!query) {
			set({
				error: "Enter a subject to explore.",
				loading: false
			});
			return;
		}
		if (exploreAbort) exploreAbort.abort();
		const abort = new AbortController();
		exploreAbort = abort;
		const requestId = ++exploreRequest;
		const { language, level } = get();
		const immediate = curatedFallback(query, language, level);
		set({
			loading: true,
			error: null,
			result: immediate ? {
				...immediate,
				books: get().result?.query === query ? get().result?.books || [] : []
			} : get().result
		});
		try {
			const pages = await searchWikipedia(query, language, abort.signal);
			if (requestId !== exploreRequest) return;
			let summaryTitle = pages[0]?.title;
			if (!summaryTitle && immediate) summaryTitle = immediate.summary.title;
			if (!summaryTitle) {
				set({
					loading: false,
					error: "No results found. Try a broader subject name."
				});
				return;
			}
			const [summary, expanded, books] = await Promise.all([
				getWikipediaSummary(summaryTitle, language, abort.signal),
				getExpandedIntro(summaryTitle, language, abort.signal),
				getBooks(query, abort.signal)
			]);
			if (requestId !== exploreRequest) return;
			const localKey = findTopicKey(query) || findTopicKey(summary.title);
			const localTopic = localKey ? getLocalizedTopic(localKey, language) : null;
			const extract = localTopic?.overview || expanded || summary.extract;
			const result = {
				query,
				level,
				language,
				summary: {
					...summary,
					extract,
					description: summary.description || localTopic?.category || ""
				},
				relatedPages: pages.slice(1),
				localKey,
				localTopic,
				books,
				fetchedAt: Date.now(),
				usedFallback: false
			};
			const recentSearches = [{
				query,
				pageTitle: summary.title,
				level,
				language,
				timestamp: Date.now()
			}, ...get().recentSearches.filter((item) => !(item.query === query && item.language === language))].slice(0, 10);
			const atlas = upsertAtlas(get().atlas, summary.title, language);
			writeJSON(KEYS.recent, recentSearches);
			writeJSON(KEYS.atlas, atlas);
			set({
				result,
				recentSearches,
				atlas,
				loading: false,
				error: null,
				research: [],
				researchLoading: true
			});
			getResearch(query, abort.signal).then((research) => {
				if (requestId !== exploreRequest) return;
				set({
					research,
					researchLoading: false
				});
			});
		} catch (error) {
			if (abort.signal.aborted || requestId !== exploreRequest) return;
			const fallback = curatedFallback(query, language, level);
			if (fallback) {
				const atlas = upsertAtlas(get().atlas, fallback.summary.title, language);
				writeJSON(KEYS.atlas, atlas);
				set({
					result: fallback,
					atlas,
					loading: false,
					error: "Live sources were unavailable, so the curated topic is shown instead.",
					researchLoading: false
				});
				return;
			}
			set({
				loading: false,
				error: error instanceof Error ? "The live source could not be reached. Check the name and try again." : "Something went wrong while exploring this subject."
			});
		}
	},
	toggleSavedTopic: () => {
		const { result, language, level, savedTopics } = get();
		if (!result) return;
		const topic = {
			title: result.summary.title,
			description: result.summary.description,
			url: result.summary.url,
			image: result.summary.image || "",
			category: result.localTopic?.category || "",
			language,
			level,
			query: result.query
		};
		const next = savedTopics.some((item) => item.url === topic.url && item.language === language) ? savedTopics.filter((item) => !(item.url === topic.url && item.language === language)) : [topic, ...savedTopics].slice(0, 50);
		writeJSON(KEYS.topics, next);
		set({ savedTopics: next });
	},
	toggleSavedResource: (resource) => {
		const next = get().savedResources.some((item) => item.url === resource.url) ? get().savedResources.filter((item) => item.url !== resource.url) : [resource, ...get().savedResources].slice(0, 50);
		writeJSON(KEYS.resources, next);
		set({ savedResources: next });
	},
	toggleSavedBook: (book) => {
		const next = get().savedBooks.some((item) => item.url === book.url) ? get().savedBooks.filter((item) => item.url !== book.url) : [book, ...get().savedBooks].slice(0, 50);
		writeJSON(KEYS.books, next);
		set({ savedBooks: next });
	},
	removeRecent: (query, language) => {
		const next = get().recentSearches.filter((item) => !(item.query === query && item.language === language));
		writeJSON(KEYS.recent, next);
		set({ recentSearches: next });
	},
	removeSavedTopic: (url, language) => {
		const next = get().savedTopics.filter((item) => !(item.url === url && item.language === language));
		writeJSON(KEYS.topics, next);
		set({ savedTopics: next });
	},
	removeSavedResource: (url) => {
		const next = get().savedResources.filter((item) => item.url !== url);
		writeJSON(KEYS.resources, next);
		set({ savedResources: next });
	},
	removeSavedBook: (url) => {
		const next = get().savedBooks.filter((item) => item.url !== url);
		writeJSON(KEYS.books, next);
		set({ savedBooks: next });
	},
	clearLearningData: () => {
		writeJSON(KEYS.recent, []);
		writeJSON(KEYS.topics, []);
		writeJSON(KEYS.resources, []);
		writeJSON(KEYS.books, []);
		writeJSON(KEYS.atlas, []);
		writeJSON(KEYS.feedback, []);
		writeJSON(KEYS.notes, []);
		set({
			recentSearches: [],
			savedTopics: [],
			savedResources: [],
			savedBooks: [],
			atlas: []
		});
	},
	setAtlasStatus: (title, status) => {
		const atlas = upsertAtlas(get().atlas, title, get().language, {
			status,
			force: true,
			countVisit: false
		});
		writeJSON(KEYS.atlas, atlas);
		set({ atlas });
	},
	recordEvidence: (title, evidence) => {
		const language = get().language;
		let atlas = upsertAtlas(get().atlas, title, language, { countVisit: false });
		atlas = atlas.map((item) => {
			if (atlasKey(item.title, item.language) !== atlasKey(title, language)) return item;
			const nextEvidence = {
				...item.evidence,
				...evidence,
				lastChecked: Date.now()
			};
			const score = Number(nextEvidence.score || 0);
			const verified = Number(nextEvidence.total || 0) >= 5 && score >= 4 && nextEvidence.explanationSubmitted && nextEvidence.connectionCompleted && Number(nextEvidence.explanationCoverage || 0) >= 2;
			return {
				...item,
				evidence: nextEvidence,
				status: verified ? "verified" : item.status
			};
		});
		writeJSON(KEYS.atlas, atlas);
		set({ atlas });
	},
	saveExplanation: (title, text) => {
		const { result } = get();
		const scored = scoreExplanation(title, result?.localKey || findTopicKey(title), text);
		get().recordEvidence(title, {
			explanationSubmitted: true,
			explanationText: text,
			explanationCoverage: scored.coverage,
			matchedConcepts: scored.matched
		});
		return scored;
	},
	saveFeedback: (topic, usefulness, note) => {
		const feedback = readJSON(KEYS.feedback, []);
		feedback.push({
			id: String(Date.now()),
			topic,
			usefulness,
			note,
			timestamp: (/* @__PURE__ */ new Date()).toISOString()
		});
		writeJSON(KEYS.feedback, feedback.slice(-100));
	},
	saveNote: (note) => {
		const notes = readJSON(KEYS.notes, []);
		notes.push({
			note,
			timestamp: (/* @__PURE__ */ new Date()).toISOString()
		});
		writeJSON(KEYS.notes, notes.slice(-50));
	},
	exportEvidence: () => {
		const payload = {
			atlas: get().atlas,
			feedback: readJSON(KEYS.feedback, []),
			studyNotes: readJSON(KEYS.notes, []),
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			methodology: "Local prototype evidence. Verification uses quiz performance, a connection question, an explanation, and transparent keyword coverage against authored concepts. It is evidence of demonstrated work, not a claim of mastery."
		};
		const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "eagles-panorama-study-evidence.json";
		document.body.appendChild(a);
		a.click();
		a.remove();
		URL.revokeObjectURL(url);
	}
}));
function upsertAtlas(atlas, title, language, options = {}) {
	if (!title) return atlas;
	const key = atlasKey(title, language);
	const next = [...atlas];
	const index = next.findIndex((item) => atlasKey(item.title, item.language) === key);
	if (index < 0) next.push({
		title,
		language,
		status: options.status || "explored",
		firstSeen: Date.now(),
		lastSeen: Date.now(),
		visits: options.countVisit === false ? 0 : 1
	});
	else {
		const current = next[index];
		next[index] = {
			...current,
			title,
			lastSeen: Date.now(),
			visits: current.visits + (options.countVisit === false ? 0 : 1),
			status: options.status && (options.force || current.status === "explored") ? options.status : current.status
		};
	}
	return next.slice(-100);
}
function isTopicSaved(state) {
	const result = state.result;
	if (!result) return false;
	return state.savedTopics.some((item) => item.url === result.summary.url && item.language === state.language);
}
function currentQuestions(result) {
	if (!result?.localTopic) return null;
	return buildKnowledgeCheck(result.localTopic, result.level, result.relatedPages, result.summary.title);
}
function nextPathStep(result) {
	if (!result) return null;
	const path = result.localTopic?.learningPath[result.level] || result.localTopic?.learningPath.beginner;
	if (path && path.length) {
		const index = path.findIndex((item) => item.toLowerCase() === result.summary.title.toLowerCase());
		return path[Math.max(0, index) + 1] || path[1] || null;
	}
	return result.relatedPages[0]?.title || null;
}
var TYPE_COLOR = {
	current: {
		fill: "#cfe8e4",
		stroke: "#1f9a93",
		edge: "#1f9a93"
	},
	foundation: {
		fill: "#dcefe0",
		stroke: "#3d7a58",
		edge: "#3d7a58"
	},
	path: {
		fill: "#d7e6f5",
		stroke: "#3d6494",
		edge: "#3d6494"
	},
	connected: {
		fill: "#e4dced",
		stroke: "#6a5a86",
		edge: "#6a5a86"
	},
	broader: {
		fill: "#f0e2d2",
		stroke: "#8a6744",
		edge: "#8a6744"
	},
	causal: {
		fill: "#d4eceb",
		stroke: "#2f7c7d",
		edge: "#2f7c7d"
	},
	application: {
		fill: "#f3e7d2",
		stroke: "#8d6a3c",
		edge: "#8d6a3c"
	},
	method: {
		fill: "#e6dcf0",
		stroke: "#6d568c",
		edge: "#6d568c"
	},
	contrast: {
		fill: "#f1dcd9",
		stroke: "#8d5753",
		edge: "#8d5753"
	},
	discovery: {
		fill: "#e8eef2",
		stroke: "#5d7380",
		edge: "#5d7380"
	}
};
var PERSPECTIVE_NOTE = {
	nearby: "Connected subjects reveal nearby areas of knowledge.",
	in: "More specific steps from this subject's learning path and foundations.",
	out: "Broader fields that place this subject in a larger landscape."
};
function KnowledgeMap({ result, perspective, onPerspective, onOpen }) {
	const [scale, setScale] = (0, import_react.useState)(1);
	const graph = (0, import_react.useMemo)(() => {
		if (!result) return null;
		return buildKnowledgeGraph({
			localTopic: result.localTopic,
			localKey: result.localKey,
			level: result.level,
			relatedPages: result.relatedPages,
			centerTitle: result.summary.title,
			perspective
		});
	}, [result, perspective]);
	if (!result || !graph) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[26px] border border-line bg-map p-6 text-ink shadow-[0_18px_44px_rgba(4,22,36,0.12)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl text-ink",
			children: "Knowledge Map"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-ink-muted",
			children: "Search a topic first, then use this map to move through the landscape around it."
		})]
	});
	const all = [
		graph.center,
		...graph.nodes,
		...graph.outer
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[26px] border border-line bg-map p-4 text-ink shadow-[0_18px_44px_rgba(4,22,36,0.12)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-ink",
					children: "Knowledge Map"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 max-w-2xl text-sm leading-6 text-ink-muted",
					children: [
						"See how ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-ink",
							children: result.summary.title
						}),
						" fits into the surrounding landscape. Different connections mean different things."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "paper",
							size: "icon",
							"aria-label": "Enlarge map",
							onClick: () => setScale((s) => Math.min(1.8, s * 1.18)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "paper",
							size: "icon",
							"aria-label": "Shrink map",
							onClick: () => setScale((s) => Math.max(.72, s * .85)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "paper",
							size: "icon",
							"aria-label": "Reset map size",
							onClick: () => setScale(1),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					"out",
					"nearby",
					"in"
				].map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onPerspective(mode),
					className: cn("min-h-11 rounded-full border px-4 text-sm font-semibold", perspective === mode ? "border-primary bg-primary-soft text-primary" : "border-line bg-surface text-ink-muted"),
					children: mode === "out" ? "Zoom out" : mode === "in" ? "Zoom in" : "Nearby"
				}, mode))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-ink-muted",
				children: PERSPECTIVE_NOTE[perspective]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-x-4 gap-y-2 text-xs text-ink-muted",
				children: Object.keys(RELATION_COPY).filter((key) => key !== "current" && key !== "discovery").map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
						className: "inline-block h-0.5 w-6 rounded-full",
						style: { background: TYPE_COLOR[key]?.stroke }
					}), RELATION_COPY[key].label]
				}, key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 overflow-hidden rounded-[20px] border border-line bg-[#f7fbfd]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 1400 780",
					className: "h-[430px] w-full sm:h-[590px]",
					role: "img",
					"aria-label": "Interactive knowledge graph",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						transform: `translate(700 390) scale(${scale}) translate(-700 -390)`,
						children: [
							graph.nodes.map((node) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: graph.center.x,
								y1: graph.center.y,
								x2: node.x,
								y2: node.y,
								stroke: TYPE_COLOR[node.type]?.edge || "#5d7380",
								strokeWidth: node.type === "foundation" || node.type === "path" ? 3 : 2.4
							}, `e-${node.title}`)),
							graph.outer.map((node, index) => {
								const parent = graph.nodes[index % Math.max(graph.nodes.length, 1)];
								if (!parent) return null;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: parent.x,
									y1: parent.y,
									x2: node.x,
									y2: node.y,
									stroke: "#7f94a1",
									strokeWidth: 1.5,
									strokeDasharray: "5 5"
								}, `o-${node.title}`);
							}),
							all.map((node) => {
								const colors = TYPE_COLOR[node.type] || TYPE_COLOR.discovery;
								const radius = node.type === "current" ? 92 : 70;
								const lines = wrapNodeTitle(node.title);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
									tabIndex: 0,
									role: "button",
									"aria-label": `Explore ${node.title}`,
									className: "cursor-pointer outline-none",
									onClick: () => onOpen(node.title),
									onKeyDown: (event) => {
										if (event.key === "Enter" || event.key === " ") {
											event.preventDefault();
											onOpen(node.title);
										}
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: node.x,
											cy: node.y,
											r: radius,
											fill: colors.fill,
											stroke: colors.stroke,
											strokeWidth: node.type === "current" ? 3 : 2
										}),
										lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
											x: node.x,
											y: node.y + (index - (lines.length - 1) / 2) * 16,
											textAnchor: "middle",
											fill: "#142b3b",
											fontSize: node.type === "current" ? 16 : 14,
											fontWeight: 700,
											children: line
										}, line + index)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
											x: node.x,
											y: node.y + radius - 16,
											textAnchor: "middle",
											fill: "#4e6674",
											fontSize: 10,
											fontWeight: 600,
											children: RELATION_COPY[node.type]?.label || node.type
										})
									]
								}, node.title);
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-[16px] border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-ink",
					children: "Explore without clicking the map"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: all.filter((node) => node.type !== "current").map((node) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpen(node.title),
						className: "max-w-full rounded-[12px] border border-line bg-surface-2 px-3 py-2 text-left text-sm text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: node.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 block text-xs text-ink-muted",
							children: [
								RELATION_COPY[node.type]?.label,
								": ",
								node.explanation
							]
						})]
					}, node.title))
				})]
			})
		]
	});
}
var STATUS_LABEL = {
	explored: "Explored",
	learning: "Learning",
	mastered: "Mastered (self)",
	verified: "Verified"
};
function LearningAtlas({ onOpen }) {
	const atlas = usePanorama((s) => s.atlas);
	const savedTopics = usePanorama((s) => s.savedTopics);
	const savedResources = usePanorama((s) => s.savedResources);
	const savedBooks = usePanorama((s) => s.savedBooks);
	const recentSearches = usePanorama((s) => s.recentSearches);
	const setAtlasStatus = usePanorama((s) => s.setAtlasStatus);
	const removeRecent = usePanorama((s) => s.removeRecent);
	const removeSavedTopic = usePanorama((s) => s.removeSavedTopic);
	const removeSavedResource = usePanorama((s) => s.removeSavedResource);
	const removeSavedBook = usePanorama((s) => s.removeSavedBook);
	const clearLearningData = usePanorama((s) => s.clearLearningData);
	const exportEvidence = usePanorama((s) => s.exportEvidence);
	const saveNote = usePanorama((s) => s.saveNote);
	const states = [...atlas].sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));
	const explored = states.filter((item) => item.status === "explored").length;
	const learning = states.filter((item) => item.status === "learning").length;
	const verified = states.filter((item) => item.status === "verified").length;
	const mastered = states.filter((item) => item.status === "mastered").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-4 py-10 text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.16em] text-primary",
						children: "Personal atlas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl",
						children: "My Learning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-2xl text-fg-muted",
						children: "A local record of what you explored, marked as learning, or actually verified. Nothing here is uploaded. Verification is evidence of demonstrated work, not a claim of mastery."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: exportEvidence,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Export evidence"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: () => {
							if (window.confirm("Clear all saved topics, resources, books, and recent searches?")) clearLearningData();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Clear"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: states.length,
						label: "Topics in atlas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: learning,
						label: "Learning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: verified,
						label: "Verified"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: savedTopics.length,
						label: "Saved"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-fg-muted",
				children: [
					"Explored ",
					explored,
					" · self-marked mastered ",
					mastered,
					". Self-mastery is not the same as verified."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 rounded-[22px] border border-border bg-bg-elevated p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Atlas"
				}), states.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-fg-muted",
					children: "Your atlas is empty. Explore a topic and it will appear here automatically."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid gap-3",
					children: states.slice(0, 12).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "flex flex-col gap-3 rounded-[16px] border border-border bg-bg-subtle p-4 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-fg-muted",
								children: [
									item.visits,
									" visit",
									item.visits === 1 ? "" : "s",
									" · ",
									STATUS_LABEL[item.status]
								]
							}),
							item.evidence ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-fg-muted",
								children: [
									"Check ",
									Number(item.evidence.score || 0),
									"/",
									Number(item.evidence.total || 5),
									" ·",
									" ",
									item.evidence.explanationSubmitted ? "explanation submitted" : "explanation pending",
									" ·",
									" ",
									item.evidence.connectionCompleted ? "connection demonstrated" : "connection pending"
								]
							}) : null
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => onOpen(item.title),
									children: "Open"
								}),
								item.status !== "learning" && item.status !== "verified" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => setAtlasStatus(item.title, "learning"),
									children: "Learning"
								}) : null,
								item.status !== "mastered" && item.status !== "verified" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => setAtlasStatus(item.title, "mastered"),
									children: "Mark mastered"
								}) : null
							]
						})]
					}, `${item.language}-${item.title}`))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-[22px] border border-border bg-bg-elevated p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Study note"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudyNote, { onSave: saveNote })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
				title: "Recent searches",
				empty: "No recent searches yet.",
				items: recentSearches.map((item) => ({
					title: item.pageTitle,
					meta: item.query,
					onOpen: () => onOpen(item.pageTitle),
					onRemove: () => removeRecent(item.query, item.language)
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
				title: "Saved topics",
				empty: "No saved topics yet.",
				items: savedTopics.map((item) => ({
					title: item.title,
					meta: item.category || item.description,
					onOpen: () => onOpen(item.title),
					onRemove: () => removeSavedTopic(item.url, item.language)
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
				title: "Saved resources",
				empty: "No saved resources yet.",
				items: savedResources.map((item) => ({
					title: item.name || item.title || item.url,
					meta: item.topic || item.url,
					href: item.url,
					onRemove: () => removeSavedResource(item.url)
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
				title: "Saved books",
				empty: "No saved books yet.",
				items: savedBooks.map((item) => ({
					title: item.title || item.url,
					meta: item.author || "",
					href: item.url,
					onRemove: () => removeSavedBook(item.url)
				}))
			})
		]
	});
}
function Stat({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[16px] border border-border bg-bg-elevated p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl tabular-nums",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-fg-muted",
			children: label
		})]
	});
}
function StudyNote({ onSave }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-3 grid gap-2",
		onSubmit: (event) => {
			event.preventDefault();
			const area = event.currentTarget.elements.namedItem("note");
			const value = area.value.trim();
			if (!value) return;
			onSave(value);
			area.value = "";
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			name: "note",
			className: "min-h-24 rounded-[12px] border border-border bg-bg-subtle p-3 text-sm text-fg outline-none focus:border-primary",
			placeholder: "A private note about what you are trying to understand."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "submit",
			variant: "secondary",
			className: "justify-self-start",
			children: "Save note locally"
		})]
	});
}
function ListBlock({ title, empty, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 rounded-[22px] border border-border bg-bg-elevated p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl",
			children: title
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-fg-muted",
			children: empty
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid gap-2 sm:grid-cols-2",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-[14px] border border-border bg-bg-subtle p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-semibold",
						children: item.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-fg-muted",
						children: item.meta
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [item.onOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: item.onOpen,
							children: "Open"
						}) : item.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: item.href,
								target: "_blank",
								rel: "noopener noreferrer",
								children: "Open"
							})
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: item.onRemove,
							children: "Remove"
						})]
					})
				]
			}, item.title + item.meta))
		})]
	});
}
var SLIDES = [
	{
		kicker: "01 / 08",
		title: "Take a step back. See the bigger picture.",
		body: "Eagles Panorama is an interactive learning explorer. The point is not one article. The point is where a topic sits in a wider landscape of knowledge."
	},
	{
		kicker: "02 / 08 · The problem",
		title: "Information is everywhere. Context is harder to find.",
		body: "Typical search hands you an isolated page. This app starts with a topic, then shows prerequisites, relationships, a path, and a way to check understanding."
	},
	{
		kicker: "03 / 08 · The solution",
		title: "A learning journey instead of a search result.",
		body: "Search, understand, connect, test, remember. Live public sources sit next to a small authored knowledge layer so exploration can be structured without becoming rigid."
	},
	{
		kicker: "04 / 08 · What you can do",
		title: "One system, several ways to learn.",
		cards: [
			"Learning paths with beginner, intermediate, and advanced routes",
			"A knowledge map of authored relationships",
			"A check that asks you to recall, connect, and explain",
			"Better sources: reference, learning, research, and books",
			"A personal atlas stored locally in the browser",
			"Wikipedia languages while exploring"
		]
	},
	{
		kicker: "05 / 08 · How it works",
		title: "A data-driven web application.",
		body: "Core subjects are structured data: aliases, overviews, paths, concepts, and relationships. The interface reads that data and generates the experience. Public APIs fill in live summaries, books, and research. Local storage keeps your atlas on this device."
	},
	{
		kicker: "06 / 08 · The technical idea",
		title: "It is not a collection of hard-coded pages.",
		body: "Adding a topic extends the app without creating a new page for every subject. Automatically generated paths are exploration aids, not formally validated curricula."
	},
	{
		kicker: "07 / 08 · Honest limitations",
		title: "A real project should say what it cannot do.",
		cards: [
			"Personal data stays in this browser",
			"Live search depends on public APIs",
			"Generated paths are not official courses",
			"The authored knowledge base is still small"
		]
	},
	{
		kicker: "08 / 08 · Demonstration",
		title: "Show the idea through one journey.",
		body: "Search Astronomy. Open the learning path. Explore the Knowledge Map. Take the check. Save it to the Personal Atlas. The strongest demo is one complete route, not a tour of every button."
	}
];
function PresentationModal() {
	const open = usePanorama((s) => s.presentationOpen);
	const setOpen = usePanorama((s) => s.setPresentationOpen);
	const [index, setIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
			if (event.key === "ArrowRight" || event.key === "ArrowDown") setIndex((value) => Math.min(SLIDES.length - 1, value + 1));
			if (event.key === "ArrowLeft" || event.key === "ArrowUp") setIndex((value) => Math.max(0, value - 1));
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, setOpen]);
	if (!open) return null;
	const slide = SLIDES[index];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-bg/95 text-fg backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-full max-w-5xl flex-col px-5 py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-semibold uppercase tracking-[0.16em] text-primary",
						children: "Project presentation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Eagles Panorama"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => setOpen(false),
						"aria-label": "Close presentation",
						children: "Close"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 h-1 overflow-hidden rounded-full bg-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-primary transition-[width] duration-200",
						style: { width: `${(index + 1) / SLIDES.length * 100}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-1 items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "w-full",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-[0.14em] text-primary",
								children: slide.kicker
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 max-w-4xl font-display text-4xl leading-tight sm:text-5xl",
								children: slide.title
							}),
							slide.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-3xl text-lg leading-8 text-fg-muted",
								children: slide.body
							}) : null,
							slide.cards ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 grid gap-3 sm:grid-cols-2",
								children: slide.cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "rounded-[16px] border border-border bg-bg-elevated p-4 text-fg-muted",
									children: card
								}, card))
							}) : null
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							disabled: index === 0,
							onClick: () => setIndex(index - 1),
							children: "Previous"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden justify-center gap-1 sm:flex",
							children: SLIDES.map((_, dot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Go to slide ${dot + 1}`,
								onClick: () => setIndex(dot),
								className: dot === index ? "h-2 w-6 rounded-full bg-primary" : "size-2 rounded-full bg-border"
							}, dot))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "justify-self-end",
							disabled: index === SLIDES.length - 1,
							onClick: () => setIndex(index + 1),
							children: "Next"
						})
					]
				})
			]
		})
	});
}
function Badge({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border border-primary/20 bg-primary-soft px-2.5 py-1 text-xs font-semibold text-primary", className),
		children
	});
}
var Tabs = Root2;
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("flex flex-wrap gap-1 rounded-[18px] bg-surface-2 p-1 text-ink", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("inline-flex min-h-11 flex-1 items-center justify-center rounded-[12px] px-3 text-sm font-semibold text-ink-muted transition-colors data-[state=active]:bg-surface data-[state=active]:text-ink data-[state=active]:shadow-sm", className),
		...props
	});
}
function TabsContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
		className: cn("mt-5 outline-none", className),
		...props
	});
}
function TopicWorkspace() {
	const result = usePanorama((s) => s.result);
	const loading = usePanorama((s) => s.loading);
	const error = usePanorama((s) => s.error);
	const tab = usePanorama((s) => s.tab);
	const setTab = usePanorama((s) => s.setTab);
	const explore = usePanorama((s) => s.explore);
	const saved = usePanorama(isTopicSaved);
	const toggleSavedTopic = usePanorama((s) => s.toggleSavedTopic);
	const next = nextPathStep(result);
	if (!result && !loading) {
		if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-8 max-w-3xl rounded-[22px] border border-danger/30 bg-surface p-6 text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Could not open that subject"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-ink-muted",
				children: error
			})]
		});
		return null;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto mt-8 max-w-5xl rounded-[26px] border border-line bg-surface p-4 text-ink shadow-[0_18px_44px_rgba(4,22,36,0.14)] sm:p-8",
		children: [loading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-col items-center gap-3 py-8",
			role: "status",
			"aria-live": "polite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-8 items-end gap-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 animate-bounce rounded-full bg-primary [animation-delay:-0.2s]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 animate-bounce rounded-full bg-primary [animation-delay:-0.1s]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 animate-bounce rounded-full bg-primary" })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink-muted",
				children: "Opening the landscape around this subject…"
			})]
		}), result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-5 border-b border-line pb-6 sm:flex-row",
				children: [result.summary.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: result.summary.image,
					alt: "",
					className: "h-36 w-full rounded-[16px] object-cover sm:h-[140px] sm:w-[190px]"
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl text-ink sm:text-4xl",
							children: result.summary.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-ink-muted",
							children: result.summary.description || "Explore this subject."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								result.localTopic ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: result.localTopic.category }) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									className: "bg-surface-2 text-ink",
									children: result.level
								}),
								result.usedFallback ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									className: "bg-surface-2 text-ink",
									children: "Curated fallback"
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "paper",
								onClick: toggleSavedTopic,
								children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), saved ? "Saved" : "Save topic"]
							}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => void explore(next),
								children: [
									"Next: ",
									next,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
								]
							}) : null]
						})
					]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-warn",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: tab,
				onValueChange: (value) => setTab(value),
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "understand",
							children: "Understand"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "connect",
							children: "Connect"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "verify",
							children: "Verify"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "sources",
							children: "Sources"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "understand",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnderstandPanel, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "connect",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectPanel, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "verify",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifyPanel, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "sources",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SourcesPanel, {})
					})
				]
			})
		] })]
	});
}
function UnderstandPanel() {
	const result = usePanorama((s) => s.result);
	const explore = usePanorama((s) => s.explore);
	const segments = segmentOverview(result.localTopic?.overview || result.summary.extract);
	const path = result.localTopic?.learningPath[result.level] || result.localTopic?.learningPath.beginner || createExplorationPath(result.summary.title, result.relatedPages, result.level);
	const currentIndex = Math.max(0, path.findIndex((item) => item.toLowerCase() === result.summary.title.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5",
		children: [
			result.localTopic?.misconception ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rounded-[16px] border border-line bg-surface-2 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.12em] text-ink-muted",
					children: "A common mix-up"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 leading-6 text-ink",
					children: result.localTopic.misconception
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: segments.map((segment) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-[16px] border border-line bg-surface-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold text-ink",
						children: segment.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 leading-7 text-ink-muted",
						children: segment.text
					})]
				}, segment.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
						title: "Core ideas",
						body: result.localTopic?.concepts.slice(0, 3).join(" · ") || result.summary.description || "Explore the connected ideas."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
						title: "Start with",
						body: result.localTopic?.prerequisites.slice(0, 2).join(" · ") || "No curated prerequisites yet."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
						title: "Nearby",
						body: result.localTopic?.related.slice(0, 3).join(" · ") || result.relatedPages.slice(0, 3).map((p) => p.title).join(" · ") || "Explore nearby ideas."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl text-ink",
					children: "Learning path"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-ink-muted",
					children: "One sequence. Click a step to open it. This is a map, not a certified curriculum."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid gap-2 sm:grid-cols-5",
					children: path.slice(0, 5).map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void explore(step),
						className: cn("flex min-h-[86px] w-full flex-col items-start rounded-[14px] border px-3 py-3 text-left", index === currentIndex ? "border-primary bg-primary-soft" : index < currentIndex ? "border-line bg-surface-2" : "border-line bg-surface"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-semibold text-ink-muted",
							children: index + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 text-sm font-semibold text-ink",
							children: step
						})]
					}) }, step))
				})
			] })
		]
	});
}
function InfoCard({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[16px] border border-line bg-surface-2 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-sm font-semibold text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-6 text-ink-muted",
			children: body
		})]
	});
}
function ConnectPanel() {
	const result = usePanorama((s) => s.result);
	const explore = usePanorama((s) => s.explore);
	const region = getDeepKnowledgeContext(result.localKey, result.summary.title);
	const related = result.localTopic?.related?.length ? result.localTopic.related : result.relatedPages.map((page) => page.title);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [region ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl text-ink",
				children: "Authored knowledge region"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-6 text-ink-muted",
				children: region.thesis
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: region.nodes.map((node) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void explore(node.title),
					className: cn("rounded-[16px] border p-4 text-left", node.title.toLowerCase() === result.summary.title.toLowerCase() ? "border-primary bg-primary-soft" : "border-line bg-surface-2"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold text-ink",
							children: node.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[11px] font-semibold uppercase tracking-[0.08em] text-ink-muted",
							children: node.role
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-6 text-ink-muted",
							children: node.why
						})
					]
				}, node.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-2",
				children: region.relations.slice(0, 8).map(([from, to, type, why]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-[12px] border-l-2 border-primary bg-surface-2 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold text-ink",
						children: [
							from,
							" → ",
							to,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs font-medium uppercase tracking-[0.08em] text-ink-muted",
								children: RELATION_COPY[type]?.label || type
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-ink-muted",
						children: why
					})]
				}, `${from}-${to}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-ink-muted",
				children: "These relationships are authored for this prototype. They are deeper than generic related-topic links, but they are not a complete map of the field."
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-ink-muted",
			children: "This subject is not in the authored knowledge regions yet. Use the related results as an exploration aid, not as a validated curriculum."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "font-display text-xl text-ink",
			children: "Related subjects"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid gap-2",
			children: related.slice(0, 8).map((title) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => void explore(title),
				className: "flex min-h-12 items-center justify-between rounded-[14px] border border-line bg-surface-2 px-4 text-left font-semibold text-ink",
				children: [title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-ink-muted" })]
			}, title))
		})] })]
	});
}
function VerifyPanel() {
	const result = usePanorama((s) => s.result);
	const questions = (0, import_react.useMemo)(() => currentQuestions(result), [result]);
	const recordEvidence = usePanorama((s) => s.recordEvidence);
	const saveExplanation = usePanorama((s) => s.saveExplanation);
	const saveFeedback = usePanorama((s) => s.saveFeedback);
	const atlas = usePanorama((s) => s.atlas);
	const explore = usePanorama((s) => s.explore);
	const evidence = atlas.find((item) => item.title === result.summary.title && item.language === result.language)?.evidence;
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [explanation, setExplanation] = (0, import_react.useState)("");
	const [explainResult, setExplainResult] = (0, import_react.useState)(null);
	const [feedback, setFeedback] = (0, import_react.useState)("");
	const [feedbackNote, setFeedbackNote] = (0, import_react.useState)("");
	const [feedbackSaved, setFeedbackSaved] = (0, import_react.useState)(false);
	const score = Object.values(answers).filter((value) => value === "correct").length;
	const answered = Object.keys(answers).length;
	const next = nextPathStep(result);
	if (!questions) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-ink-muted",
		children: "This topic does not yet have enough curated data for a full check. Read the overview, then try explaining it in your own words after exploring a related subject."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl text-ink",
				children: "Knowledge check"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-ink-muted",
				children: "Reading is not the same as understanding. This is a recall check, not a certificate."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [
				"Score ",
				score,
				" / ",
				questions.length
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-4",
			children: questions.map((question, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionCard, {
				index,
				question,
				state: answers[index],
				onAnswer: (correct) => {
					if (answers[index]) return;
					const nextAnswers = {
						...answers,
						[index]: correct ? "correct" : "wrong"
					};
					setAnswers(nextAnswers);
					const nextScore = Object.values(nextAnswers).filter((value) => value === "correct").length;
					if (Object.keys(nextAnswers).length === questions.length) recordEvidence(result.summary.title, {
						score: nextScore,
						total: questions.length,
						connectionCompleted: nextAnswers[4] === "correct"
					});
				}
			}, question.prompt))
		})] }), answered === questions.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-[16px] border border-line bg-surface-2 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold text-ink",
					children: "Evidence of understanding"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-ink-muted",
					children: "Verified means 4/5 or better, a demonstrated connection, and an explanation that hits at least two authored concepts. That is evidence of work, not mastery."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
							title: "Knowledge check",
							body: `${score} / ${questions.length}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
							title: "Connection question",
							body: answers[4] === "correct" ? "Demonstrated" : "Not yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoCard, {
							title: "Own explanation",
							body: evidence?.explanationSubmitted ? "Submitted" : "Pending"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-sm font-semibold text-ink",
					children: ["Explain it in your own words", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: explanation,
						onChange: (event) => setExplanation(event.target.value),
						className: "mt-2 min-h-28 w-full rounded-[12px] border border-line bg-surface p-3 text-sm text-ink outline-none focus:border-primary",
						placeholder: "What is the main idea? How does it work, and what does it connect to?"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					disabled: !explanation.trim(),
					onClick: () => setExplainResult(saveExplanation(result.summary.title, explanation.trim())),
					children: "Save explanation"
				}),
				explainResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-ink-muted",
					children: explainResult.coverage >= 2 ? "Your explanation included multiple authored concepts. That is useful evidence." : "Recorded, but it did not yet contain enough key concepts for verification."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-ink",
							children: "Did this help you understand the topic?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								"helpful",
								"mixed",
								"not-helpful"
							].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setFeedback(value),
								className: cn("min-h-10 rounded-full border px-3 text-sm font-semibold", feedback === value ? "border-primary bg-primary-soft text-primary" : "border-line bg-surface text-ink"),
								children: value === "helpful" ? "Helpful" : value === "mixed" ? "Somewhat" : "Not yet"
							}, value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: feedbackNote,
							onChange: (event) => setFeedbackNote(event.target.value),
							className: "mt-3 min-h-20 w-full rounded-[12px] border border-line bg-surface p-3 text-sm",
							placeholder: "Optional: what confused you, or what helped most?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-3",
							variant: "paper",
							disabled: !feedback,
							onClick: () => {
								saveFeedback(result.summary.title, feedback, feedbackNote);
								setFeedbackSaved(true);
							},
							children: feedbackSaved ? "Feedback saved locally" : "Save feedback"
						})
					]
				}),
				next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "mt-4",
					onClick: () => void explore(next),
					children: ["Continue to ", next]
				}) : null
			]
		}) : null]
	});
}
function QuestionCard({ index, question, state, onAnswer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[16px] border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] font-semibold uppercase tracking-[0.1em] text-primary",
				children: ["Question ", index + 1]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "mt-1 font-semibold text-ink",
				children: question.prompt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-2",
				children: question.options.map((option, optionIndex) => {
					const isCorrect = option === question.correct;
					const chosen = Boolean(state);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: chosen,
						onClick: () => onAnswer(isCorrect),
						className: cn("flex min-h-12 items-center gap-3 rounded-[12px] border px-3 text-left text-sm", chosen && isCorrect ? "border-primary bg-primary-soft text-ink" : chosen && !isCorrect && state === "wrong" ? "border-line bg-surface-2 text-ink" : "border-line bg-surface text-ink"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-7 place-items-center rounded-[8px] border border-line text-xs font-bold",
							children: String.fromCharCode(65 + optionIndex)
						}), option]
					}, option);
				})
			}),
			state ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-ink-muted",
				children: [
					state === "correct" ? "Correct — keep going." : "Not quite — use the explanation as a clue.",
					" ",
					question.explanation
				]
			}) : null
		]
	});
}
function SourcesPanel() {
	const result = usePanorama((s) => s.result);
	const research = usePanorama((s) => s.research);
	const researchLoading = usePanorama((s) => s.researchLoading);
	const toggleSavedBook = usePanorama((s) => s.toggleSavedBook);
	const toggleSavedResource = usePanorama((s) => s.toggleSavedResource);
	const savedBooks = usePanorama((s) => s.savedBooks);
	const savedResources = usePanorama((s) => s.savedResources);
	const curated = result.localKey ? topics[result.localKey]?.resources || [] : [];
	const wikiURL = result.summary.url;
	const bookURL = `https://openlibrary.org/search?q=${encodeURIComponent(result.summary.title)}`;
	const researchURL = `https://openalex.org/works?search=${encodeURIComponent(result.summary.title)}`;
	const scholarURL = `https://www.semanticscholar.org/search?q=${encodeURIComponent(result.summary.title)}`;
	const learnURL = `https://www.khanacademy.org/search?page_search_query=${encodeURIComponent(result.summary.title)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Lane, {
					title: "Research",
					body: "Find academic work related to this topic.",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: researchURL,
						target: "_blank",
						rel: "noopener noreferrer",
						children: "OpenAlex"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: scholarURL,
						target: "_blank",
						rel: "noopener noreferrer",
						children: "Semantic Scholar"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Lane, {
					title: "Learn",
					body: "Use structured material when you want to actually study.",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: learnURL,
						target: "_blank",
						rel: "noopener noreferrer",
						children: "Khan Academy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: bookURL,
						target: "_blank",
						rel: "noopener noreferrer",
						children: "Open Library"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-[16px] border border-line bg-surface-2 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.08em] text-ink-muted",
							children: "Reference"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
							className: "mt-2 font-semibold",
							children: ["Wikipedia — ", result.summary.title]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-ink-muted",
							children: "Definitions, context, citations, and linked concepts."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary",
							href: wikiURL,
							target: "_blank",
							rel: "noopener noreferrer",
							children: ["Open reference ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
						})
					]
				}), curated.map((resource) => {
					const type = classifySource(resource.url, resource.name);
					const saved = savedResources.some((item) => item.url === resource.url);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-[16px] border border-line bg-surface-2 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-[0.08em] text-ink-muted",
								children: type.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "mt-2 font-semibold",
								children: resource.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-ink-muted",
								children: type.why
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "inline-flex items-center gap-1 text-sm font-semibold text-primary",
									href: resource.url,
									target: "_blank",
									rel: "noopener noreferrer",
									children: ["Open source ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "paper",
									onClick: () => toggleSavedResource({
										name: resource.name,
										url: resource.url,
										topic: result.summary.title
									}),
									children: saved ? "Saved" : "Save"
								})]
							})
						]
					}, resource.url);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "inline-flex items-center gap-2 font-display text-xl text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5" }), " Public learning library"]
			}), result.books.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-ink-muted",
				children: "No publicly readable books were found for this search."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: result.books.map((book) => {
					const saved = savedBooks.some((item) => item.url === book.url);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "flex gap-3 rounded-[16px] border border-line bg-surface-2 p-3",
						children: [book.cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: book.cover,
							alt: "",
							className: "h-[110px] w-[76px] rounded-[8px] object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[110px] w-[76px] rounded-[8px] bg-line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-semibold",
									children: book.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-ink-muted",
									children: book.author
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-ink-muted",
									children: ["First published: ", book.year]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "mt-2 inline-block text-sm font-semibold text-primary",
									href: book.url,
									target: "_blank",
									rel: "noopener noreferrer",
									children: "Explore book"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "paper",
									className: "ml-2",
									onClick: () => toggleSavedBook({
										...book,
										topic: result.summary.title
									}),
									children: saved ? "Saved" : "Save"
								})
							]
						})]
					}, book.url);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "inline-flex items-center gap-2 font-display text-xl text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5" }), " Live research"]
			}), researchLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-ink-muted",
				children: "Searching recent research sources…"
			}) : research.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-ink-muted",
				children: "No live research results were found. The source links above are still available."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: research.map((work) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-[16px] border border-line bg-surface-2 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold text-primary",
							children: [
								work.year,
								" · ",
								work.venue
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "mt-1 font-semibold",
							children: work.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "mt-2 inline-flex items-center gap-1 text-sm font-semibold text-primary",
							href: work.url,
							target: "_blank",
							rel: "noopener noreferrer",
							children: ["Read research ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })]
						})
					]
				}, work.url))
			})] })
		]
	});
}
function Lane({ title, body, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[16px] border border-line bg-surface-2 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "font-semibold text-ink",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-ink-muted",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2 [&_a]:rounded-[10px] [&_a]:border [&_a]:border-line [&_a]:bg-surface [&_a]:px-3 [&_a]:py-2 [&_a]:text-sm [&_a]:font-semibold [&_a]:text-ink",
				children
			})
		]
	});
}
function AppChrome({ children }) {
	const hydrate = usePanorama((s) => s.hydrate);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_15%_10%,rgba(31,154,147,0.16),transparent_28%),radial-gradient(circle_at_88%_0%,rgba(180,210,220,0.08),transparent_24%)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresentationModal, {})
		]
	});
}
function TopBar() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const language = usePanorama((s) => s.language);
	const setLanguage = usePanorama((s) => s.setLanguage);
	const setPresentationOpen = usePanorama((s) => s.setPresentationOpen);
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-30 border-b border-border/80 bg-bg/85 px-3 py-3 backdrop-blur-md sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "mr-auto flex min-h-11 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-8 place-items-center rounded-[10px] bg-primary text-xs font-bold text-primary-fg",
						children: "EP"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden font-display text-lg sm:block",
						children: "Eagles Panorama"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavLink, {
					to: "/",
					active: pathname === "/",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: "Explore"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavLink, {
					to: "/map",
					active: pathname === "/map",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map$1, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: "Map"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavLink, {
					to: "/learning",
					active: pathname === "/learning",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: "Learning"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "sm",
					onClick: () => setPresentationOpen(true),
					children: "Project"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					className: "hidden sm:inline-flex",
					onClick: () => {
						navigate({ to: "/" });
						requestAnimationFrame(() => document.querySelector("#about")?.scrollIntoView({ behavior: "smooth" }));
					},
					children: "About"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "sr-only",
					htmlFor: "languageSelect",
					children: "Language"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					id: "languageSelect",
					value: language,
					onChange: (event) => setLanguage(event.target.value),
					className: "h-11 max-w-[34vw] rounded-[12px] border border-border bg-bg-elevated px-2 text-sm text-fg sm:max-w-none",
					children: SUPPORTED_LANGUAGES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.code,
						children: item.label
					}, item.code))
				})
			]
		})
	});
}
function NavLink({ to, active, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: cn("inline-flex min-h-11 items-center gap-2 rounded-[12px] px-3 text-sm font-semibold", active ? "bg-bg-subtle text-fg" : "text-fg-muted hover:bg-bg-subtle hover:text-fg"),
		children
	});
}
function ExploreHome() {
	const query = usePanorama((s) => s.query);
	const setQuery = usePanorama((s) => s.setQuery);
	const loadSuggestions = usePanorama((s) => s.loadSuggestions);
	const suggestions = usePanorama((s) => s.suggestions);
	const clearSuggestions = usePanorama((s) => s.clearSuggestions);
	const explore = usePanorama((s) => s.explore);
	const loading = usePanorama((s) => s.loading);
	const level = usePanorama((s) => s.level);
	const setLevel = usePanorama((s) => s.setLevel);
	const language = usePanorama((s) => s.language);
	const atlas = usePanorama((s) => s.atlas);
	const inputRef = (0, import_react.useRef)(null);
	const categories = topicCategories(language);
	const continueTitle = atlas[0]?.title;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "px-4 pb-8 pt-14 text-center sm:pt-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-[0.18em] text-primary",
					children: "Welcome to the knowledge landscape"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mx-auto mt-5 max-w-4xl font-display text-4xl leading-tight sm:text-6xl",
					children: ["Take a step back.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-primary",
						children: "See the bigger picture."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-5 max-w-2xl text-base leading-7 text-fg-muted sm:text-lg",
					children: "Search a subject, see what it depends on, follow a path, and check whether you actually understood it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "relative mx-auto mt-8 w-full max-w-3xl",
					onSubmit: (event) => {
						event.preventDefault();
						clearSuggestions();
						explore(query);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 rounded-[20px] border border-border bg-bg-elevated p-2 sm:flex-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								ref: inputRef,
								id: "searchInput",
								value: query,
								onChange: (event) => loadSuggestions(event.target.value),
								onKeyDown: (event) => {
									if (event.key === "Enter") {
										event.preventDefault();
										clearSuggestions();
										explore(query);
									}
								},
								placeholder: "What do you want to learn?",
								autoComplete: "off",
								className: "h-12 flex-1"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: level,
								onChange: (event) => setLevel(event.target.value),
								className: "h-12 rounded-[12px] border border-line bg-surface px-3 text-ink",
								"aria-label": "Learning level",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "beginner",
										children: "Beginner"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "intermediate",
										children: "Intermediate"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "advanced",
										children: "Advanced"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: loading,
								className: "h-12 min-w-28",
								children: loading ? "Exploring" : "Explore"
							})
						]
					}), suggestions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: "suggestions",
						className: "absolute left-0 right-0 top-[calc(100%+8px)] z-20 max-h-[min(360px,55vh)] overflow-y-auto rounded-[12px] border border-line bg-surface text-left shadow-lg",
						children: suggestions.map((title) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "block w-full px-4 py-3 text-left text-ink hover:bg-surface-2",
							onClick: () => {
								setQuery(title);
								clearSuggestions();
								explore(title);
							},
							children: title
						}, title))
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap justify-center gap-2",
					children: [[
						"Astronomy",
						"Physics",
						"History",
						"Philosophy",
						"Mathematics"
					].map((title) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setQuery(title);
							explore(title);
						},
						className: "min-h-10 rounded-full border border-border bg-bg-elevated px-3 text-sm text-fg-muted hover:text-fg",
						children: ["Try ", title]
					}, title)), continueTitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setQuery(continueTitle);
							explore(continueTitle);
						},
						className: "min-h-10 rounded-full border border-primary/40 bg-primary/10 px-3 text-sm text-primary",
						children: ["Continue ", continueTitle]
					}) : null]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopicWorkspace, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "about",
			className: "mx-auto mt-16 max-w-5xl px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[24px] border border-border bg-bg-elevated p-6 sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "About Eagles Panorama"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-3xl leading-7 text-fg-muted",
						children: "A learning explorer for seeing the landscape around a subject — not just a page of facts. Curated paths and authored relationships sit beside live public sources. Personal progress stays in this browser."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutCard, {
								title: "Curated knowledge",
								body: "Core subjects include levels, concepts, prerequisites, related subjects, and an authored relationship model."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutCard, {
								title: "Live sources",
								body: "Wikipedia, Open Library, and OpenAlex extend the built-in catalog. If live search fails, curated topics still open."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutCard, {
								title: "Evidence, not theater",
								body: "A quiz score is only one signal. Verification also needs a connection and an explanation in your own words."
							})
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto mt-14 max-w-5xl px-4 pb-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Explore a world of knowledge"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-fg-muted",
					children: "Start from a field, then keep moving through connected ideas."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid gap-4",
					children: categories.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-[20px] border border-border bg-bg-elevated p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-semibold",
							children: group.category
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: group.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-[12px] border border-border bg-bg-subtle px-4 text-sm font-semibold text-fg",
								onClick: () => {
									setQuery(item.title);
									explore(item.title);
									window.scrollTo({
										top: 0,
										behavior: "smooth"
									});
								},
								children: item.title
							}, item.key))
						})]
					}, group.category))
				})
			]
		})
	] });
}
function AboutCard({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-[16px] border border-border bg-bg-subtle p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "font-semibold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-6 text-fg-muted",
			children: body
		})]
	});
}
function MapPage() {
	const result = usePanorama((s) => s.result);
	const perspective = usePanorama((s) => s.mapPerspective);
	const setMapPerspective = usePanorama((s) => s.setMapPerspective);
	const explore = usePanorama((s) => s.explore);
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Knowledge Map"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-fg-muted",
				children: "A brighter map board, not a star chart. Click a node to open that subject in the learning space."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => void navigate({ to: "/" }),
				children: "Back to learning"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KnowledgeMap, {
			result,
			perspective,
			onPerspective: setMapPerspective,
			onOpen: (title) => {
				explore(title);
				navigate({ to: "/" });
			}
		})]
	});
}
function LearningPage() {
	const explore = usePanorama((s) => s.explore);
	const setQuery = usePanorama((s) => s.setQuery);
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LearningAtlas, { onOpen: (title) => {
		setQuery(title);
		explore(title);
		navigate({ to: "/" });
	} });
}
//#endregion
export { MapPage as i, ExploreHome as n, LearningPage as r, AppChrome as t };
