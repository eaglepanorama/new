import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as LearningPage, t as AppChrome } from "./shell-BzHUoGFR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learning-C0WZuurW.js
var import_jsx_runtime = require_jsx_runtime();
function LearningRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppChrome, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LearningPage, {}) });
}
//#endregion
export { LearningRoute as component };
