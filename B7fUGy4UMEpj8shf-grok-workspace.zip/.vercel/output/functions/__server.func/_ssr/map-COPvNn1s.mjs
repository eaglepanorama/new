import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as MapPage, t as AppChrome } from "./shell-BzHUoGFR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/map-COPvNn1s.js
var import_jsx_runtime = require_jsx_runtime();
function MapRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppChrome, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPage, {}) });
}
//#endregion
export { MapRoute as component };
