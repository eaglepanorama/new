//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-P9tbbt-m.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/learning",
			"/map"
		],
		preloads: ["/assets/index-xaESCcVF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-xaESCcVF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B0mkObEH.js", "/assets/shell-BdPgpXlD.js"]
	},
	"/learning": {
		filePath: "/workspace/src/routes/learning.tsx",
		children: void 0,
		preloads: ["/assets/learning-CDcWK2QE.js", "/assets/shell-BdPgpXlD.js"]
	},
	"/map": {
		filePath: "/workspace/src/routes/map.tsx",
		children: void 0,
		preloads: ["/assets/map-NkMcTMsX.js", "/assets/shell-BdPgpXlD.js"]
	}
} });
//#endregion
export { tsrStartManifest };
